PivotData Command Line Utility
------------------------------
Pivotdata is a command line utility that can aggregate data from CSV files and SQL databases, 
build in-memory data cube and produce pretty pivot table reports (HTML/Excel/CSV/PDF) without OLAP server and Excel. 
Pivotdata utility doesn't need any programming skills. 

Links
-----
Utility documentation: http://www.nrecosite.com/pivotdata_utility.aspx
NReco.PivotData library page: http://www.nrecosite.com/pivot_data_library_net.aspx
Email: support@nrecosite.com

Demo
----
run_example1_save_and_load.bat			illustrates how to aggregate data from csv file, save data cube into file, get aggregated values and generate HTML pivot reports from previously saved aggregation results
run_example2_mapping.bat				illustrates how to use advanced field mapping rules and generate HTML pivot table report without creating data cube file
run_example3_excel.bat					generates pivot report in Excel format
run_example4_mssql_source.bat			illustrates how to use MS SQL AdventureWorks DB as input data
run_example5_mssql_grouped_source.bat	illustrates how to pre-aggregate data on SQL level with GROUP BY

Usage
-----
usage: pivotdata [OPTIONS] -i <inputHandler> [dataOptions] -o <outputHandler>
Global Options:
  -h                                              Display help
  --silent                                        Be less verbose
  --debug                                         Output error stacktrace

Input Handlers:
  -i cubefile <input file>                        Load cube from serialized data file (pair of .cfg and .dat files) as input source
  -i csv <csv file> [{csv_opts_json}]             Aggregate data from csv file. Cube configuration is required in this case (-p)
  -i <mssql|odbc> {db_opts_json}                  Aggregate data returned by DB driver (mssql or odbc). Cube configuration is required in this case (-p)

Data Options:
  -p {cube_cfg_json}                              Define in-memory cube configuration (json)
  -m {mapping_opts_json}                          Apply value mapping rules for each input data row. Not applicable with 'cubefile' input handler
  -t {pivot_table_config_json}                    Pivot table report configuration for 'pivottable*' output handlers
  -s {slice_query_json}                           Transform data cube according to the specified query
  -g <count field name>                           Load input data as pre-grouped cube datapoints. This option is not applicable with '-i cubefile' 

Output Handlers:
  -o cubefile <output file>                       Save aggregated data to the file (pair of .cfg and .dat files)
  -o uploadpackage {opts_json}                    Upload zip package with cube file to the specified URL (can be used for uploading cube to the SemanticTool) 
  -o getvalue {value_key_json_arr}                Display aggregated value for specified dimension keys
  -o pivottablehtml <output file> [{opts_json}]   Render pivot table report to HTML (-t option is required)
  -o pivottablecsv <output file> [{opts_json}]    Render pivot table report to CSV (-t option is required)
  -o pivottableexcel <output file> [{opts_json}]  Render pivot table report to Excel (-t option is required)
	
License
-------
Pivotdata utility is a FREE tool that may be used by end-users and for server-side automations.
If you want to redistribute it as part of your own solution/product you will need to purchase appropriate commercial license.

Pivotdata utility source code may be purchased as part of NReco.PivotData Toolkit: http://www.nrecosite.com/pivot_data_library_net.aspx


