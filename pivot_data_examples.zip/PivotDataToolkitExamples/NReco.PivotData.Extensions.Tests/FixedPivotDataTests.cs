﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Threading.Tasks;
using Xunit;
using System.Diagnostics;
using System.IO;

namespace NReco.PivotData.Extensions.Tests {
	
	public class FixedPivotDataTests {

		[Fact]
		public void GetValueAndTotals() {
			var pvtData = getSamplePivotData();

			Assert.Throws<ArgumentException>( ()=> { var val = pvtData[Key.Empty,Key.Empty].Value; });
			Assert.Equal(54U, pvtData[Key.Empty,Key.Empty,Key.Empty].Value);

			Assert.Equal(18U, pvtData["A1",Key.Empty,Key.Empty].Value);
			Assert.Equal(6U, pvtData["A1","B1", Key.Empty].Value);

			Assert.Equal(2U, pvtData["A1","B1", "C1"].Value);
		}

		[Fact]
		public void SliceQueryTest() {
			var pvtData = new PivotData(new[] {"a","b","d"},
					new CompositeAggregatorFactory(
						new CountAggregatorFactory(), 
						new SumAggregatorFactory("d")
					),
					false);
			pvtData.ProcessData( DataUtils.getSampleData(10000), DataUtils.getProp);

			var q = new SliceQuery(pvtData).Dimension("a").Where("a", "val1", "val2").Measure(0);
			var pvtDataRes1 = q.Execute(false);

			var pvtState = pvtData.GetState();
			var pvtFixedData = new FixedPivotData(pvtData.Dimensions, pvtData.AggregatorFactory, pvtState);

			var q2 = new SliceQuery(pvtFixedData).Dimension("a").Measure(0)
				.Where( (entry) => new[]{"val1","val2"}.Contains(entry.Key[0].ToString()) );
			var pvtDataRes2 = q2.Execute(false);

			Assert.Equal( pvtDataRes1[Key.Empty].Value, pvtDataRes2[Key.Empty].Value );
		}

		[Fact]
		public void SparseDataTest() {
			var pvtData = new PivotData(new[] { "A", "B" }, new CountAggregatorFactory());
			pvtData.ProcessData(new[] {
				new { A = "a1", B = "b1"},
				new { A = "a2", B = "b2"}
			}, new ObjectMember().GetValue);
			Assert.Equal(2, pvtData.Count);

			var pvtState = pvtData.GetState();
			Assert.Equal(2, pvtState.Values.Length);
			var fixedPvtData = new FixedPivotData(pvtData.Dimensions, pvtData.AggregatorFactory, pvtState);
			Assert.Equal(1U, fixedPvtData["a1", "b1"].Count);
			Assert.Equal(0U, fixedPvtData["a1", "b2"].Count);
			Assert.Equal(0U, fixedPvtData["a2", "b1"].Count);
		}

		[Fact]
		public void SerializeTest() {
			var pivotDataState = new PivotDataState(2,
				new object[] { Key.Empty, "AAA" },
				new uint[1][] {
					new uint[2] { 0, 1 },
				},
				new object[] { new object[] { (uint)1, 2M } }
			);
			var fixedPvtData = new FixedPivotData(new[] { "A", "B" }, new SumAggregatorFactory("C"), pivotDataState);
			Assert.Equal(2M, fixedPvtData[Key.Empty, "AAA"].Value);

			var memStream = new MemoryStream();
			new PivotDataState(fixedPvtData).Serialize(memStream);
			var deserializedState = PivotDataState.Deserialize(new MemoryStream(memStream.ToArray()));

			var fixedPvtData2 = new FixedPivotData(new[] { "A", "B" }, new SumAggregatorFactory("C"), deserializedState);
			Assert.Equal(2M, fixedPvtData2[Key.Empty, "AAA"].Value);
		}

		[Fact]
		public void StateWithDuplicateEntryTest() {
			// check set state with duplicate keys for values
			var pvtState = new PivotDataState() {
				DimCount = 2,
				KeyValues = new object[] { "a1", "a2", "b1", "b2" },
				ValueKeys = new uint[][] {
					new uint[] { 0, 2 },
					new uint[] { 0, 3 },
					new uint[] { 1, 2 },
					new uint[] { 1, 3 },
					new uint[] { 0, 2 },  // duplicate key!
					new uint[] { 0, 2 }  // duplicate key!
				},
				Values = new object[] { 1, 2, 3, 4, 5, 1 }
			};
			var pvtData = new FixedPivotData(new[] { "a", "b" }, new CountAggregatorFactory(), pvtState);
			Assert.Equal(7U, pvtData["a1", "b1"].Value);  // 1+5+1
			Assert.Equal(16U, pvtData[Key.Empty, Key.Empty].Value);
			Assert.Equal(4, pvtData.Count);
			Assert.Equal(4, pvtData.Count());
		}

		//[Fact]
		public void PerformanceTest() {
			var tstPvtData = new PivotData(
				new string[] { "year", "month", "a" },
				new CompositeAggregatorFactory(new CountAggregatorFactory(), new SumAggregatorFactory("i")),
				SampleGenerator(1000000),
				GetRecordValue, true);
			Func<IPivotData,long> checkAccessTime = (pvtData) => {
				var sw = new Stopwatch();
				sw.Start();

				var pvtTbl = new PivotTable(new[] { "year", "month" }, new[] { "a" }, pvtData);
				Console.WriteLine("Table size: {0}x{1}", pvtTbl.RowKeys.Length, pvtTbl.ColumnKeys.Length);
				for (int n = 0; n < 10; n++) {
					uint cnt = 0;
					int zeroCells = 0;
					//foreach (var entry in pvtData)
					//	cnt += entry.Value.Count;
					for (int i = 0; i < pvtTbl.RowKeys.Length; i++)
						for (int j = 0; j < pvtTbl.ColumnKeys.Length; j++) {
							var cellCnt = pvtTbl[i, j].Count;
							cnt += cellCnt;
							if (cellCnt == 0)
								zeroCells++;
						}
				}

				sw.Stop();
				return sw.ElapsedMilliseconds;
			};

			var pvtState = tstPvtData.GetState();

			Console.WriteLine("PivotData class access time = "+checkAccessTime(tstPvtData).ToString()+"ms");

			GC.Collect();
			var memBytes = GC.GetTotalMemory(false);

			var fixedPvtData = new FixedPivotData(tstPvtData.Dimensions, tstPvtData.AggregatorFactory, pvtState);
			Console.WriteLine("FixedPivotData class access time = " + checkAccessTime(tstPvtData).ToString() + "ms");

			Console.WriteLine("MEM=" + (GC.GetTotalMemory(false)- memBytes).ToString());

		}

		#region Perf test related
		public class TestRecord {
			public int a;
			public int year;
			public int month;
			public int i;
		}
		public static IEnumerable<TestRecord> SampleGenerator(int cnt, int shift = 0) {
			var r = new TestRecord();
			var dtStart = new DateTime(2015, 2, 08);
			for (int i = 0; i < cnt; i++) {
				r.a = i % 500;
				var dt = dtStart.AddHours(i);
				r.year = dt.Year;
				r.month = dt.Month;
				r.i = i + shift;
				yield return r;
			}
		}
		public static object GetRecordValue(object o, string f) {
			var r = (TestRecord)o;
			switch (f) {
				case "a": return r.a;
				case "year": return r.year;
				case "month": return r.month;
				case "i": return r.i;
			}
			return null;
		}
		#endregion

		FixedPivotData getSamplePivotData(bool diag = false) {
			var vals = new List<object>();
			var keys = new List<uint[]>();
			for (uint a=0; a<3; a++)
				for (uint b=(diag?a:0); b<3; b++)
					for (uint c=(diag?b:0); c<3; c++) {
						keys.Add( new uint[] {a, b+3, c+6 });
						vals.Add(2);
					}

			var pvtState = new PivotDataState() {
				DimCount = 3,
				KeyValues = new object[] { "A1", "A2", "A3", "B1", "B2", "B3", "C1", "C2", "C3" },
				Values = vals.ToArray(),
				ValueKeys = keys.ToArray()
			};
			return new FixedPivotData(new string[] {"A","B", "C"}, new CountAggregatorFactory(), pvtState );
		}


	}
}
