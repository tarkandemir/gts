﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xunit;

namespace NReco.PivotData.Extensions.Tests
{
    public class PaginatePivotTableTests
    {

		PivotTable createPvtTbl1() {
			var pvtData = new PivotData(new[] {"a","d", "f"}, new CountAggregatorFactory());
			pvtData.ProcessData( DataUtils.getSampleData(10000), DataUtils.getProp);
			return new PivotTable(new[]{"a"}, new[]{"d"}, pvtData);
		}

		[Fact]
		public void PaginateSimplePivotTableTest() {
			var pvtTbl = createPvtTbl1();

			var pagePvtTbl = new PaginatePivotTable(pvtTbl, 
					new PaginatePivotTable.Page(0, 10), 
					new PaginatePivotTable.Page(50, 10) );

			Assert.Equal(3, pagePvtTbl.RowKeys.Length );  // 3 + 0 (nothing to page)
			Assert.Equal(12, pagePvtTbl.ColumnKeys.Length );  // 10 + prev + next

			var colPrevKey =  pagePvtTbl.ColumnKeys[0].DimKeys[0] as PaginatePivotTable.Page;
			Assert.NotNull( colPrevKey );
			Assert.Equal(40, colPrevKey.Offset );
			Assert.Equal(10, colPrevKey.Limit );

			var colNextKey = pagePvtTbl.ColumnKeys[pagePvtTbl.ColumnKeys.Length-1].DimKeys[0] as PaginatePivotTable.Page;
			Assert.NotNull( colNextKey );
			Assert.Equal(60, colNextKey.Offset );
			Assert.Equal(10, colNextKey.Limit );

			// ensure that totals are unchanged
			Assert.Equal( pvtTbl.GetValue(null,null).Value, pagePvtTbl.GetValue(null,null).Value );

			var pagePvtTbl2 = new PaginatePivotTable(pvtTbl, 
					new PaginatePivotTable.Page(1, 2), 
					new PaginatePivotTable.Page(90, 10) );
			Assert.Equal(3, pagePvtTbl2.RowKeys.Length );  // 2 + 1 (prev)
			Assert.Equal(0, ((PaginatePivotTable.Page)pagePvtTbl2.RowKeys[0].DimKeys[0]).Offset );
			Assert.False( pagePvtTbl2.RowKeys.Last().DimKeys[0] is PaginatePivotTable.Page );

			Assert.Equal(11, pagePvtTbl2.ColumnKeys.Length );  // 9 + 1 (prev)
		}


    }
}
