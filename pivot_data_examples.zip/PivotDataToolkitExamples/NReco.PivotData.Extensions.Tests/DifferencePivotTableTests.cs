﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xunit;

namespace NReco.PivotData.Extensions.Tests
{
    public class DifferencePivotTableTests
    {

		PivotData createPvtData() {
			var pvtData = new PivotData(new[] { "a", "b" }, new SumAggregatorFactory("val"));
			pvtData.ProcessData(new object[] {
				new { a = "a1", b = "b1", val = 0 },
				new { a = "a1", b = "b2", val = 1 },
				new { a = "a1", b = "b3", val = 0 },
				new { a = "a1", b = "b4", val = 5 },
				new { a = "a1", b = "b5", val = -5 },
				new { a = "a2", b = "b3", val = 5 },
				new { a = "a2", b = "b4", val = 6 }
			}, new ObjectMember().GetValue);
			return pvtData;
		}

		void AssertPivotTableEqual(object[][] expectedVals, IPivotTable pvtTbl) {
			for (var colKeyIdx = 0; colKeyIdx < pvtTbl.ColumnKeys.Length; colKeyIdx++)
				for (var rowKeyIdx = 0; rowKeyIdx < pvtTbl.RowKeys.Length; rowKeyIdx++) {
					//Console.WriteLine("r:{0} c:{1} [{2}]", rowKeyIdx, colKeyIdx, pvtTbl.GetValue(pvtTbl.RowKeys[rowKeyIdx], pvtTbl.ColumnKeys[colKeyIdx]).Value);
					Assert.Equal(expectedVals[colKeyIdx][rowKeyIdx],
						pvtTbl.GetValue(pvtTbl.RowKeys[rowKeyIdx], pvtTbl.ColumnKeys[colKeyIdx]).Value);
				}
		}

		[Fact]
		public void DiffByPrevRowTest() {
			var pvtTbl = new PivotTable(new[]{"b"}, new[]{"a"}, createPvtData() );

			var prevRowDiffPvtTbl = new DifferencePivotTable(pvtTbl, DifferencePivotTable.DifferenceMode.PreviousRow);
			AssertPivotTableEqual(
				new object[][] {
					new object[] { null, 1M, -1M, 5M, -10M},
					new object[] { null, 0M, 5M, 1M, -6M }
				}, prevRowDiffPvtTbl);

			// percentage
			prevRowDiffPvtTbl.Percentage = true;
			prevRowDiffPvtTbl.RoundDigits = 2;

			AssertPivotTableEqual(
				new object[][] {
					new object[] { null, null, -100M, null, -200M},
					new object[] { null, null, null, 20M, -100M}
				}, prevRowDiffPvtTbl);
		}


		[Fact]
		public void DiffByNextRowTest() {
			var pvtTbl = new PivotTable(new[] { "b" }, new[] { "a" }, createPvtData());

			var prevRowDiffPvtTbl = new DifferencePivotTable(pvtTbl, DifferencePivotTable.DifferenceMode.NextRow);
			AssertPivotTableEqual(
				new object[][] {
					new object[] { -1M, 1M, -5M, 10M, null},
					new object[] { 0M, -5M, -1M, 6M, null }
				}, prevRowDiffPvtTbl);

			// percentage
			prevRowDiffPvtTbl.Percentage = true;
			prevRowDiffPvtTbl.RoundDigits = 2;

			AssertPivotTableEqual(
				new object[][] {
					new object[] { -100M, null, -100M, -200M, null},
					new object[] { null, -100M, -16.67M, null, null}
				}, prevRowDiffPvtTbl);
		}


		[Fact]
		public void DiffByPrevColumnTest() {
			var pvtTbl = new PivotTable(new[] { "a" }, new[] { "b" }, createPvtData());

			var prevColDiffPvtTbl = new DifferencePivotTable(pvtTbl, DifferencePivotTable.DifferenceMode.PreviousColumn);
			AssertPivotTableEqual(
				new object[][] {
					new object[] { null, null},
					new object[] { 1M, 0M },
					new object[] { -1M, 5M},
					new object[] { 5M, 1M },
					new object[] { -10M, -6M}
				}, prevColDiffPvtTbl);

			// percentage
			prevColDiffPvtTbl.Percentage = true;
			prevColDiffPvtTbl.RoundDigits = 2;

			AssertPivotTableEqual(
				new object[][] {
					new object[] {null, null},
					new object[] {null, null},
					new object[] {-100M, null},
					new object[] {null, 20M},
					new object[] {-200M, -100M},
				}, prevColDiffPvtTbl);
		}


		[Fact]
		public void DiffByNextColumnTest() {
			var pvtTbl = new PivotTable(new[] { "a" }, new[] { "b" }, createPvtData());

			var nextColDiffPvtTbl = new DifferencePivotTable(pvtTbl, DifferencePivotTable.DifferenceMode.NextColumn);
			AssertPivotTableEqual(
				new object[][] {
					new object[] { -1M, 0M},
					new object[] { 1M, -5M},
					new object[] { -5M, -1M},
					new object[] { 10M, 6M},
					new object[] { null, null},
				}, nextColDiffPvtTbl);

			// percentage
			nextColDiffPvtTbl.Percentage = true;
			nextColDiffPvtTbl.RoundDigits = 2;

			AssertPivotTableEqual(
				new object[][] {
					new object[] { -100M, null},
					new object[] { null, -100M},
					new object[] { -100M, -16.67M},
					new object[] { -200M, null},
					new object[] {null, null}
				}, nextColDiffPvtTbl);
		}

		PivotData getYearQuarterZ_PivotData(bool multiValue = false) {
			var pvtData = new PivotData(new[] { "year", "quarter", "z" }, 
				multiValue ? (IAggregatorFactory)new CompositeAggregatorFactory(
					new SumAggregatorFactory("val"), new CountAggregatorFactory()
				) : new SumAggregatorFactory("val"));
			pvtData.ProcessData(new object[] {
				new { year = 2016, quarter = "Q2", z = 1, val = 7 },
				new { year = 2016, quarter = "Q3", z = 1, val = 6 },
				new { year = 2016, quarter = "Q4", z = 1, val = 10 },
				new { year = 2017, quarter = "Q1", z = 1, val = 9 },
				new { year = 2017, quarter = "Q2", z = 1, val = 10 },
				new { year = 2017, quarter = "Q3", z = 1, val = 11 },
				new { year = 2017, quarter = "Q4", z = 1, val = 9 }
			}, new ObjectMember().GetValue);
			return pvtData;
		}

		[Fact]
		public void Diff_SubTotals() {
			var pvtData = getYearQuarterZ_PivotData();
			var rowPvtTbl = new PivotTable(new[] { "year", "quarter" }, new[] { "z" }, pvtData);
			var prevRowDiffPvtTbl = new DifferencePivotTable(rowPvtTbl, DifferencePivotTable.DifferenceMode.PreviousRow);
			Assert.Equal(39M-23,
				prevRowDiffPvtTbl.GetValue(new ValueKey(new object[] {2017, Key.Empty }), new ValueKey(new object[] {1})).Value );
			Assert.Equal(39M-23,
				prevRowDiffPvtTbl.GetValue(new ValueKey(new object[] { 2017, Key.Empty }), null).Value);
		}

		[Fact]
		public void Diff_MultiValue() {
			var pvtData = getYearQuarterZ_PivotData(true);
			var rowPvtTbl = new PivotTable(new[] { "year", "quarter" }, new[] { "z" }, pvtData);
			var prevRowDiffPvtTbl = new DifferencePivotTable(rowPvtTbl, DifferencePivotTable.DifferenceMode.PreviousRow);

			var strWr = new System.IO.StringWriter();
			var jsonWr = new NReco.PivotData.Output.PivotTableJsonWriter(strWr);
			jsonWr.Write(prevRowDiffPvtTbl);
		}

		[Fact]
		public void DiffWithCustomFromTest() {
			var pvtData = getYearQuarterZ_PivotData();

			var rowPvtTbl = new PivotTable(new[] { "year", "quarter" }, new[] { "z" }, pvtData);
			var prevYearDiffRowPvtTbl = new DifferencePivotTable(rowPvtTbl, 
					(diffValContext) => {
						// lets calculate diff from 'prev year' value
						var rowIdx = diffValContext.RowKeyIndex;
						if (rowIdx >= 0) {
							var yearKey = diffValContext.BasePivotTable.RowKeys[rowIdx].DimKeys[0];
							var quarterKey = diffValContext.BasePivotTable.RowKeys[rowIdx].DimKeys[1];
							if (yearKey!=null) {
								var prevYear = Convert.ToInt32(yearKey)-1;
								var fromValRowKey = new ValueKey(prevYear, quarterKey);
								if (diffValContext.RowKeyExists(fromValRowKey))
									return diffValContext.BasePivotTable.GetValue(fromValRowKey, diffValContext.ColumnKey);
							}
						}
						return null; // no 'from' value
					}, 0);
			AssertPivotTableEqual(
				new object[][] {
					new object[] { null, null, null, null, 3M, 5M, -1M },
				}, prevYearDiffRowPvtTbl);

			var colPvtTbl = new PivotTable(new[] { "z" }, new[] { "year", "quarter" }, pvtData);
			var prevYearDiffColPvtTbl = new DifferencePivotTable(colPvtTbl,
					(diffValContext) => {
						// lets calculate diff from 'prev year' value
						var colIdx = diffValContext.ColumnKeyIndex;
						if (colIdx >= 0) {
							var yearKey = diffValContext.BasePivotTable.ColumnKeys[colIdx].DimKeys[0];
							var quarterKey = diffValContext.BasePivotTable.ColumnKeys[colIdx].DimKeys[1];
							if (yearKey != null) {
								var prevYear = Convert.ToInt32(yearKey) - 1;
								var fromValColKey = new ValueKey(prevYear, quarterKey);
								if (diffValContext.ColumnKeyExists(fromValColKey))
									return diffValContext.BasePivotTable.GetValue(diffValContext.RowKey, fromValColKey);
							}
						}
						return null; // no 'from' value
					}, 0);

			AssertPivotTableEqual(
				new object[][] {
					new object[] { null },
					new object[] { null },
					new object[] { null },
					new object[] { null },
					new object[] { 3M },
					new object[] { 5M },
					new object[] { -1M }
				}, prevYearDiffColPvtTbl);
		}


	}
}
