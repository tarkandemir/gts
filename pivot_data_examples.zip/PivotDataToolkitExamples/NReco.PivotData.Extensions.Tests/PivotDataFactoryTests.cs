﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xunit;

namespace NReco.PivotData.Extensions.Tests
{
    public class PivotDataFactoryTests
    {

		[Fact]
		public void CreateTest() {
			var pvtDataFactory = new PivotDataFactory();

			var simpleAggrCfg = new PivotDataConfiguration() {
				LazyTotals = true,
				Dimensions = new [] { "dim1", "dim2" },
				Aggregators = new [] { new  AggregatorFactoryConfiguration() {
					Name = "Sum",
					Params = new object[] { "dim3"}
				} }
			};

			var pvtData1 = pvtDataFactory.Create(simpleAggrCfg);

			Assert.True(pvtData1.LazyTotals);
			Assert.Equal(2, pvtData1.Dimensions.Length);
			Assert.True( pvtData1.AggregatorFactory is SumAggregatorFactory );
			Assert.Equal( "dim3", ((SumAggregatorFactory)pvtData1.AggregatorFactory).Field );

			var compositeAggrCfg = new PivotDataConfiguration() {
				Dimensions = new [] {"a1", "a2", "a3"},
				Aggregators = new [] {
					 new AggregatorFactoryConfiguration() {
						 Name = "Count"
					 },
					 new AggregatorFactoryConfiguration() {
						 Name = "Average",
						 Params = new object[] {"a4"}
					 }
				}
			};
			var pvtData2 = pvtDataFactory.Create(compositeAggrCfg);
			Assert.Equal(3, pvtData2.Dimensions.Length);
			Assert.True( pvtData2.AggregatorFactory is CompositeAggregatorFactory );
			Assert.True( ((CompositeAggregatorFactory)pvtData2.AggregatorFactory).Factories[0] is CountAggregatorFactory );
			Assert.True( ((CompositeAggregatorFactory)pvtData2.AggregatorFactory).Factories[1] is AverageAggregatorFactory );
		}

		[Fact]
		public void GetConfigurationTest() {
			var pvtFactory = new PivotDataFactory();

			var pvtData1 = new PivotData(new [] {"bla1"}, new CountAggregatorFactory(), true);
			var pvt1Cfg = pvtFactory.GetConfiguration(pvtData1);

			Assert.True(pvt1Cfg.LazyTotals);
			Assert.Equal("bla1", pvt1Cfg.Dimensions[0]);
			Assert.Equal("Count", pvt1Cfg.Aggregators[0].Name);

			var pvtData2 = new PivotData(new [] {"bla1"},
				new CompositeAggregatorFactory(
					new IAggregatorFactory[] {
						new CountUniqueAggregatorFactory("f1"),
						new MinAggregatorFactory("f2")
					}
				) );
			var pvt2Cfg = pvtFactory.GetConfiguration(pvtData2);
			Assert.Equal(2, pvt2Cfg.Aggregators.Length);
			Assert.Equal("f1", pvt2Cfg.Aggregators[0].Params[0]);

		}

    }
}
