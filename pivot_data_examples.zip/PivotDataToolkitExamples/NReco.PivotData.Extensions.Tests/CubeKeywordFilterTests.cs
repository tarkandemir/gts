﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

using NReco.PivotData.Input;
using NReco.PivotData.Output;
using Xunit;

namespace NReco.PivotData.Extensions.Tests {
	
	public class CubeKeywordFilterTests {

		PivotData getTestCube(bool withEmpty = false) {
			var pvtData = new PivotData(new[] {"a","d","f"}, new CompositeAggregatorFactory(
				new IAggregatorFactory[] { 
					new CountAggregatorFactory(),
					new AverageAggregatorFactory("b"),
					new MaxAggregatorFactory("c")
				}
			), true);
			pvtData.ProcessData(
				withEmpty ? DataUtils.getSampleDataWithNullAndEmpty(1000) : DataUtils.getSampleData(1000),
				DataUtils.getProp);
			return pvtData;
		}

		[Fact]
		public void SimpleMatches() {

			var pvtData = getTestCube();

			// by single full-match keyword
			var flt1 = new CubeKeywordFilter("val1");
			var flt1PvtData = flt1.Filter(pvtData);
			Assert.Equal(1, flt1PvtData.GetDimensionKeys()[0].Length );
			Assert.Equal("val1", flt1PvtData.GetDimensionKeys()[0][0] );
			
			// by single like-match keyword
			var flt2 = new CubeKeywordFilter("val");
			var flt2PvtData = flt2.Filter(pvtData); // doesn't filter anything
			Assert.Equal(3, flt2PvtData.GetDimensionKeys()[0].Length );
			Assert.Equal(pvtData.Count, flt2PvtData.Count );
			
			// by 2 full-match keywords for the same dimension
			var flt3 = new CubeKeywordFilter("val1, val2");
			var flt3PvtData = flt3.Filter(pvtData);
			Assert.Equal(2, flt3PvtData.GetDimensionKeys()[0].Length );
			Assert.Equal("val1", flt3PvtData.GetDimensionKeys()[0][0] );
			Assert.Equal("val2", flt3PvtData.GetDimensionKeys()[0][1] );
			flt3 = new CubeKeywordFilter("val1 val2");
			flt3PvtData = flt3.Filter(pvtData);
			Assert.Equal(2, flt3PvtData.GetDimensionKeys()[0].Length);

			// by 3 full-match keywords for the same dimension
			var flt4 = new CubeKeywordFilter("val3, 99, 98");
			var flt4PvtData = flt4.Filter(pvtData);
			Assert.Equal(1, flt4PvtData.GetDimensionKeys()[0].Length );
			Assert.Equal(2, flt4PvtData.GetDimensionKeys()[1].Length );

		}

		[Fact]
		public void AndMatches() {
			var pvtData = getTestCube();

			// by single and-pair full-and-like-match keyword
			var flt1 = new CubeKeywordFilter("val1+alpha");
			var flt1PvtData = flt1.Filter(pvtData);
			Assert.Equal(1, flt1PvtData.GetDimensionKeys()[0].Length );
			Assert.Equal(2, flt1PvtData.GetDimensionKeys()[2].Length );

			// by single and-pair full-match keyword
			var flt2 = new CubeKeywordFilter("val1 + test alpha");
			var flt2PvtData = flt2.Filter(pvtData);
			Assert.Equal(1, flt2PvtData.GetDimensionKeys()[0].Length );
			Assert.Equal(1, flt2PvtData.GetDimensionKeys()[2].Length );
			flt2 = new CubeKeywordFilter("val1+\"test alpha\"");
			flt2PvtData = flt2.Filter(pvtData);
			Assert.Equal(1, flt2PvtData.GetDimensionKeys()[0].Length);
			Assert.Equal(1, flt2PvtData.GetDimensionKeys()[2].Length);

			var flt3 = new CubeKeywordFilter("test*+");
			var flt3PvtData = flt3.Filter(pvtData);
			Assert.Equal(4, flt3PvtData.GetDimensionKeys()[2].Length );

			var flt4 = new CubeKeywordFilter("+test*");
			var flt4PvtData = flt4.Filter(pvtData);
			Assert.Equal(4, flt4PvtData.GetDimensionKeys()[2].Length );
		}

		[Fact]
		public void ExcludeMatches() {
			var pvtData = getTestCube();

			// by single exclude full-match keyword
			var flt1 = new CubeKeywordFilter("-val1");
			var flt1PvtData = flt1.Filter(pvtData);
			Assert.Equal(2, flt1PvtData.GetDimensionKeys()[0].Length );
			Assert.Equal("val2", flt1PvtData.GetDimensionKeys()[0][0] );
			Assert.Equal("val3", flt1PvtData.GetDimensionKeys()[0][1] );

			// by single exclude full-match 2-words phrase
			var flt2 = new CubeKeywordFilter("-\"test alpha\"");
			var flt2PvtData = flt2.Filter(pvtData);
			Assert.Equal(4, flt2PvtData.GetDimensionKeys()[2].Length );

			// by singe exclude like-match
			var flt3 = new CubeKeywordFilter("-\"alpha\"");
			var flt3PvtData = flt3.Filter(pvtData);
			Assert.Equal(3, flt3PvtData.GetDimensionKeys()[2].Length );

			// by single match that shouldn't exclude anything
			var flt4 = new CubeKeywordFilter("-\"alpha2\"");
			var flt4PvtData = flt4.Filter(pvtData);
			Assert.Equal(pvtData.Count, flt4PvtData.Count);

		}

		[Fact]
		public void LikeMatches() {
			var pvtData = getTestCube();

			var flt1 = new CubeKeywordFilter("*eta");
			var flt1PvtData = flt1.Filter(pvtData);
			Assert.Equal(1, flt1PvtData.GetDimensionKeys()[2].Length );

			var flt2 = new CubeKeywordFilter("*alpha");
			var flt2PvtData = flt2.Filter(pvtData);
			Assert.Equal(2, flt2PvtData.GetDimensionKeys()[2].Length );

			var flt3 = new CubeKeywordFilter("test*");
			var flt3PvtData = flt3.Filter(pvtData);
			Assert.Equal(4, flt3PvtData.GetDimensionKeys()[2].Length );
		}

		[Fact]
		public void HintMatches() {
			var pvtData = getTestCube();

			var flt1 = new CubeKeywordFilter("f:val1");
			var flt1PvtData = flt1.Filter(pvtData);
			Assert.Equal(1, flt1PvtData.GetDimensionKeys()[2].Length );
			Assert.Equal("val1 test", flt1PvtData.GetDimensionKeys()[2][0] );
			Assert.Equal(3, flt1PvtData.GetDimensionKeys()[0].Length );

			var flt2 = new CubeKeywordFilter("*test*+-f:val1*"); // contains 'test' and not starts with 'val1'
			var flt2PvtData = flt2.Filter(pvtData);
			Assert.Equal(4, flt2PvtData.GetDimensionKeys()[2].Length );

			var flt3 = new CubeKeywordFilter(" \"f\":\"val1\"");
			Assert.Equal(flt1PvtData.Count, flt3.Filter(pvtData).Count);

			var flt4 = new CubeKeywordFilter(" \"a\":\"val1\"");
			Assert.Equal(334U, flt4.Filter(pvtData)["val1", Key.Empty, Key.Empty].AsComposite().Aggregators[0].Value);
			var flt5 = new CubeKeywordFilter(" \"a\"=\"val1\"");
			Assert.Equal(334U, flt5.Filter(pvtData)["val1", Key.Empty, Key.Empty].AsComposite().Aggregators[0].Value);

			var flt6 = new CubeKeywordFilter(" \"d\"<50");
			Assert.Equal(500U, flt6.Filter(pvtData)[Key.Empty, Key.Empty, Key.Empty].AsComposite().Aggregators[0].Value);

			var flt7 = new CubeKeywordFilter(" \"a\"<>\"val1\"");
			Assert.Equal(666U, flt7.Filter(pvtData)[Key.Empty, Key.Empty, Key.Empty].AsComposite().Aggregators[0].Value);

		}

		[Fact]
		public void TestEmptyMatches() {
			var pvtData = getTestCube(true);

			var flt1 = new CubeKeywordFilter("a:\"\"");
			Assert.Equal( 
				new SliceQuery(pvtData).Where("a", v=>v==null || DBNull.Value.Equals(v)).Execute().Count, 
				flt1.Filter(pvtData).Count);

			var flt2 = new CubeKeywordFilter("\" \""); // match any key with space. this can be only in "f" dim
			Assert.Equal(
				new SliceQuery(pvtData).Where("f", v => v.ToString().IndexOf(" ")>=0 ).Execute().Count,
				flt2.Filter(pvtData).Count);

			var flt3 = new CubeKeywordFilter("-a:\"\"");  // not for a
			Assert.Equal(
				new SliceQuery(pvtData).Where("a", v => v != null && !DBNull.Value.Equals(v)).Execute().Count,
				flt3.Filter(pvtData).Count);

			var flt4 = new CubeKeywordFilter("-\"\"");  // not for any null, empty or whitespace string
			Assert.Equal(
				new SliceQuery(pvtData).Where( entry => {
					return DBNull.Value.Equals(entry.Key[0]) || String.IsNullOrWhiteSpace(entry.Key[2] as string);
				}).Execute().Count,
				flt4.Filter(pvtData).Count);

		}

		[Fact]
		public void TestMeasureConditions() {
			var pvtData = getTestCube();

			var flt1 = new CubeKeywordFilter("count>0");
			Assert.Equal(pvtData.Count, flt1.Filter(pvtData).Count);

			var flt2 = new CubeKeywordFilter("count>3");
			Assert.Equal(100, flt2.Filter(pvtData).Count);

			var flt3 = new CubeKeywordFilter("count>3, average>500");  // count>3 OR average>500
			Assert.Equal(199, flt3.Filter(pvtData).Count);

			var flt4 = new CubeKeywordFilter("count>3 + average>500");  // count>3 AND average>500
			Assert.Equal(49, flt4.Filter(pvtData).Count);

			var flt5 = new CubeKeywordFilter("count<>3");
			Assert.Equal(100, flt5.Filter(pvtData).Count);

			var flt6 = new CubeKeywordFilter(">3");  // no hint, assumed as first measure (this is count in pvtData)
			Assert.Equal(100, flt6.Filter(pvtData).Count);

			var flt7 = new CubeKeywordFilter("\"count\">3");
			Assert.Equal(100, flt7.Filter(pvtData).Count);

			var flt8 = new CubeKeywordFilter("count>3 average>500");  // count>3 OR average>500
			Assert.Equal(199, flt8.Filter(pvtData).Count);

		}

		[Fact]
		public void TestParse() {
			var flt = new CubeKeywordFilter("year:2018+name:John*, age>20");
			var parseRes = flt.Parse();
			Assert.Equal(2, parseRes.Count());
			Assert.Equal("year", parseRes.First().Hint);
			Assert.Equal("John", parseRes.First().AndKeywords.First().Keyword);
			Assert.False(parseRes.First().AndKeywords.First().StartLike);
			Assert.True(parseRes.First().AndKeywords.First().EndLike);
			Assert.Equal( CubeKeywordFilter.HintConditionType.GreaterThan , parseRes.Skip(1).First().HintCondition);
		}

	}
}
