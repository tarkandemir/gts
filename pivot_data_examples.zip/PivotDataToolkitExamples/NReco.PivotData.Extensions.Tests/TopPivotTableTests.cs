﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using NReco.PivotData.Output;
using System.Xml;

using Xunit;

namespace NReco.PivotData.Extensions.Tests
{
    public class TopPivotTableTests
    {

		PivotTable createPvtTbl1() {
			var pvtData = new PivotData(new[] {"a","d"}, new CountAggregatorFactory());
			pvtData.ProcessData( DataUtils.getSampleData(10000), DataUtils.getProp);
			return new PivotTable(new[]{"a"}, new[]{"d"}, pvtData);
		}

		PivotTable createPvtTbl2() {
			var pvtData = new PivotData(new[] {"a","b","d"}, new CountAggregatorFactory());
			pvtData.ProcessData( DataUtils.getSampleData(10000), DataUtils.getProp);
			return new PivotTable(new[]{"d"}, new[]{"a", "b"}, pvtData);
		}

		[Fact]
		public void TopSimplePivotTableTest() {
			var pvtTbl = createPvtTbl1();

			var topPvtTbl = new TopPivotTable(pvtTbl, 2, 50);

			Assert.Equal(3, topPvtTbl.RowKeys.Length );  // top 2 + other group
			Assert.Equal(51, topPvtTbl.ColumnKeys.Length );  // top 50 + other group

			// ensure that totals are unchanged
			Assert.Equal( pvtTbl.GetValue(null,null).Value, topPvtTbl.GetValue(null,null).Value );

			// check other group value
			Assert.True( topPvtTbl.RowKeys[2].DimKeys[0] is TopPivotTable.OtherKey );
			Assert.Equal( pvtTbl.GetValue( pvtTbl.RowKeys[2], null ).Value, topPvtTbl.GetValue( pvtTbl.RowKeys[2], null ).Value );

			// top pivot table without other groups
			var topWithoutOtherPvtTbl = new TopPivotTable(pvtTbl, 2, 3) { 
				IncludeOtherGroups = false 
			};
			Assert.Equal(2, topWithoutOtherPvtTbl.RowKeys.Length );
			Assert.Equal(3, topWithoutOtherPvtTbl.ColumnKeys.Length);
			Assert.Equal(pvtTbl.GetValue(null,null).Value, topWithoutOtherPvtTbl.GetValue(null,null).Value );
		}

		[Fact]
		public void TopGroupedPivotTableTest() {
			var pvtTbl = createPvtTbl2();

			var topPvtTbl = new TopPivotTable(pvtTbl, 50, 100);

			Assert.Equal(51, topPvtTbl.RowKeys.Length );  // top 50 + other group
			Assert.Equal(102, topPvtTbl.ColumnKeys.Length );  // top 100 + 2 other groups 
			// ensure that totals are unchanged
			Assert.Equal( pvtTbl.GetValue(null,null).Value, topPvtTbl.GetValue(null,null).Value );
			// check other groups
			Assert.Equal(33U, topPvtTbl.GetValue(topPvtTbl.RowKeys[0], topPvtTbl.ColumnKeys[100] /*101-th*/).Value);
			Assert.Equal(66U, topPvtTbl.GetValue(topPvtTbl.RowKeys[0], topPvtTbl.ColumnKeys[101] /*102-th*/).Value);
			Assert.Equal(3333U, topPvtTbl.GetValue(topPvtTbl.RowKeys[50/*51-th*/], topPvtTbl.ColumnKeys[101] /*102-th*/).Value);

			// test export
			var strWr = new StringWriter();
			var pvtHtmlWr = new PivotTableHtmlWriter(strWr);
			pvtHtmlWr.Write(topPvtTbl);
			var xmlDoc1 = new XmlDocument();
			xmlDoc1.LoadXml(strWr.ToString());
			Assert.Equal(4, xmlDoc1.SelectNodes("/table//th[@data-key-type='other']").Count ); // 3 cells on cols + 1 on rows
		}

		[Fact]
		public void TopLastPivotTableTest() {
			var pvtTbl = createPvtTbl2();

			var topPvtTbl = new TopPivotTable(pvtTbl, 50, 100) {
				RowTopMode = TopPivotTable.TopMode.Last,
				ColumnTopMode = TopPivotTable.TopMode.Last
			};

			Assert.Equal(51, topPvtTbl.RowKeys.Length );  // top 50 + other group
			Assert.Equal(102, topPvtTbl.ColumnKeys.Length );  // top 100 + 2 other groups 
			// check last keys
			Assert.Equal(99, topPvtTbl.RowKeys[50/*51-th*/].DimKeys[0] );
			Assert.Equal(9998, topPvtTbl.ColumnKeys[101/*102-th*/].DimKeys[1]);

			// check other groups
			Assert.Equal(3334U, topPvtTbl.GetValue(topPvtTbl.RowKeys[0], topPvtTbl.ColumnKeys[0]).Value);
			Assert.Equal(1616U, topPvtTbl.GetValue(topPvtTbl.RowKeys[0], topPvtTbl.ColumnKeys[1]).Value);
			Assert.Equal(66U, topPvtTbl.GetValue(topPvtTbl.RowKeys[1], topPvtTbl.ColumnKeys[0]).Value);

			// test export
			/*var strWr = new StringWriter();
			var pvtHtmlWr = new PivotTableHtmlWriter(strWr);
			pvtHtmlWr.Write(topPvtTbl);
			Console.WriteLine(strWr.ToString());*/

		}

	}
}
