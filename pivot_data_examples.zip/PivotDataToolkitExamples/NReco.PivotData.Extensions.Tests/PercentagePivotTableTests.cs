﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xunit;

namespace NReco.PivotData.Extensions.Tests
{
    public class PercentagePivotTableTests
    {

		PivotTable createPvtTbl() {
			var pvtData = new PivotData(new[] {"a","d"}, new CountAggregatorFactory());
			pvtData.ProcessData( DataUtils.getSampleData(10000), DataUtils.getProp);
			return new PivotTable(new[]{"a"}, new[]{"d"}, pvtData);
		}

		[Fact]
		public void PercentageByGrandTotalTest() {
			var pvtTbl = createPvtTbl();

			var percentPvtTbl = new PercentagePivotTable(pvtTbl, PercentagePivotTable.PercentageMode.GrandTotal);
			Assert.Equal(100M, percentPvtTbl.GetValue(null,null).Value );

			Assert.Equal(33M, Math.Round( (decimal)percentPvtTbl.GetValue( percentPvtTbl.RowKeys[0], null ).Value ) );

			Assert.Equal(0.34M, Math.Round( (decimal)percentPvtTbl.GetValue( percentPvtTbl.RowKeys[0], percentPvtTbl.ColumnKeys[0] ).Value, 2 ) );
		}

		[Fact]
		public void PercentageByColumnTotalTest() {
			var pvtTbl = createPvtTbl();

			var percentPvtTbl = new PercentagePivotTable(pvtTbl, PercentagePivotTable.PercentageMode.ColumnTotal);
			Assert.Equal(100M, percentPvtTbl.GetValue(null,null).Value );

			Assert.Equal(100M, Math.Round( (decimal)percentPvtTbl.GetValue( null, percentPvtTbl.ColumnKeys[0] ).Value ) );

			Assert.Equal(34M, Math.Round( (decimal)percentPvtTbl.GetValue( percentPvtTbl.RowKeys[0], percentPvtTbl.ColumnKeys[0] ).Value, 2 ) );
			Assert.Equal(33M, Math.Round( (decimal)percentPvtTbl.GetValue( percentPvtTbl.RowKeys[1], percentPvtTbl.ColumnKeys[0] ).Value, 2 ) );
			Assert.Equal(33M, Math.Round( (decimal)percentPvtTbl.GetValue( percentPvtTbl.RowKeys[1], percentPvtTbl.ColumnKeys[0] ).Value, 2 ) );
		}


		[Fact]
		public void PercentageByRowTotalTest() {
			var pvtTbl = createPvtTbl();

			var percentPvtTbl = new PercentagePivotTable(pvtTbl, PercentagePivotTable.PercentageMode.RowTotal);
			Assert.Equal(100M, percentPvtTbl.GetValue(null,null).Value );

			Assert.Equal(100M, Math.Round( (decimal)percentPvtTbl.GetValue(  percentPvtTbl.RowKeys[0], null ).Value ) );

			Assert.Equal(1M, Math.Round( (decimal)percentPvtTbl.GetValue( percentPvtTbl.RowKeys[0], percentPvtTbl.ColumnKeys[0] ).Value ) );
			Assert.Equal(1M, Math.Round( (decimal)percentPvtTbl.GetValue( percentPvtTbl.RowKeys[0], percentPvtTbl.ColumnKeys[99] ).Value ) );
		}

		[Fact]
		public void PercentageByNegativeAndZeroTest() {
			var pivotDataState = new PivotDataState(2,
				new object[] { "A1", "A2", "B1", "B2" },
				new uint[][] {
					new uint[] { 0, 2 },
					new uint[] { 1, 2 },
					new uint[] { 0, 3 }
				},
				new object[] {
					new object[] { (uint)1, (int)-10 },
					new object[] { (uint)1, (int)5 },
					new object[] { (uint)1, (int)0 }
				}
			);
			var pvtData = new PivotData(new[] { "A", "B" }, new SumAggregatorFactory("v"));
			pvtData.SetState(pivotDataState);
			var pvtTbl = new PivotTable(new[] { "A" }, new[] { "B" }, pvtData);
			Assert.Equal(-5M, pvtTbl[null, 0].Value);
			Assert.Equal(0M, pvtTbl[null, 1].Value);

			var percentPvtTbl = new PercentagePivotTable(pvtTbl, PercentagePivotTable.PercentageMode.ColumnTotal);
			Assert.Equal(200M, percentPvtTbl.GetValue(percentPvtTbl.RowKeys[0], percentPvtTbl.ColumnKeys[0]).Value);
			Assert.Equal(-100M, percentPvtTbl.GetValue(percentPvtTbl.RowKeys[1], percentPvtTbl.ColumnKeys[0]).Value);
			Assert.Equal(100M, percentPvtTbl.GetValue(null, percentPvtTbl.ColumnKeys[0]).Value);
			Assert.Null(percentPvtTbl.GetValue(null, percentPvtTbl.ColumnKeys[1]).Value);
		}

		[Fact]
		public void PercentageWithCustomBaseTest() {
			var pvtData = new PivotData(new[] { "year", "quarter" }, new SumAggregatorFactory("val"));
			pvtData.ProcessData(new object[] {
				new { year = 2016, quarter = "Q2", val = 7 },
				new { year = 2016, quarter = "Q3", val = 6 },
				new { year = 2016, quarter = "Q4", val = 10 },
				new { year = 2017, quarter = "Q1", val = 9 },
				new { year = 2017, quarter = "Q2", val = 10 },
				new { year = 2017, quarter = "Q3", val = 11 },
				new { year = 2017, quarter = "Q4", val = 9 }
			}, new ObjectMember().GetValue);

			var pvtTbl = new PivotTable(new[] { "year", "quarter" }, null, pvtData);
			var percentPvtTbl = new PercentagePivotTable(pvtTbl,
					(cell) => {
						var parentRowKey = new ValueKey(cell.RowKey.DimKeys[0], Key.Empty);
						return cell.BasePivotTable.GetValue(parentRowKey, cell.ColumnKey);
					}, 0);

			Assert.Equal(30, Math.Round(Convert.ToDouble(percentPvtTbl.GetValue(new ValueKey(2016, "Q2"), null).Value ) ) );
			Assert.Equal(23, Math.Round(Convert.ToDouble(percentPvtTbl.GetValue(new ValueKey(2017, "Q1"), null).Value)));
			Assert.Equal(100, Math.Round(Convert.ToDouble(percentPvtTbl.GetValue(new ValueKey(2017, Key.Empty), null).Value)));
		}


	}
}
