﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Xml;
using System.Data;

using Xunit;

using NReco.PivotData.Output;
using OfficeOpenXml;
using Newtonsoft.Json;
using Xunit.Abstractions;
using System.Diagnostics;

namespace NReco.PivotData.Extensions.Tests.Output {
	
	public class PivotTableWriterTests {

		ITestOutputHelper Output;

		public PivotTableWriterTests(ITestOutputHelper output) {
			Output = output;
		}

		[Fact]
		public void HtmlWriterTest() {
			var pvtData = new PivotData(new[] {"a","b","e","f"}, new CountAggregatorFactory(), true);
			pvtData.ProcessData( DataUtils.getSampleData(1000), DataUtils.getProp);
			var pvtTbl = new PivotTable(new[]{"a"},null,pvtData);

			var xmlDoc = new XmlDocument();
			xmlDoc.LoadXml( ToHtml(pvtTbl, (htmlWr) => { }) );
			RemoveTrialTr(xmlDoc);
			Assert.Equal(5,  xmlDoc.SelectNodes("/table/tr").Count);
			Assert.Equal(4,  xmlDoc.SelectNodes("/table/tr/td").Count);
			Assert.Equal(6,  xmlDoc.SelectNodes("/table/tr/th").Count);
			Assert.Equal(1000, Convert.ToInt32( xmlDoc.SelectSingleNode("(//td)[last()]").InnerText ) );

			// test for 2 measures
			var pvtData2 = new PivotData(new[] {"a","b","e","f"}, 
				new CompositeAggregatorFactory( new MinAggregatorFactory("d"), new MaxAggregatorFactory("d") ),
				true);
			pvtData2.ProcessData( DataUtils.getSampleData(1000), DataUtils.getProp);
			
			var pvtTbl2 = new PivotTable(new[]{"a"},null,pvtData2);
			var xmlDoc2 = new XmlDocument();
			xmlDoc2.LoadXml( ToHtml(pvtTbl2, (htmlWr) => { 
				htmlWr.RenderDimensionLabel = PivotTableHtmlWriter.RenderDimensionLabelType.NoLabels;
				htmlWr.FormatValue = (aggr, idx) => String.Format( System.Globalization.CultureInfo.InvariantCulture, "{0:0.##}", aggr.Value);
			}) );
			RemoveTrialTr(xmlDoc2);

			// no columns and multiple measures = first row with "totals" is excluded
			//Assert.Equal(2,  xmlDoc2.SelectNodes("/table/tr[position()=1]/th").Count);
			// row for row header (a - but no label b/c 'RenderDimensionLabel') + measure headers for totals (3)
			Assert.Equal(3,  xmlDoc2.SelectNodes("/table/tr[position()=1]/th").Count);
			Assert.Equal(8,  xmlDoc2.SelectNodes("/table//td").Count);
			Assert.Equal(6,  xmlDoc2.SelectNodes("/table//th[@class]").Count);
			Assert.Equal("0", xmlDoc2.SelectSingleNode("/table//td[@class='totalValue pvtMeasure0']").InnerText );
			Assert.Equal("99", xmlDoc2.SelectSingleNode("/table//td[@class='totalValue pvtMeasure1']").InnerText);

			// test for dimension labels
			var pvtTbl3 = new PivotTable(new[]{"a"}, new[] {"b"},pvtData2);
			var xmlDoc3 = new XmlDocument();
			xmlDoc3.LoadXml( ToHtml(pvtTbl3, (htmlWr) => {
				htmlWr.RenderDimensionLabel = PivotTableHtmlWriter.RenderDimensionLabelType.ColumnAndRowLabels;	
			}));
			RemoveTrialTr(xmlDoc3);
			Assert.True( String.IsNullOrEmpty( xmlDoc3.SelectSingleNode("/table/tr[position()=1]/th[position()=1]").InnerText ) );

			Assert.Equal( "b", xmlDoc3.SelectSingleNode("/table/tr[position()=1]/th[position()=2]").InnerText );
			Assert.Equal( "a", xmlDoc3.SelectSingleNode("/table/tr[position()=2]/th[position()=1]").InnerText );
			Assert.Equal(2,  xmlDoc3.SelectNodes("/table//th[@class='pvtColumnLabel' or @class='pvtRowLabel']").Count);
			Assert.Equal(1000,  xmlDoc3.SelectNodes("/table//th[@class='pvtColumn']").Count);
			Assert.Equal(8008,  xmlDoc3.SelectNodes("/table//td").Count);
			
			// subtotals tests
			// 1) all dims, 1 aggr
			var pvtTbl4 = new PivotTable(new[]{"a", "e"}, new[] {"f"},pvtData);
			var xmlDoc4 = new XmlDocument();
			xmlDoc4.LoadXml( ToHtml(pvtTbl4, (htmlWr) => {
				htmlWr.SubtotalRows = true;	
			}));
			RemoveTrialTr(xmlDoc4);

			Assert.Equal(3,  xmlDoc4.SelectNodes("/table//th[@class='pvtRow' and @rowspan='2']").Count);
			Assert.Equal(4,  xmlDoc4.SelectNodes("/table//th[@colspan='3']").Count);  // 3 subtotals + total
			Assert.Equal(60,  xmlDoc4.SelectNodes("/table//td").Count);

			// 2) all dims, 2 aggr
			var pvtTbl5 = new PivotTable(new[]{"a", "e", "f"}, new string[] {},pvtData);
			var xmlDoc5 = new XmlDocument();
			xmlDoc5.LoadXml( ToHtml(pvtTbl5, (htmlWr) => {
				htmlWr.SubtotalRows = true;	
				htmlWr.SubtotalDimensions = new[] {"a"};
			}));
			RemoveTrialTr(xmlDoc5);
			Assert.Equal(39, xmlDoc5.SelectNodes("/table//th[@class='pvtRow']").Count);
			Assert.Equal(4,  xmlDoc5.SelectNodes("/table//th[@colspan='4']").Count);  // 3 subtotals + total
			// 3) one dim for subtotals, 2 aggr
			var pvtTbl6 = new PivotTable(new string[] {}, new[]{"a", "e", "f"},pvtData2);
			var xmlDoc6 = new XmlDocument();
			xmlDoc6.LoadXml( ToHtml(pvtTbl6, (htmlWr) => {
				htmlWr.SubtotalColumns = true;	
				htmlWr.SubtotalDimensions = new[] {"a"};
			}));
			RemoveTrialTr(xmlDoc6);
			Assert.Equal(39, xmlDoc6.SelectNodes("/table//th[@class='pvtColumn']").Count);
			Assert.Equal(4,  xmlDoc6.SelectNodes("/table//th[@rowspan='3']").Count);  // 3 subtotals
			Assert.Equal(68,  xmlDoc6.SelectNodes("/table//td").Count);
			Assert.Equal(68,  xmlDoc6.SelectNodes("/table//th[contains(@class, 'pvtMeasure')]").Count);

			// test for composite aggr with single entry
			var pvtData3 = new PivotData(new[] { "a", "b"},
				new CompositeAggregatorFactory(new CountAggregatorFactory()) );
			pvtData3.ProcessData(DataUtils.getSampleData(1000), DataUtils.getProp);
			var pvtTbl7 = new PivotTable(new[] { "a" }, new[] { "b" }, pvtData3);
			var xmlDoc7 = new XmlDocument();
			xmlDoc7.LoadXml(ToHtml(pvtTbl7, (htmlWr) => { }));
			RemoveTrialTr(xmlDoc7);
			Assert.Equal("1", xmlDoc7.SelectSingleNode("/table//td").InnerText);
		}

		[Fact]
		public void HtmlWriterPerformance_Test() {
			var pvtData = new PivotData(new[] { "a", "b", "e", "f", "d" }, new CountAggregatorFactory(), true);
			pvtData.ProcessData(DataUtils.getSampleData(5000), DataUtils.getProp);
			var pvtTbl = new PivotTable(new[] { "b" }, new[] {"a", "f", "e", "d"}, pvtData);
			Output.WriteLine($"Pivot table size: {pvtTbl.RowKeys.Length}x{pvtTbl.ColumnKeys.Length}");

			var sw = new Stopwatch();
			sw.Start();

			for (int i = 0; i < 10; i++) {
				var html = ToHtml(pvtTbl, (wr) => {
					wr.SubtotalColumns = true;
					wr.SubtotalRows = true;
					wr.GrandTotal = true;
					wr.TotalsColumn = true;
					wr.TotalsRow = true;
				});
			}
			sw.Stop();
			Output.WriteLine("ProcessData: {0}", sw.Elapsed);
		}

		void RemoveTrialTr(XmlDocument xmlDoc) {
			var lastTr = xmlDoc.SelectSingleNode("/table/tr[last()]");
			if (lastTr.InnerText.IndexOf("Trial") >= 0)
				lastTr.ParentNode.RemoveChild(lastTr);
		}

		[Fact]
		public void HtmlWriter_RepeatKeysTest() {
			var pvtData = new PivotData(new[]{"a","b","c","d"}, new CountAggregatorFactory() );
			var inputData = new List<object>();
			for (int i = 0; i < 100; i++) {
				inputData.Add( new { a = 1, b = 1, c = i%10, d = i%20 });
			}
			pvtData.ProcessData(inputData, DataUtils.getProp);

			Action<PivotTable,string, int, int, int> check = (pvtTbl, thCssClass, defaultCnt, repeatKeysCnt, repeatDupKeysAcrossDimCnt) => {
				var xmlDoc1 = new XmlDocument();
				xmlDoc1.LoadXml( ToHtml(pvtTbl, (htmlWr) => { }) );
				RemoveTrialTr(xmlDoc1);
				Assert.Equal(defaultCnt, xmlDoc1.SelectNodes("/table//th[@class='"+thCssClass+"']").Count);

				var xmlDoc2 = new XmlDocument();
				xmlDoc2.LoadXml( ToHtml(pvtTbl, 
					(htmlWr) => { htmlWr.RepeatKeysInGroups = RepeatDimensionKeyType.ColumnsAndRows; }) );
				RemoveTrialTr(xmlDoc2);
				Assert.Equal(repeatKeysCnt, xmlDoc2.SelectNodes("/table//th[@class='"+thCssClass+"']").Count);

				var xmlDoc3 = new XmlDocument();
				xmlDoc3.LoadXml( ToHtml(pvtTbl, 
					(htmlWr) => { htmlWr.RepeatDuplicateKeysAcrossDimensions = RepeatDimensionKeyType.No; }) );
				RemoveTrialTr(xmlDoc3);
				Assert.Equal(repeatDupKeysAcrossDimCnt, xmlDoc3.SelectNodes("/table//th[@class='"+thCssClass+"']").Count);
			};

			// check cols
			check( new PivotTable(new[]{"d"}, new[]{"a","b","c"}, pvtData ), "pvtColumn", 12, 30, 11 );
			check( new PivotTable(new[]{"d"}, new[]{"c","a","b"}, pvtData ), "pvtColumn", 30, 30, 19 );
			check( new PivotTable(new[]{"d"}, new[]{"a","c","b"}, pvtData ), "pvtColumn", 21, 30, 20 );

			// check rows
			check( new PivotTable(new[]{"a","b","c"}, new[]{"d"}, pvtData ), "pvtRow", 12, 30, 11 );
			check( new PivotTable(new[]{"c","a","b"}, new[]{"d"}, pvtData ), "pvtRow", 30, 30, 19 );
			check( new PivotTable(new[]{"a","c","b"}, new[]{"d"}, pvtData ), "pvtRow", 21, 30, 20 );
		}

		[Fact]
		public void HtmlWriter_ExpandCollapse() {
			var pvtData = new PivotData(new[] { "c1", "c2", "c3", "r1", "r2" }, new CountAggregatorFactory());
			var inputData = new List<object>();
			for (int i = 0; i < 5000; i++) {
				inputData.Add(new { c1 = $"C1_{i%2}", c2 = $"C2_{i%3}", c3 = $"C3_{i%10}", r1 = $"R1_{i%3}", r2 = $"R2_{i%6}" });
			}
			pvtData.ProcessData(inputData, DataUtils.getProp);
			var pvtTbl1 = new PivotTable(new[] { "r1", "r2" }, new[] { "c1", "c2", "c3" }, pvtData);

			Action<IPivotTable,CollapsePivotTableConfiguration, string, string, int> check = (pvtTbl,collapseCfg, tag, cssClass, cnt) => {
				var xmlDoc1 = new XmlDocument();
				xmlDoc1.LoadXml(ToHtml(pvtTbl, (htmlWr) => {
					htmlWr.SubtotalKeySuffix = null;
					htmlWr.CollapseConfiguration = collapseCfg;
				}));
				RemoveTrialTr(xmlDoc1);
				Assert.Equal(cnt, xmlDoc1.SelectNodes("/table//"+tag+"[contains(@class,'" + cssClass + " ') or @class='" + cssClass + "']").Count);
			};

			// all collapsed
			var collapseCfg1 = new CollapsePivotTableConfiguration();
			check(pvtTbl1, collapseCfg1, "th", "pvtColumn", 2);
			check(pvtTbl1, collapseCfg1, "th", "pvtRow", 3);
			// both row and col have expanded
			var collapseCfg2 = new CollapsePivotTableConfiguration() {
				ExpandedRows = new[] { new[] { 0 }, new[] { 2 }  },
				ExpandedColumns = new [] { new[] { 0 }, new[] {0, 2 } }
			};
			check(pvtTbl1, collapseCfg2, "th", "pvtColumn", 10);
			check(pvtTbl1, collapseCfg2, "th", "pvtRow", 7);
			check(pvtTbl1, collapseCfg2, "td", "subtotalValue", 20);

			// now check the same for CollapsePivotTable wrapper
			var collapsePvtTbl1 = new CollapsePivotTable(pvtTbl1, collapseCfg1);
			check(collapsePvtTbl1, null, "th", "pvtColumn", 2);
			check(collapsePvtTbl1, null, "th", "pvtRow", 3);
			var collapsePvtTbl2 = new CollapsePivotTable(pvtTbl1, collapseCfg2);
			check(collapsePvtTbl2, null, "th", "pvtColumn", 10);
			check(collapsePvtTbl2, null, "th", "pvtRow", 7);
			check(collapsePvtTbl2, null, "td", "subtotalValue", 20);
		}

		string ToHtml(IPivotTable tbl, Action<PivotTableHtmlWriter> setup) {
			var strWr = new StringWriter();
			var htmlWr = new PivotTableHtmlWriter(strWr);
			setup(htmlWr);
			htmlWr.Write(tbl);
			return strWr.ToString();
		}

		[Fact]
		public void CsvWriterTest() {
			var pvtData = new PivotData(new[] {"a","b"}, new CountAggregatorFactory(), true);
			pvtData.ProcessData( DataUtils.getSampleData(1000), DataUtils.getProp);
			var pvtTbl = new PivotTable(new[]{"b"},null,pvtData);

			var strWr = new StringWriter();
			using (strWr) {
				var csvWr = new PivotTableCsvWriter(strWr);
				csvWr.Write(pvtTbl);
			}

			var lines = strWr.ToString().Split(new[]{'\n'},StringSplitOptions.RemoveEmptyEntries);
			Assert.Equal(1002,lines.Length);

			Assert.Equal(1000, Convert.ToInt32( lines.Last().Split(',').Last() ) );

			// test for 2 measures
			var pvtData2 = new PivotData(new[] {"a","b"}, 
				new CompositeAggregatorFactory( new AverageAggregatorFactory("c"), new SumAggregatorFactory("c") ),
				true);

			pvtData2.ProcessData( DataUtils.getSampleData(1000), DataUtils.getProp);
			var pvtTbl2 = new PivotTable(new[]{"b"},new[]{"a"},pvtData2);
			var strWr2 = new StringWriter();
			using (strWr2) {
				var csvWr2 = new PivotTableCsvWriter(strWr2);
				csvWr2.Write(pvtTbl2);
			}
			var lines2 = strWr2.ToString().Split(new[]{'\n'},StringSplitOptions.RemoveEmptyEntries);
			Assert.Equal(9, lines2[0].Split(new[]{','}).Count() );
			Assert.Equal(9, lines2[1].Split(new[]{','}).Count() );
			Assert.Equal(9, lines2.Last().Split(new[]{','}).Count() );
			
		}

		[Fact]
		public void ExcelWriterTest() {

			var pvtData = new PivotData(new[] {"a"}, new CountAggregatorFactory(), false);
			pvtData.ProcessData( DataUtils.getSampleData(10000), DataUtils.getProp);
			var pvtTbl = new PivotTable(null,new[]{"a"},pvtData);
			
			var memStream = new MemoryStream();
			using (memStream) {
				var excelWr = new PivotTableExcelWriter(memStream,"Data");
				excelWr.Write(pvtTbl);
			}

			using (var package = new ExcelPackage( new MemoryStream(memStream.ToArray()) )) {
				Assert.Equal(1, package.Workbook.Worksheets.Count);

				Assert.Equal(10000D, package.Workbook.Worksheets["Data"].Cells[2,5].Value );
			}

		}

		[Fact]
		public void ExcelWriter_RepeatKeysTest() {
			var pvtData = new PivotData(new[]{"a","b","c","d"}, new CountAggregatorFactory() );
			var inputData = new List<object>();
			for (int i = 0; i < 100; i++) {
				inputData.Add( new { a = 1, b = 1, c = i%10, d = i%20 });
			}
			pvtData.ProcessData(inputData, DataUtils.getProp);

			Func<ExcelWorksheet,string,int> countCells = (ws, styleName) => {
				int cnt = 0;
				for (int r=ws.Dimension.Start.Row; r<=ws.Dimension.End.Row; r++)
					for (int c = ws.Dimension.Start.Column; c <= ws.Dimension.End.Column; c++) {
						var cell = ws.Cells[r,c];
						if (!cell.Merge && cell.StyleName==styleName)
							cnt++;
					}
				foreach (var merged in ws.MergedCells) {
					var range = ws.Cells[merged];
					if (range.StyleName==styleName)
						cnt++;
				}
				return cnt;
			};

			Action<PivotTable,string, int, int, int> check = (pvtTbl, styleName, defaultCnt, repeatKeysCnt, repeatDupKeysAcrossDimCnt) => {
				var excelPkg = new ExcelPackage();
				var workSheet = excelPkg.Workbook.Worksheets.Add("Test");
				var pvtExcelWr = new PivotTableExcelWriter(workSheet);
				pvtExcelWr.Write(pvtTbl);

				Assert.Equal(defaultCnt, countCells(workSheet, styleName) );

				var workSheet2 = excelPkg.Workbook.Worksheets.Add("Test2");
				var pvtExcelWr2 = new PivotTableExcelWriter(workSheet2);
				pvtExcelWr2.RepeatKeysInGroups = RepeatDimensionKeyType.ColumnsAndRows;
				pvtExcelWr2.Write(pvtTbl);	
				Assert.Equal(repeatKeysCnt, countCells(workSheet2, styleName) );
				
				var workSheet3 = excelPkg.Workbook.Worksheets.Add("Test3");
				var pvtExcelWr3 = new PivotTableExcelWriter(workSheet3);
				pvtExcelWr3.RepeatDuplicateKeysAcrossDimensions = RepeatDimensionKeyType.No; 
				pvtExcelWr3.Write(pvtTbl);
				Assert.Equal(repeatDupKeysAcrossDimCnt, countCells(workSheet3, styleName) );
			};

			// check cols
			check( new PivotTable(new[]{"d"}, new[]{"a","b","c"}, pvtData ), "pvtColumn", 12, 30, 11 );
			check( new PivotTable(new[]{"d"}, new[]{"c","a","b"}, pvtData ), "pvtColumn", 30, 30, 19 );
			check( new PivotTable(new[]{"d"}, new[]{"a","c","b"}, pvtData ), "pvtColumn", 21, 30, 20 );

			// check rows
			check( new PivotTable(new[]{"a","b","c"}, new[]{"d"}, pvtData ), "pvtRow", 12, 30, 11 );
			check( new PivotTable(new[]{"c","a","b"}, new[]{"d"}, pvtData ), "pvtRow", 30, 30, 19 );
			check( new PivotTable(new[]{"a","c","b"}, new[]{"d"}, pvtData ), "pvtRow", 21, 30, 20 );
		}


		[Fact]
		public void JsonWriterTest() {
			var pvtData = new PivotData(new[] {"a", "d"}, new CountAggregatorFactory(), false);
			pvtData.ProcessData( DataUtils.getSampleData(10000), DataUtils.getProp);
			
			var pvtTbl = new PivotTable(new[] {"d"},new[]{"a"},pvtData);

			var strWr = new StringWriter();
			var jsonWr = new PivotTableJsonWriter(strWr);
			jsonWr.Write(pvtTbl);

			var pvtModel = JsonConvert.DeserializeObject<PivotTableModel>(strWr.ToString());
			Assert.Equal(pvtTbl.Columns.Length, pvtModel.Columns.Length);
			Assert.Equal(pvtTbl.Rows.Length, pvtModel.Rows.Length);
			Assert.Equal(pvtTbl.RowKeys.Length, pvtModel.RowKeys.Length);
			Assert.Equal(pvtTbl.ColumnKeys.Length, pvtModel.ColumnKeys.Length);

			Assert.Equal(10000L, pvtModel.GrandTotal);
			Assert.Equal(3, pvtModel.ColumnTotals.Length);
			Assert.Equal(100, pvtModel.RowTotals.Length);

			var pvtData2 = new PivotData(new[] {"a", "d"}, 
				new CompositeAggregatorFactory( new AverageAggregatorFactory("b"), new SumAggregatorFactory("b") ), false);
			pvtData2.ProcessData( DataUtils.getSampleData(10000), DataUtils.getProp);
			var pvtTbl2 = new PivotTable(new[] {"d"},new[]{"a"},pvtData2);

			var strWr2 = new StringWriter();
			var jsonWr2 = new PivotTableJsonWriter(strWr2);
			jsonWr2.Write(pvtTbl2);
			var pvtModel2 = JsonConvert.DeserializeObject<PivotTableModel>(strWr2.ToString());
			Assert.Equal(2, ((IList)pvtModel2.Values[0][0]).Count);

			// subtotals test
			var pvtData3 = new PivotData(new[] { "a", "e", "d" }, new CompositeAggregatorFactory( new CountAggregatorFactory() ), false);
			pvtData3.ProcessData(DataUtils.getSampleData(10000), DataUtils.getProp);
			var pvtTbl3 = new PivotTable(new[] { "e", "a", "d" }, null, pvtData3);
			var strWr3 = new StringWriter();
			var jsonWr3 = new PivotTableJsonWriter(strWr3) { SubtotalRows = true, SubtotalColumns = true };
			jsonWr3.Write(pvtTbl3);
			var pvtModel3 = JsonConvert.DeserializeObject<PivotTableModel>(strWr3.ToString());
			Assert.Equal(308, pvtModel3.RowKeys.Length);
			Assert.Null(pvtModel3.RowKeys[50][2]);

			var pvtTbl4 = new PivotTable(null, new[] { "e", "a", "d" }, pvtData3);
			var strWr4 = new StringWriter();
			var jsonWr4 = new PivotTableJsonWriter(strWr4) { SubtotalRows = true, SubtotalColumns = true };
			jsonWr4.Write(pvtTbl4);
			var pvtModel4 = JsonConvert.DeserializeObject<PivotTableModel>(strWr4.ToString());
			Assert.Equal(308, pvtModel4.ColumnKeys.Length);
			Assert.Null(pvtModel4.ColumnKeys[50][2]);

			// PaginatePivotTable and composite aggregator with only one aggr
			var pvtTbl5 = new PaginatePivotTable(pvtTbl4, new PaginatePivotTable.Page(0, Int32.MaxValue), new PaginatePivotTable.Page(0, 5));
			var strWr5 = new StringWriter();
			var jsonWr5 = new PivotTableJsonWriter(strWr5);
			jsonWr5.Write(pvtTbl5);
		}

		public class PivotTableModel {
			public string[] Columns;
			public string[] Rows;
			public object[][] ColumnKeys;
			public object[][] RowKeys;
			public object[][] Values;
			public object GrandTotal;
			public object[] ColumnTotals;
			public object[] RowTotals;
		}

		[Fact]
		public void DataTableWriterTest() {

			var pvtData = new PivotData(new[] {"a", "d"}, new CountAggregatorFactory(), false);
			pvtData.ProcessData( DataUtils.getSampleData(10000), DataUtils.getProp);
			
			var pvtTbl = new PivotTable(new[] {"d"},new[]{"a"},pvtData);
			var dataTblWr = new PivotTableDataTableWriter("Test") {
				GrandTotal = false,
				TotalsRow = false,
				TotalsColumn = false				
			};
			var tbl = dataTblWr.Write(pvtTbl);
			
			Assert.Equal(4, tbl.Columns.Count);
			Assert.Equal(typeof(int), tbl.Columns[0].DataType);
			Assert.Equal(100, tbl.Rows.Count);

			// several measures test
			var pvtData2 = new PivotData(new[] {"a", "d", "e" }, 
				new CompositeAggregatorFactory(
					new CountAggregatorFactory(),
					new SumAggregatorFactory("b"),
					new MaxAggregatorFactory("f")
				) );
			pvtData2.ProcessData( DataUtils.getSampleData(1000), DataUtils.getProp);
			var pvtTbl2 = new PivotTable(new[] {"d"},new[]{"a", "e"},pvtData2);
			var tbl2 = new PivotTableDataTableWriter("Test"){
				GrandTotal = false,
				TotalsRow = false,
				TotalsColumn = false
			}.Write(pvtTbl2);

			// check column types
			Assert.Equal(typeof(int), tbl2.Columns[0].DataType);  // this is values of "d" dim
			Assert.Equal(typeof(uint), tbl2.Columns[1].DataType); // this is values of count aggr
			Assert.Equal(typeof(decimal), tbl2.Columns[2].DataType); // this is values of sum aggr
			Assert.Equal(typeof(string), tbl2.Columns[3].DataType); // this is values of max of f aggr (f is string)

			Assert.Equal(19, tbl2.Columns.Count);
			Assert.Equal("val1_false_count", tbl2.Columns[1].ColumnName);
			Assert.Equal("val1_false_sumofb", tbl2.Columns[2].ColumnName);
			Assert.Equal(100, tbl2.Rows.Count);

			var tbl3 = new PivotTableDataTableWriter("Test").Write(pvtTbl2);
			Assert.Equal(19+3, tbl3.Columns.Count);
			Assert.Equal(100+1, tbl3.Rows.Count);
			Assert.Equal(1000U, tbl3.Rows[tbl3.Rows.Count-1]["totals_count"] );
			Assert.Equal(499500M, tbl3.Rows[tbl3.Rows.Count-1]["totals_sumofb"] );

			/*var ds = new DataSet();
			ds.Tables.Add(tbl3);

			var strWr = new StringWriter();
			ds.WriteXml( strWr, XmlWriteMode.WriteSchema );
			Console.WriteLine( strWr.ToString() );*/
		}


		[Fact]
		public void DataTableWriter_SubTotalTest() {
			var dataTblWr = new PivotTableDataTableWriter("Test") {
				SubtotalRows = true,
				SubtotalColumns = true
			};

			var pvtDataForSubtotals = new PivotData(new[] { "a", "f", "e", "d" }, new CountAggregatorFactory(), false);
			pvtDataForSubtotals.ProcessData(DataUtils.getSampleData(10000), DataUtils.getProp);

			var tbl1 = dataTblWr.Write(new PivotTable(new[] { "a", "f", "e" }, new string[0], pvtDataForSubtotals));
			Assert.Equal(49, tbl1.Rows.Count);

			var tbl2 = dataTblWr.Write(new PivotTable(new string[0], new[] { "e", "a", "f" }, pvtDataForSubtotals));
			Assert.Equal(39, tbl2.Columns.Count);

			var tbl3 = dataTblWr.Write(new PivotTable(new[] { "e", "d" }, new[] { "a", "f" }, pvtDataForSubtotals));
			Assert.Equal(103, tbl3.Rows.Count);
			Assert.Equal(
				"e#d#val1_testalpha#val1_testbeta#val1_testgamma#val1_testzeta_alpha#val1_val1test#val1_total#val2_testalpha#val2_testbeta#val2_testgamma#val2_testzeta_alpha#val2_val1test#val2_total#val3_testalpha#val3_testbeta#val3_testgamma#val3_testzeta_alpha#val3_val1test#val3_total#totals",
				String.Join("#", tbl3.Columns.Cast<DataColumn>().Select(c=>c.ColumnName.Replace("[trial]","") ).ToArray() ) );
		}


	}
}
