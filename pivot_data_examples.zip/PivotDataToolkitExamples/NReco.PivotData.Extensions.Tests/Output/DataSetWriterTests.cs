﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Xml;
using System.Data;

using Xunit;

using NReco.PivotData.Output;

namespace NReco.PivotData.Extensions.Tests.Output {
	
	public class DataSetWriterTests {

		[Fact]
		public void WriteStarSchemaTest() {
			var pvtData = new PivotData(new[] {"a","b"}, new CountAggregatorFactory(), true);
			pvtData.ProcessData( DataUtils.getSampleData(1000), DataUtils.getProp);
			
			var ds = new DataSet();
			var dsStarWr = new DataSetStarSchemaWriter(ds);
			dsStarWr.Write(pvtData);

			var keys = pvtData.GetDimensionKeys();

			//Console.WriteLine(ds.GetXml() );
			Assert.Equal(3, ds.Tables.Count );
			Assert.True( ds.Tables.Contains("a") );
			Assert.True( ds.Tables.Contains("b") );
			Assert.Equal( pvtData.Count, ds.Tables["facts"].Rows.Count );
			Assert.Equal( keys[0].Length, ds.Tables["a"].Rows.Count );
			Assert.Equal( keys[1].Length, ds.Tables["b"].Rows.Count );
		}


	}
}
