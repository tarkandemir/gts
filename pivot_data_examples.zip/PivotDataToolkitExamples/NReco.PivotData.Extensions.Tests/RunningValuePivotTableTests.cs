﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xunit;

namespace NReco.PivotData.Extensions.Tests
{
    public class RunningValuePivotTableTests
    {

		[Fact]
		public void RunningSumByColumnTest() {
			var pvtData = new PivotData(new[] {"a","d"}, new SumAggregatorFactory("b"));
			pvtData.ProcessData( DataUtils.getSampleData(1000), DataUtils.getProp);
			var pvtTbl = new PivotTable(new[]{"d"}, new[]{"a"}, pvtData);

			var runningSumPvtTbl = new RunningValuePivotTable(pvtTbl, RunningValuePivotTable.Direction.Column);

			Assert.Equal( 1800M+1503, runningSumPvtTbl.GetValue(runningSumPvtTbl.RowKeys[1],runningSumPvtTbl.ColumnKeys[0]).Value );
			Assert.Equal( 1800M+1503+1206, runningSumPvtTbl.GetValue(runningSumPvtTbl.RowKeys[2],runningSumPvtTbl.ColumnKeys[0]).Value );
			Assert.Equal( pvtTbl[null,0].Value, runningSumPvtTbl.GetValue(runningSumPvtTbl.RowKeys.Last(),runningSumPvtTbl.ColumnKeys[0]).Value );

			Assert.Equal( pvtTbl[null,null].Value, runningSumPvtTbl.GetValue(runningSumPvtTbl.RowKeys.Last(),null).Value );
		}

		[Fact]
		public void RunningSumByRowTest() {
			var pvtData = new PivotData(new[] {"a","d"}, new SumAggregatorFactory("b"));
			pvtData.ProcessData( DataUtils.getSampleData(1000), DataUtils.getProp);
			var pvtTbl = new PivotTable(new[]{"a"}, new[]{"d"}, pvtData);

			var runningSumPvtTbl = new RunningValuePivotTable(pvtTbl, RunningValuePivotTable.Direction.Row);

			Assert.Equal( 1800M+1503, runningSumPvtTbl.GetValue(runningSumPvtTbl.RowKeys[0],runningSumPvtTbl.ColumnKeys[1]).Value );
			Assert.Equal( 1800M+1503+1206, runningSumPvtTbl.GetValue(runningSumPvtTbl.RowKeys[0],runningSumPvtTbl.ColumnKeys[2]).Value );
			Assert.Equal( pvtTbl[0,null].Value, runningSumPvtTbl.GetValue(runningSumPvtTbl.RowKeys[0],runningSumPvtTbl.ColumnKeys.Last()).Value );

			Assert.Equal( pvtTbl[null,null].Value, runningSumPvtTbl.GetValue(null,runningSumPvtTbl.ColumnKeys.Last() ).Value );
		}


    }
}
