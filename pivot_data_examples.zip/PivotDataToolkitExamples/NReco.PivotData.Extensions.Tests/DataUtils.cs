﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

using NReco.PivotData.Input;
using NReco.PivotData.Output;
using Xunit;

namespace NReco.PivotData.Extensions.Tests {
	
	public class DataUtils {

		public static IEnumerable getSampleData(int records = 100000) {
			var aVals = new string[] {"val1", "val2", "val3"};
			var fVals = new string[] {"test alpha", "test beta", "test gamma", "test zeta-alpha", "val1 test"};
			var rnd = new Random();
			for (int i = 0; i < records; i++) {
				yield return new {
					a = aVals[i%aVals.Length],
					b = i,
					c = rnd.NextDouble()*10,
					d = i%100,
					e = i%2==0,
					f = fVals[i%fVals.Length]
				};
			}
		}

		public static IEnumerable getSampleDataWithNullAndEmpty(int records = 100000) {
			var aVals = new string[] { "val1", "val2", null };
			var fVals = new string[] { "test alpha", "test beta", "test gamma", "", " "};
			var rnd = new Random();
			for (int i = 0; i < records; i++) {
				yield return new {
					a = aVals[i % aVals.Length],
					b = i,
					c = rnd.NextDouble() * 10,
					d = i % 100,
					e = i % 2 == 0,
					f = fVals[i % fVals.Length]
				};
			}
		}

		public static object getProp(object r, string f) {
			return r.GetType().GetProperty(f).GetValue(r);
		}

	}
}
