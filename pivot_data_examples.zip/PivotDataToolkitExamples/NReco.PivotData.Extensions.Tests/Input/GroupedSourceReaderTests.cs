﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

using Xunit;

using NReco.PivotData.Input;
using NReco.PivotData.Input.Value;

namespace NReco.PivotData.Extensions.Tests.Input {
	public class GroupedSourceReaderTests {

		string sampleGroupedCsvData = 
@"A,B,CNT,SM_Sum
2005,Q1,2,150
2005,Q2,3,250
2005,Q3,1,100,
2006,Q2,4,500";

		[Fact]
		public void LoadTest() {
			var csvStream = new MemoryStream( System.Text.Encoding.UTF8.GetBytes(sampleGroupedCsvData) );

			var csvSource = new CsvSource( new StreamReader( csvStream ) );
			var pvtCfg = new PivotDataConfiguration() {
				Dimensions = new[] { "A", "B"},
				Aggregators = new AggregatorFactoryConfiguration[] {
					new AggregatorFactoryConfiguration("Sum", new object[]{"SM"})
				},
				LazyTotals = true
			};

			var groupedSourceRdr = new GroupedSourceReader(csvSource, "CNT");
			var pvtData = groupedSourceRdr.Read(pvtCfg, new PivotDataFactory());

			Assert.Equal(4, pvtData.Count );
			Assert.Equal(500M, pvtData["2005", Key.Empty].Value);
			Assert.Equal(6U, pvtData["2005", Key.Empty].Count);
			Assert.Equal(500M, pvtData["2006", Key.Empty].Value);
		}

		[Fact]
		public void LoadWithSubtotalsTest() {
			var data = new object[] {
				new { A = 2005, B = "Q1", CNT = 2 },
				new { A = 2005, B = "Q2", CNT = 3 },
				new { A = 2006, B = "Q2", CNT = 4 },
				new { A = 2005, B = Key.Empty, CNT = 50 },  // custom value to test
				new { A = 2006, B = Key.Empty, CNT = 40 },
				new { A = Key.Empty, B = Key.Empty, CNT = 100}
			};
			var grpSrcRdr = new GroupedSourceReader((processData) => {
				processData(data, new ObjectMember().GetValue);
			}, "CNT");
			var pvtDataCfg = new PivotDataConfiguration() {
				Dimensions = new[] { "A", "B" },
				Aggregators = new[] { new AggregatorFactoryConfiguration("Count", null) }
			};
			var pvtData = grpSrcRdr.Read(pvtDataCfg, new PivotDataFactory());

			Assert.Equal(50U, pvtData[2005, Key.Empty].Value);
			Assert.Equal(40U, pvtData[2006, Key.Empty].Value);
			Assert.Equal(100U, pvtData[Key.Empty, Key.Empty].Value);

			// check FixedPivotData too
			var pvtDataState = grpSrcRdr.ReadState(pvtDataCfg);
			var fixedPvtData = new FixedPivotData(pvtDataCfg.Dimensions, new CountAggregatorFactory(), pvtDataState);

			Assert.Equal(50U, fixedPvtData[2005, Key.Empty].Value);
			Assert.Equal(40U, fixedPvtData[2006, Key.Empty].Value);
			Assert.Equal(100U, fixedPvtData[Key.Empty, Key.Empty].Value);
		}

		[Fact]
		public void AggregatorStateComposersTest() {
			var data = new object[] {
				new {
					A = 2005, B = "Q1",
					CNT = 2, VAL_Min = 1, VAL_Max = 10, VAL_Average = 5, VAL_Sum = 11,
					VAL_CountUnique = new object[] {1, 10},
					VAL_ListUnique = new object[] {1, 10},
					VAL_List = new object[] {1, 10},
					VAL_Variance = 40.5
				},
			};
			var grpSrcRdr = new GroupedSourceReader((processData) => {
				processData(data, new ObjectMember().GetValue);
			}, "CNT");
			var pvtDataCfg = new PivotDataConfiguration() {
				Dimensions = new[] { "A", "B" },
				Aggregators = new[] {
					new AggregatorFactoryConfiguration("Count", null),
					new AggregatorFactoryConfiguration("Min", new[]{"VAL"}),
					new AggregatorFactoryConfiguration("Max", new[]{"VAL"}),
					new AggregatorFactoryConfiguration("Average", new[]{"VAL"}),
					new AggregatorFactoryConfiguration("Sum", new[]{"VAL"}),
					new AggregatorFactoryConfiguration("CountUnique", new[]{"VAL"}),
					new AggregatorFactoryConfiguration("List", new[]{"VAL"}),
					new AggregatorFactoryConfiguration("Variance", new[]{"VAL"}),
					new AggregatorFactoryConfiguration("Variance", new[]{"VAL", "StandardDeviation"}),
					new AggregatorFactoryConfiguration("ListUnique", new[]{"VAL"})
				}
			};
			var pvtData = grpSrcRdr.Read(pvtDataCfg, new PivotDataFactory());
			var aggr = pvtData[2005, "Q1"].AsComposite();
			Assert.Equal(2U, aggr.Aggregators[0].Value);
			Assert.Equal(1, aggr.Aggregators[1].Value);
			Assert.Equal(10, aggr.Aggregators[2].Value);
			Assert.Equal(5M, aggr.Aggregators[3].Value);
			Assert.Equal(11M, aggr.Aggregators[4].Value);
			Assert.Equal(2, aggr.Aggregators[5].Value);
			Assert.Equal(2, ((IList)aggr.Aggregators[6].Value).Count );
			Assert.Equal(40.5, aggr.Aggregators[7].Value );
			Assert.Equal(6.364, Math.Round( (double)aggr.Aggregators[8].Value, 3) );
			Assert.Equal(2, ((IList)aggr.Aggregators[9].Value).Count);
		}

	}
}
