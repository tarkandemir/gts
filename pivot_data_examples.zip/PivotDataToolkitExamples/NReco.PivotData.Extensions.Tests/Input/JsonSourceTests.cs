﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

using Xunit;

using NReco.PivotData;
using NReco.PivotData.Input;
using NReco.PivotData.Input.Value;
using Newtonsoft.Json;

namespace NReco.PivotData.Extensions.Tests.Input {

	public class JsonSourceTests {
		//'A','B',C'
		string sampleJsonArrData1 = 
@"[
[1,5.5,'5 Jun 2014'],
[2,0,'6/6/2014'],
[3,4.6,'6-7-2014'],
[4,2,'6-5-2014'] ]";

		string sampleJsonObjData1 = 
@"[
{ 'A' : 1, 'B' : 5.5, 'C' : '5 Jun 2014' },
{ 'A' : 2, 'B' : 0, 'C': '6/6/2014' },
{ 'A' : 3, 'B' : 4.6, 'C' :'6-7-2014' },
{ 'A' : 4, 'B' : 2, 'C' : '6-5-2014'} ]";

		[Fact]
		public void ParseJsonValueArrayTest() {
			var jsonSource = GetJsonSource(sampleJsonArrData1);
			Assert.Throws<JsonException>( () => {
				ParseAndTest(jsonSource);
			});

			jsonSource = GetJsonSource(sampleJsonArrData1);
			jsonSource.Headers = new[] {"A","B","C"};
			ParseAndTest(jsonSource);
		}

		[Fact]
		public void ParseJsonObjectsTest() {
			var jsonSource = GetJsonSource(sampleJsonObjData1);
			ParseAndTest(jsonSource);

			jsonSource = GetJsonSource(sampleJsonObjData1);
			ParseAndTest(jsonSource);
		}

		private JsonSource GetJsonSource(string jsonStr) {
			var jsonArrStream = new MemoryStream( System.Text.Encoding.UTF8.GetBytes(jsonStr) );
			return new JsonSource(new StreamReader( jsonArrStream ) );			
		}

		private void ParseAndTest(JsonSource jsonSource) {
			var pvtData = new PivotData(new[] { "A", "C" }, 
				new CompositeAggregatorFactory( new IAggregatorFactory[]{
					new CountAggregatorFactory(),
					new AverageAggregatorFactory("B")
				}), false);

			var castWrapper = new DerivedValueSource(jsonSource);
			var parseVal = new ParseValue() { FormatProvider = System.Globalization.CultureInfo.InvariantCulture };
			castWrapper.Register("A", parseVal.ParseIntegerHandler);
			castWrapper.Register("B", parseVal.ParseDoubleHandler);
			castWrapper.Register("C", parseVal.ParseDateTimeHandler);

			pvtData.ProcessData(castWrapper);
			Assert.Equal(4U, ((object[])pvtData[Key.Empty, Key.Empty].Value)[0]);
			Assert.Equal(3.75M, ((object[])pvtData[Key.Empty, new DateTime(2014,6,5)].Value)[1]);
		}


	}
}
