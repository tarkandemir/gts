﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

using Xunit;

using NReco.PivotData;
using NReco.PivotData.Input;
using NReco.PivotData.Input.Value;

namespace NReco.PivotData.Extensions.Tests.Input {
	public class CsvSourceTests {

		string sampleCsv = 
@"A,B,C
1,5.5,5 Jun 2014
2,0,6/6/2014
3,4.6,6-7-2014
4,2,6-5-2014";

		[Fact]
		public void ParseCsvTest() {
			var csvStream = new MemoryStream( System.Text.Encoding.UTF8.GetBytes(sampleCsv) );

			var csvSource = new CsvSource(new StreamReader( csvStream ) );
			var pvtData = new PivotData(new[] { "A", "C" }, 
				new CompositeAggregatorFactory( new IAggregatorFactory[]{
					new CountAggregatorFactory(),
					new AverageAggregatorFactory("B")
				}), false);

			var castWrapper = new DerivedValueSource(csvSource);
			var parseVal = new ParseValue() { FormatProvider = System.Globalization.CultureInfo.InvariantCulture };
			castWrapper.Register("A", parseVal.ParseIntegerHandler);
			castWrapper.Register("B", parseVal.ParseDoubleHandler);
			castWrapper.Register("C", parseVal.ParseDateTimeHandler);

			pvtData.ProcessData(castWrapper);
			Assert.Equal(4U, ((object[])pvtData[Key.Empty, Key.Empty].Value)[0]);
			Assert.Equal(3.75M, ((object[])pvtData[Key.Empty, new DateTime(2014,6,5)].Value)[1]);
		}

		string strangeHdrSampleCsv = "\"A\nA\",B  B,\"C\r\n\tC\"\n1,5.5,5 Jun 2014";

		[Fact]
		public void StrangeHeadersTest() {
			var csvSource = new CsvSource(new StreamReader(new MemoryStream(System.Text.Encoding.UTF8.GetBytes(strangeHdrSampleCsv))));
			csvSource.ReadData((data, getValue) => {
				var dataEnumerator = data.GetEnumerator();
				dataEnumerator.MoveNext();
				var row = dataEnumerator.Current;
				Assert.Equal("1", getValue(row, "A\nA") );
				Assert.Equal("1", getValue(row, "A A") );
				Assert.Equal("5.5", getValue(row, "B  B") );
				Assert.Equal("5.5", getValue(row, "B B") );
				Assert.Equal("5 Jun 2014", getValue(row, "C\r\n\tC"));
				Assert.Equal("5 Jun 2014", getValue(row, "C   C"));
				Assert.Equal("5 Jun 2014", getValue(row, "C C"));
			});
		}

		[Fact]
		public void CsvOptionsTest() {
			var tests = new string[] {
				// tab
				"A\tB\tC \r\n1\t2\t 3\r\n\r\n5\t\t\n\"6\"\t \"7\"\"\" \t\"\"\"\"",
				// custom 3-symobls
				"A%%% \"B\"%%%C\n 1%%%2%%%3 \n5%%%6%%6%%%7%\n",
				// no trim
				"A,B,C\n1 , 2  ,3 \n  4,5, 6\n \"7\",\"\"8 ,\"9\"",
				"A,B,C",
				"A,B,C\n1,2,3"
			};
			var testConfigs = new CsvConfiguration[] {
				new CsvConfiguration() { Delimiter = "\t", HasHeaderRecord = true, TrimFields = true },
				new CsvConfiguration() { Delimiter = "%%%", HasHeaderRecord = true, TrimFields = true },
				new CsvConfiguration() { Delimiter = ",", HasHeaderRecord = true, TrimFields = false },
				new CsvConfiguration() { Delimiter = ",", HasHeaderRecord = true, BufferSize = 5 },
				new CsvConfiguration() { Delimiter = ",", HasHeaderRecord = true, BufferSize = 5 }
			};
			var expected = new string[] {
				"1|2|3|#5|||#6|7\"|\"|#",
				"1|2|3|#5|6%%6|7%|#",
				"1 | 2  |3 |#  4|5| 6|# \"7\"|\"\"8 |9|#",
				"",
				"1|2|3|#"
			};
			for (int i=0; i<tests.Length; i++) {
				var csvSource = new CsvSource(
					new StreamReader(new MemoryStream(System.Text.Encoding.UTF8.GetBytes(tests[i]))),
					testConfigs[i]);
				csvSource.ReadData((data, getValue) => {
					var sb = new StringBuilder();
					foreach (var row in data) {
						sb.Append(getValue(row, "A") + "|");
						sb.Append(getValue(row, "B") + "|");
						sb.Append(getValue(row, "C") + "|");
						sb.Append("#");
					}
					Assert.Equal(expected[i], sb.ToString());
				});
			}
		}

		[Fact]
		public void InvalidCsvTest() {
			var test = "ABCDEF,123456";
			var csvSource = new CsvSource(
					new StreamReader(new MemoryStream(System.Text.Encoding.UTF8.GetBytes(test))),
					new CsvConfiguration() { Delimiter = ",", HasHeaderRecord = true, BufferSize = 5 } );
			Assert.Throws<InvalidDataException>(() => {
				csvSource.ReadData((data, getValue) => {
					foreach (var r in data) { }
				});
			});
		}

		[Fact]
		public void LargeCsvTest() {
			var memStream = new MemoryStream();
			using (var streamWr = new StreamWriter(memStream, Encoding.UTF8, 4096, true)) {
				streamWr.WriteLine("HeaderA, HeaderB , HeaderC  , Header D");
				var bVals = new string[] { "b1", "b2", "b3" };
				for (int i=0; i<1000000; i++) {
					streamWr.WriteLine(String.Format("{0},{1}, \"Quoted\", just a value", i, bVals[i%bVals.Length] ));
				}
			}
			memStream.Position = 0;

			Console.WriteLine("CSV len = " + memStream.Length.ToString());
			var sw = new System.Diagnostics.Stopwatch();
			sw.Start();

			var csvSource = new CsvSource(new StreamReader(memStream));
			var pvtData = new PivotData(new[] { "HeaderC", "Header D" }, new CountAggregatorFactory());
			pvtData.ProcessData(csvSource);

			sw.Stop();
			Console.WriteLine("Time: {0}ms", sw.ElapsedMilliseconds);

			Assert.Equal(1000000U, pvtData[Key.Empty, Key.Empty].Value);
		}

		[Fact]
		public void ProcessValueInBufferTest() {
			var sb = new StringBuilder();
			sb.AppendLine("A,B,C");
			for (int i=0; i<10000; i++) {
				sb.AppendLine("Some test value, \"Some value with \"\"quotes\"\"\",\"Simple in quotes\",a ");
			}
			var csvSource = new CsvSource(new StringReader(sb.ToString()), new CsvConfiguration() {
				Delimiter = ",",
				BufferSize = 100
			});
			csvSource.ReadData((data, getValue) => {
				foreach (CsvSource.CsvRecord r in data) {
					r.ProcessValueInBuffer(0, (buf, start, len) => {
						Assert.Equal("Some test value", new string(buf, start, len));
					});
					r.ProcessValueInBuffer(1, (buf, start, len) => {
						Assert.Equal("Some value with \"quotes\"", new string(buf, start, len));
					});
					r.ProcessValueInBuffer(2, (buf, start, len) => {
						Assert.Equal("Simple in quotes", new string(buf, start, len));
					});
					r.ProcessValueInBuffer(3, (buf, start, len) => {
						Assert.Equal("a", new string(buf, start, len));
					});
				}
			});
		}

	}
}
