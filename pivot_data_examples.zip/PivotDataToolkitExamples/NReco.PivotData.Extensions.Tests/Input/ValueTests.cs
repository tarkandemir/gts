﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

using Xunit;

using NReco.PivotData.Input;
using NReco.PivotData.Input.Value;

namespace NReco.PivotData.Extensions.Tests.Input {
	
	public class ValueTests {

		[Fact]
		public void DatePartValueTest() {

			var testMap = new Dictionary<string,object>() {
				{"Date1", new DateTime(2015, 5, 25, 11, 00, 00) },
				{"Str1", "str" }
			};
			Func<object,string,object> getVal = (o,f) => {
				return ((IDictionary<string,object>)o)[f];
			};
			
			var datePartVal = new DatePartValue();
			Assert.Equal(2015, datePartVal.YearHandler(getVal)(testMap, "Date1") );
			Assert.Null( datePartVal.YearHandler(getVal)(testMap, "Str1") );

			Assert.Equal(5, datePartVal.MonthNumberHandler(getVal)(testMap, "Date1") );

			Assert.Equal(2, datePartVal.QuarterHandler(getVal)(testMap, "Date1") );

			Assert.Equal(25, datePartVal.DayHandler(getVal)(testMap, "Date1") );
		}

		[Fact]
		public void FormatValueTest() {
			var testMap = new Dictionary<string,object>() {
				{"Date1", new DateTime(2015, 5, 25, 11, 00, 00) },
				{"Str1", "str" },
				{"Num1", 1}
			};
			Func<object,string,object> getVal = (o,f) => {
				return ((IDictionary<string,object>)o)[f];
			};
			var fmtVal1 = new FormatValue("{0:yyyy}-{0:MM}");
			Assert.Equal("2015-05", fmtVal1.FormatHandler(getVal)(testMap, "Date1") );

			var fmtVal2 = new FormatValue("{0}/{1}", new string[] {"Num1", "Str1"});
			Assert.Equal("1/str", fmtVal2.FormatHandler(getVal)(testMap, "Date1") );
		}

		[Fact]
		public void ParseValueTest() {
			var testMap = new Dictionary<string,object>() {
				{"Date1", "2015 May 25 10:55"},
				{"Date2", "2014/05/20" },
				{"Int1", "-5"},
				{"Num1", "5.5"},
				{"emptyVal", ""},
				{"nullVal", null},
				{"zeroVal", "0"}
			};
			Func<object,string,object> getVal = (o,f) => {
				return ((IDictionary<string,object>)o)[f];
			};

			var parseVal = new ParseValue() { FormatProvider = System.Globalization.CultureInfo.InvariantCulture };
			Assert.Equal( new DateTime(2014,5,20), parseVal.ParseDateTimeHandler(getVal)(testMap, "Date2") );
			Assert.Equal( new DateTime(2015,5,25, 10, 55, 00), parseVal.ParseDateTimeHandler(getVal)(testMap, "Date1") );

			Assert.Equal( -5, parseVal.ParseIntegerHandler(getVal)(testMap, "Int1") );
			Assert.Null( parseVal.ParseIntegerHandler(getVal)(testMap, "Num1") );
			Assert.Equal( 5.5, parseVal.ParseDoubleHandler(getVal)(testMap, "Num1") );

			Assert.Equal(5.5M, parseVal.ParseDecimalHandler(getVal)(testMap, "Num1"));
			Assert.Equal(0M, parseVal.ParseDecimalHandler(getVal)(testMap, "zeroVal"));
			Assert.Null(parseVal.ParseDecimalHandler(getVal)(testMap, "emptyVal"));
			Assert.Null(parseVal.ParseDecimalHandler(getVal)(testMap, "nullVal"));

		}

		[Fact]
		public void RegexMatchValueTest() {
			var testMap = new Dictionary<string,object>() {
				{"val1", "AAABB"},
				{"val2", "Test" }
			};
			Func<object,string,object> getVal = (o,f) => {
				return ((IDictionary<string,object>)o)[f];
			};
			var regexMatchVal1 = new RegexMatchValue("^A+", null);
			Assert.Equal(true, regexMatchVal1.IsMatchHandler( getVal )(testMap, "val1") );
			Assert.Equal(false, regexMatchVal1.IsMatchHandler( getVal )(testMap, "val2") );
 		}

		[Fact]
		public void RegexReplaceValueTest() {
			var testMap = new Dictionary<string,object>() {
				{"val1", "AAABB"},
				{"val2", "Test" }
			};
			Func<object,string,object> getVal = (o,f) => {
				return ((IDictionary<string,object>)o)[f];
			};
			var regexReplVal = new RegexReplaceValue("^(?<aGrp>A+)", "[${aGrp}]", null);
			Assert.Equal("[AAA]BB", regexReplVal.ReplaceHandler( getVal )(testMap, "val1") );
			Assert.Equal("Test", regexReplVal.ReplaceHandler( getVal )(testMap, "val2") );
		}

	}
}
