﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using NReco.PivotData.Output;
using System.Xml;

using Xunit;

namespace NReco.PivotData.Extensions.Tests
{
    public class HeatmapPivotTableTests
    {

		string ToHtml(IPivotTable tbl) {
			var strWr = new StringWriter();
			var htmlWr = new PivotTableHtmlWriter(strWr);
			htmlWr.RenderValueIndexAttr = true;
			htmlWr.Write(tbl);
			return strWr.ToString();
		}

		void CheckCellStyle(XmlDocument xmlDoc, int row, int col, string styleProp, string value) {
			var valIdx = row.ToString()+":"+col.ToString();
			var node = xmlDoc.SelectSingleNode("/table//td[@data-value-index='"+valIdx+"']");
			if (node==null)
				throw new Exception("There are no cell for "+valIdx);
			var styleAttr = node.Attributes["style"];
			if (styleAttr==null)
				if (value!=null)
					throw new Exception("Style attribute is not present for "+valIdx);
				else
					return;
			var styleVal = styleAttr.Value;
			if (styleVal==null)
				if (value!=null)
					throw new Exception("Style attribute is not present for "+valIdx);
				else
					return;
			var props = styleVal.Split(new []{';'}, StringSplitOptions.RemoveEmptyEntries);
			foreach (var prop in props) {
				var propParts = prop.Split(':');
				var propName = propParts[0].Trim();
				if (propName == styleProp) {
					Assert.Equal(value, propParts[1].Trim() );
					return;
				}
			}
			if (value!=null)
				throw new Exception("Style property "+styleProp+" not present for "+valIdx);
		}

		PivotTable GetTestPivotTable() {
			var pvtData = new PivotData(new[] {"a","d"}, new SumAggregatorFactory("b"));
			pvtData.ProcessData( DataUtils.getSampleData(1000), DataUtils.getProp);
			return new PivotTable(new[]{"d"}, new[]{"a"}, pvtData);
		}

		[Fact]
		public void HeatmapByTableTest() {
			var pvtTbl = GetTestPivotTable();

			var heatmapPvtTbl = new HeatmapPivotTable(pvtTbl, HeatmapPivotTable.HeatmapMode.Table);
			var pvtTblHtml = ToHtml(heatmapPvtTbl);
			var xmlDoc1 = new XmlDocument();
			xmlDoc1.LoadXml( pvtTblHtml );	

			CheckCellStyle(xmlDoc1, 99, 0, "background-color", "#FF0000");
			CheckCellStyle(xmlDoc1, 1, 2, "background-color", "#FFFEFE");
			CheckCellStyle(xmlDoc1, 0, 1, "background-color", null);  // min value, no color
		}

		[Fact]
		public void HeatmapByRowTest() {
			var pvtTbl = GetTestPivotTable();

			var heatmapPvtTbl = new HeatmapPivotTable(pvtTbl, HeatmapPivotTable.HeatmapMode.Row);
			var pvtTblHtml = ToHtml(heatmapPvtTbl);
			var xmlDoc1 = new XmlDocument();
			xmlDoc1.LoadXml( pvtTblHtml );	

			// first row
			CheckCellStyle(xmlDoc1, 0, 0, "background-color", "#FF0000"); // max val
			CheckCellStyle(xmlDoc1, 0, 1, "background-color", null);  // min value, no color

			CheckCellStyle(xmlDoc1, 99, 0, "background-color", "#FF0000"); // max val
			CheckCellStyle(xmlDoc1, 99, 1, "background-color", null); // min value, no color
		}

		[Fact]
		public void HeatmapByColumnTest() {
			var pvtTbl = GetTestPivotTable();

			var heatmapPvtTbl = new HeatmapPivotTable(pvtTbl, HeatmapPivotTable.HeatmapMode.Column);
			var pvtTblHtml = ToHtml(heatmapPvtTbl);
			var xmlDoc1 = new XmlDocument();
			xmlDoc1.LoadXml( pvtTblHtml );	

			// max values in columns
			CheckCellStyle(xmlDoc1, 97, 1, "background-color", "#FF0000"); 
			CheckCellStyle(xmlDoc1, 99, 0, "background-color", "#FF0000"); 
			CheckCellStyle(xmlDoc1, 98, 2, "background-color", "#FF0000"); 
		}



    }
}
