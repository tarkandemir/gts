﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

using NReco.PivotData.Input;
using NReco.PivotData.Output;
using Xunit;

namespace NReco.PivotData.Extensions.Tests {
	
	public class CubeFileTests {

		[Fact]
		public void WriteAndRead() {
			var tmpFolder = Path.Combine( Path.GetTempPath(), "pvt"+Path.GetRandomFileName() );

			try {
				var fileName = Path.Combine(tmpFolder, "test1.cfg");
				var fileRdr = new CubeFileReader(fileName);
				var fileWr = new CubeFileWriter(fileName);

				var pvtData = new PivotData(new[] {"a","c"}, new CompositeAggregatorFactory(
					new IAggregatorFactory[] { 
						new CountAggregatorFactory(),
						new AverageAggregatorFactory("b"),
						new MaxAggregatorFactory("c")
					}
				), true);
				pvtData.ProcessData(DataUtils.getSampleData(), DataUtils.getProp);

				fileWr.Write(pvtData, new PivotDataFactory().GetConfiguration(pvtData) );

				Assert.True( System.IO.File.Exists( Path.Combine(tmpFolder, "test1.cfg" )  ) );

				var loadedPvtData = fileRdr.Read();
				
				Assert.Equal( pvtData.Count, loadedPvtData.Count );
				Assert.Equal( pvtData.Dimensions.Length, loadedPvtData.Dimensions.Length );

				Assert.Equal( ((object[])pvtData[Key.Empty,Key.Empty].Value)[2], ((object[])loadedPvtData[Key.Empty,Key.Empty].Value)[2] );

				Assert.Equal( ((object[])pvtData["val1",Key.Empty].Value)[0], ((object[])loadedPvtData["val1",Key.Empty].Value)[0] );

			} finally {
				if (Directory.Exists(tmpFolder))
					Directory.Delete(tmpFolder, true);
			}
		}

	}
}
