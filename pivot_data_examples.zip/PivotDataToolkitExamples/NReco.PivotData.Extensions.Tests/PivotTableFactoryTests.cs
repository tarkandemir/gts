﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit.Abstractions;
using Xunit;

namespace NReco.PivotData.Extensions.Tests
{
    public class PivotTableFactoryTests
    {
		ITestOutputHelper Output;

		public PivotTableFactoryTests(ITestOutputHelper output) {
			Output = output;
		}

		PivotData createPvtData() {
			var pvtData = new PivotData(new[] {"a","b","d"},
					new CompositeAggregatorFactory(
						new CountAggregatorFactory(), 
						new SumAggregatorFactory("d"),
						new MaxAggregatorFactory("b")
					),
					false);
			pvtData.ProcessData( DataUtils.getSampleData(10000), DataUtils.getProp);
			return pvtData;
		}

		[Fact]
		public void CreatePivotTableTest() {
			var pvtTblFactory = new PivotTableFactory();
			var pvtData = createPvtData();

			var simpleTbl = new PivotTableConfiguration() {
				Rows = new [] {"a"},
				Columns = new [] {"d"},
				Measures = new[] { 0 }
			};

			var pvtTbl1 = pvtTblFactory.Create(pvtData, simpleTbl);

			Assert.Equal(3, pvtTbl1.RowKeys.Length);
			Assert.Equal("val1", pvtTbl1.RowKeys[0].DimKeys[0]);
			Assert.Equal("val3", pvtTbl1.RowKeys[2].DimKeys[0]);
			Assert.Equal(100, pvtTbl1.ColumnKeys.Length);

			var emptyTbl = new PivotTableConfiguration() {
				Rows = new string[0],
				Columns = new string[0],
				Measures = new[] { 0 }
			};
			var pvtTbl2 = pvtTblFactory.Create(pvtData, emptyTbl);
			Assert.Equal(10000U, pvtTbl2[null,null].Value);
			emptyTbl.Rows = null; // check correct null handling
			emptyTbl.Columns = null;
			var pvtTbl3 = pvtTblFactory.Create(pvtData, emptyTbl);
			Assert.Equal(10000U, pvtTbl3[null,null].Value);
		}

		[Fact]
		public void SortByValueTest() {

			var pvtTblFactory = new PivotTableFactory();
			var pvtData = createPvtData();

			var tblCfg = new PivotTableConfiguration() {
				Rows = new [] {"a"},
				Columns = new [] {"d"},
				Measures = new[] { 2 },
				SortByValue = new PivotTableConfiguration.AxisValuesOrder(
					PivotTableConfiguration.TableAxis.Rows, 0, System.ComponentModel.ListSortDirection.Descending )
			};
			var pvtTbl1 = pvtTblFactory.Create(pvtData, tblCfg);
			Assert.Equal( "val1", pvtTbl1.RowKeys[0].DimKeys[0] );

			tblCfg.SortByValue = new PivotTableConfiguration.AxisValuesOrder(
					PivotTableConfiguration.TableAxis.Rows, 0, System.ComponentModel.ListSortDirection.Ascending );
			var pvtTbl2 = pvtTblFactory.Create(pvtData, tblCfg);
			Assert.Equal( "val2", pvtTbl2.RowKeys[0].DimKeys[0] );

			// check incorrect measure index
			// no exception is thrown, sort by value just ignored
			tblCfg.Measures = null;
			tblCfg.SortByValue = new PivotTableConfiguration.AxisValuesOrder(
					PivotTableConfiguration.TableAxis.Rows, null, System.ComponentModel.ListSortDirection.Ascending) {
				Measure = 3
			};
			var pvtTbl3 = pvtTblFactory.Create(pvtData, tblCfg);
		}

		[Fact]
		public void SortByValue_PreserveGroups_Test() {
			var pvtTblFactory = new PivotTableFactory();
			var pvtData = createPvtData();

			var tblCfg = new PivotTableConfiguration() {
				Rows = new[] { "a", "d" },
				Measures = new[] { 2 },
				PreserveGroupOrder = true,
				SortByValue = new PivotTableConfiguration.AxisValuesOrder(
					PivotTableConfiguration.TableAxis.Rows, null, System.ComponentModel.ListSortDirection.Descending)
			};
			var pvtTbl1 = pvtTblFactory.Create(pvtData, tblCfg);
			Assert.Equal("val1", pvtTbl1.RowKeys[0].DimKeys[0]);
			Assert.Equal(99, pvtTbl1.RowKeys[0].DimKeys[1]);
			Assert.Equal(9999, pvtTbl1.GetValue(pvtTbl1.RowKeys[0], null).Value);

			// check sort-groups-by-subtotals mode
			tblCfg.SortGroupsBySubtotals = true;
			var pvtTbl2 = pvtTblFactory.Create(pvtData, tblCfg);

			Assert.Equal("val3", pvtTbl2.RowKeys[100].DimKeys[0]);
			Assert.Equal(98, pvtTbl2.RowKeys[100].DimKeys[1]);
			Assert.Equal(9998, pvtTbl2.GetValue(pvtTbl2.RowKeys[100], null).Value);
		}

		[Fact]
		public void SortByLabelTest() {

			var pvtTblFactory = new PivotTableFactory();
			var pvtData = createPvtData();

			var tblCfg = new PivotTableConfiguration() {
				Rows = new [] {"a", "d"},
				Measures = new[] { 0 },
				OrderKeys = new PivotTableConfiguration.AxisKeysOrder[] { 
					new PivotTableConfiguration.AxisKeysOrder(PivotTableConfiguration.TableAxis.Rows, 0, System.ComponentModel.ListSortDirection.Descending )
				}
			};

			var pvtTbl1 = pvtTblFactory.Create(pvtData, tblCfg);
			Assert.Equal( "val3", pvtTbl1.RowKeys[0].DimKeys[0] );
			Assert.Equal( 0, pvtTbl1.RowKeys[0].DimKeys[1] );

			tblCfg.OrderKeys = new PivotTableConfiguration.AxisKeysOrder[] { 
					new PivotTableConfiguration.AxisKeysOrder(PivotTableConfiguration.TableAxis.Rows, 1, System.ComponentModel.ListSortDirection.Descending )
			};
			var pvtTbl2 = pvtTblFactory.Create(pvtData, tblCfg);
			Assert.Equal( "val1", pvtTbl2.RowKeys[0].DimKeys[0] );
			Assert.Equal( 99, pvtTbl2.RowKeys[0].DimKeys[1] );

			tblCfg.OrderKeys = new PivotTableConfiguration.AxisKeysOrder[] { 
					new PivotTableConfiguration.AxisKeysOrder(PivotTableConfiguration.TableAxis.Rows, 0, System.ComponentModel.ListSortDirection.Descending ),
					new PivotTableConfiguration.AxisKeysOrder(PivotTableConfiguration.TableAxis.Rows, 1, System.ComponentModel.ListSortDirection.Descending )
			};
			var pvtTbl3 = pvtTblFactory.Create(pvtData, tblCfg);
			Assert.Equal( "val3", pvtTbl3.RowKeys[0].DimKeys[0] );
			Assert.Equal( 99, pvtTbl3.RowKeys[0].DimKeys[1] );

			// add sort by values
			tblCfg.SortByValue = new PivotTableConfiguration.AxisValuesOrder(
					PivotTableConfiguration.TableAxis.Rows, null, System.ComponentModel.ListSortDirection.Descending );
			var pvtTbl4 = pvtTblFactory.Create(pvtData, tblCfg);
			Assert.Equal( "val1", pvtTbl4.RowKeys[0].DimKeys[0] ); // labels grouping changed by sort by values

			tblCfg.PreserveGroupOrder = true;
			var pvtTbl5 = pvtTblFactory.Create(pvtData, tblCfg);
			Assert.Equal( pvtTbl3.RowKeys[0].DimKeys[0], pvtTbl5.RowKeys[0].DimKeys[0] ); // labels grouping remains the same as for pvtTbl3
			Assert.NotEqual( pvtTbl3.RowKeys[0].DimKeys[1], pvtTbl5.RowKeys[0].DimKeys[1] ); // changed only rows order inside group (last dim)
		}

		[Fact]
		public void CustomComparerTest() {

			var pvtTblFactory = new PivotTableFactory();

			var aOrder = new[] {"val2", "val1", "val3"};
			var aRevOrder = aOrder.Reverse().ToArray();
			pvtTblFactory.RegisterDimensionComparer("a", new SortAsComparer(aOrder) );

			var pvtData = createPvtData();

			var cfg = new PivotTableConfiguration() {
				Columns = new[] { "a" },
				Rows = new[] { "d" }
			};
			var pvtTbl = pvtTblFactory.Create(pvtData, cfg);
			for (int i = 0; i < 3; i++) {
				Assert.Equal(aOrder[i], pvtTbl.ColumnKeys[i].DimKeys[0]);
			}

			// check reverse order
			cfg.OrderKeys = new[] { 
				new PivotTableConfiguration.AxisKeysOrder(
					PivotTableConfiguration.TableAxis.Columns, 0, System.ComponentModel.ListSortDirection.Descending
				)
			};
			pvtTbl = pvtTblFactory.Create(pvtData, cfg);
			for (int i = 0; i < 3; i++) {
				Assert.Equal(aRevOrder[i], pvtTbl.ColumnKeys[i].DimKeys[0]);
			}
		}

    }
}
