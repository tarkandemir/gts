﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

using NReco.PivotData;
using NReco.PivotData.Output;

namespace NReco.PivotData.Examples.ToolkitPivotTableWinForms {

	/// <summary>
	/// This examples illustrates how to display pivot table in desktop applications:
	/// <list>
	///	<item>with WebBrowser control + HTML produced by PivotTableHtmlWriter</item>
	///	<item>standard DataGridView + DataTable produced by PivotTableDataTableWriter</item>
	/// </list>
	/// </summary>
	public partial class Form1 : Form {
		public Form1() {
			InitializeComponent();

			RenderWebBrowserPivotTable();

			BindDataGridViewPivotTable();
		}

		private void BindDataGridViewPivotTable() {
			var pvtData = new PivotData(
					new[] { "product", "country", "year", "month", "day"},
 					new SumAggregatorFactory("total") );
			pvtData.ProcessData( new DataTableReader( GetOrdersTable() ) );
			var pvtTbl = new PivotTable(new[]{"year","month"},new [] {"country"}, pvtData);
			var pvtDataTableWr = new PivotTableDataTableWriter("PivotTable");
			var dataTbl = pvtDataTableWr.Write(pvtTbl);

			dataGridView1.ReadOnly = true;
			dataGridView1.DataSource = dataTbl;
			dataGridView1.AutoResizeColumns( 
				DataGridViewAutoSizeColumnsMode.AllCellsExceptHeader);

			// lets use DataColumn.Caption as column header
			foreach (DataGridViewColumn col in dataGridView1.Columns) {
			  col.HeaderText = dataTbl.Columns[col.HeaderText].Caption;
			}
		}

		private void RenderWebBrowserPivotTable() {
			var pvtData = new PivotData(
					new[] { "product", "country", "year", "month", "day"},
 					new SumAggregatorFactory("total") );
			pvtData.ProcessData( new DataTableReader( GetOrdersTable() ) );
			var pvtTbl = new PivotTable(new[]{"product", "country"},new [] {"year","month"}, pvtData);

			var strWr = new StringWriter();
			var pvtTblWr = new PivotTableHtmlWriter(strWr);
			pvtTblWr.Write(pvtTbl);

			webBrowser1.DocumentText = PrepareWebBrowserContent( strWr.ToString() );
		}

		private void webBrowser1_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e) {

		}


		static DataTable GetOrdersTable() {
			// sample "orders" table that contains 1,000 rows
			var t = new DataTable("orders");
			t.Columns.Add("product", typeof(string));
			t.Columns.Add("country", typeof(string));
			t.Columns.Add("quantity", typeof(int));
			t.Columns.Add("total", typeof(decimal));
			t.Columns.Add("year", typeof(int));
			t.Columns.Add("month", typeof(int));
			t.Columns.Add("day", typeof(int));

			var countries = new [] { "USA", "United Kingdom", "Germany", "Italy", "France", "Canada", "Spain" };
			var products = new [] { "Product #1", "Product #2", "Product #3" };
			var productPrices = new decimal[] { 21, 33, 78 };

			for (int i = 1; i <= 1000; i++) {
				var q = 1+(i%6);
				var productIdx = (i+i%10)%products.Length;
				t.Rows.Add(new object[] {
					products[productIdx],
 					countries[i%countries.Length],
					q,
					q*productPrices[productIdx],
					2010 + (i%6),
					1+(i%12),
					i%29
				});
			}
			t.AcceptChanges();
			return t;

		}

		string PrepareWebBrowserContent(string bodyHtml) {
			return @"<html><head>	<style>
body {
	font-family:Arial;
}
table.pvtTable {
	font-size: 12px;
	margin:0px;
	width:100%;
	border-collapse: collapse;
	border: 1px solid #ddd;
}
table.pvtTable th, table.pvtTable td {
	border: 1px solid #ddd;
	padding: 5px;
}
		table.pvtTable th {
			text-align:center;
			vertical-align:middle;
		}
		table.pvtTable th.totals {
			font-style:italic;
			text-align:right;
			vertical-align:bottom !important;
		}
		table.pvtTable td {
			text-align:right;
		}
	</style></head><body>"+bodyHtml+"</body></html>";
		}

	}
}
