﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NReco.PivotData.Examples.ToolkitLoadPreaggregatedTotals {

	/// <summary>
	/// Implements special aggregator that always holds only last value.
	/// </summary>	 
	public class LastAggregator : IAggregator {

		object value = null;
		uint count = 0;
		string field;

		public LastAggregator(string f) {
			field = f;
		}

		public LastAggregator(string f, object state) : this(f) {
			var stateArr = state as object[];
			if (stateArr == null || stateArr.Length != 2)
				throw new InvalidOperationException("invalid state");
			count = Convert.ToUInt32(stateArr[0]);
			value = stateArr[1];
		}

		public void Push(object r, Func<object, string, object> getValue) {
			var v = getValue(r, field);
			if (v != null && !DBNull.Value.Equals(v)) {
				value = v;
				count++;
			}
		}

		public object Value {
			get { return value; }
		}

		public uint Count {
			get { return count; }
		}

		public void Merge(IAggregator aggr) {
			// just hold last merged value
			value = aggr.Value;
			count = aggr.Count;
		}

		public object GetState() {
			return new object[] { count, value };
		}
	}

	public class LastAggregatorFactory : IAggregatorFactory {

		public string Field {
			get { return fld; }
		}

		string fld;

		public LastAggregatorFactory(string field) {
			fld = field;
		}

		public IAggregator Create() {
			return new LastAggregator(fld);
		}

		public IAggregator Create(object state) {
			return new LastAggregator(fld, state);
		}

		public override bool Equals(object obj) {
			var factory = obj as LastAggregatorFactory;
			if (factory == null)
				return false;
			return factory.fld == fld;
		}

		public override string ToString() {
			return Field;
		}
	}

}
