﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using NReco.PivotData.Input;

namespace NReco.PivotData.Examples.ToolkitLoadPreaggregatedTotals {

	/// <summary>
	/// <see cref="IPivotDataSource"/> wrapper that converts all null or DBNull.Value to Key.Empty
	/// </summary>
	public class NullAsKeyEmptySource : IPivotDataSource {

		IPivotDataSource BaseSource;

		public NullAsKeyEmptySource(IPivotDataSource baseSource) {
			BaseSource = baseSource;
		}

		public void ReadData(Action<IEnumerable, Func<object, string, object>> readData) {
			BaseSource.ReadData((data, getValue) => {
				readData(data, (row, field) => {
					var val = getValue(row, field);
					if (val == null || DBNull.Value.Equals(val))
						val = Key.Empty;
					return val;
				});
			});
		}
	}
}
