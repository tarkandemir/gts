﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

using NReco.PivotData;
using NReco.PivotData.Input;
using NReco.PivotData.Output;

namespace NReco.PivotData.Examples.ToolkitLoadPreaggregatedTotals {
	public class Program {

		/// <summary>
		/// This example illustrates how to load pre-aggregated dataset with explicitely calculated totals.
		/// Use this approach for special measures calculated outside PivotData library and if their totals
		/// cannot be calculated with one of the existing aggregators (say, Sum or Average):
		///  - metrics returned by SELECT ... GROUP BY ... WITH CUBE
		///  - metrics returned by OLAP server
		/// </summary>
		static void Main(string[] args) {

			var sampleDataSource = new SampleDataSource();

			var grpRdr = new GroupedSourceReader(
				new NullAsKeyEmptySource(sampleDataSource),  // convert NULLs to Key.Empty for correct totals handling inside PivotData
				"Count");

			// lets register state composer for custom "LastAggregator"
			grpRdr.AggregatorStateComposers.Add(
				new GroupedSourceReader.ArrayAggregatorStateComposer("Last",
					// LastAggregator state is an array of 2 elements:
					// [0] = count: lets take from "Count" field
					// [1] = value (any type): lets take from field specified as parameter
					new[] {"Count", "{0}"},   // input fields for state values
					new [] {typeof(uint), typeof(object)} )   // types of state values
			);

			var pvtCfg = new PivotDataConfiguration() {
				Dimensions = new[] {"Year", "Quarter"},
				Aggregators = new[] {
					new AggregatorFactoryConfiguration("Last", new [] {"Value"})
				}
			};

			// In this example custom LastAggregator is used to hold values.
			// It is called "Last" because of its Merge behaviour: it simply keeps the last merged value
			// This allows to perform correct roll-ups if pre-aggregated values are partially ordered and totals go after 'normal' values
			// If your totals are go at the beginning you might prefer to use "FirstAggregator" logic

			// No problems if your pre-aggregated values (both normal and totals) are not go in exact order.
			// This only means that aggregator's "Merge" method cannot be defined and you'll not able to use SliceQuery class to reduce number of dimensions, and it is important to load only dimensions that are displayed in the pivot table (to avoid roll-ups).

			// IPivotData implementation should preserve input rows sequence
			// PivotData is not suitable for this; FixedPivotData should be instead
			var pvtDataState = grpRdr.ReadState(pvtCfg);
			var pvtData = new FixedPivotData(pvtCfg.Dimensions, new LastAggregatorFactory("Value"), pvtDataState);

			// lets check that pre-aggregated subtotals are used as is
			Console.WriteLine("Load pre-aggregated totals and sub-totals example");
			var pvtTbl = new PivotTable(new[] { "Year" }, new[] { "Quarter" }, pvtData );
			pvtTbl.TotalsCache = false; // not necessary for LastAggregator, but excessive as anyway our totals are pre-calculated 

			var strWr = new StringWriter();
			new PivotTableCsvWriter(strWr).Write(pvtTbl);
			Console.WriteLine(strWr.ToString());
			Console.WriteLine();

			// one more test - slice by year
			var byYearPvtData = new SliceQuery(pvtData).Dimension("Year").Execute();
			var strWr2 = new StringWriter();
			var pvtTbl2 = new PivotTable(new[] { "Year" }, null, byYearPvtData);
			pvtTbl2.TotalsCache = false;
			new PivotTableCsvWriter(strWr2).Write(pvtTbl2);
			Console.WriteLine(strWr2.ToString());
			Console.WriteLine();

			Console.WriteLine("\nPress any key to exit...");
			Console.ReadKey();
		}

		// sample data source that returns pre-aggregated data with subtotals
		public class SampleDataSource : IPivotDataSource {

			IEnumerable GetSampleData() {
				// lets assume that "Value" property that represents
				// some special metric that comes with calculated subtotals
				// IMPORTANT NOTICES: 
				//  - subtotals should go AFTER more detailed rows for correct work of LastAggregator
				//  - ALL subtotals (for all possible combinations of dimension keys) should be present
				return new object[] {
					new { Year = 2016, Quarter = "Q1", Value = 1.01, Count = 25 },
					new { Year = 2016, Quarter = DBNull.Value, Value = 1.01, Count = 25 },
					new { Year = 2017, Quarter = "Q1", Value = 1.1, Count = 13 },
					new { Year = 2017, Quarter = DBNull.Value, Value = 1.17, Count = 21},
					new { Year = DBNull.Value, Quarter = "Q1", Value = 1.03, Count = 38},
					new { Year = DBNull.Value, Quarter = DBNull.Value, Value = 1.05, Count = 17}
				};
			}

			public void ReadData(Action<IEnumerable, Func<object, string, object>> readData) {
				readData(
					GetSampleData(),
					new ObjectMember().GetValue
				);
			}

		}

	}
}
