﻿/*
 *  Copyright 2015 Vitaliy Fedorchenko (nrecosite.com)
 *
 *  Licensed under PivotData Source Code Licence (see LICENSE file).
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS 
 *  OF ANY KIND, either express or implied.
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.IO;
using System.Globalization;

using CsvHelper;
using CsvHelper.Configuration;

namespace NReco.PivotData.Examples.ToolkitCreateOfflineCube {
	
	public class JetDbCsvWriter {

		string BasePath;

		public JetDbCsvWriter(string basePath) {
			BasePath = basePath;
		}

		static Dictionary<Type,string> knownJetTypes = new Dictionary<Type,string>() {
			{typeof(string), "Text"},
			{typeof(byte), "Byte"},
			{typeof(bool), "Bit"},
			{typeof(int), "Long"},
			{typeof(long), "Long"},
			{typeof(decimal), "Currency"},
			{typeof(float), "Double"},
			{typeof(double), "Double"},
			{typeof(DateTime), "Text"}// "DateTime"}
		};
		private string GetJetDataType(Type type) {
			string jetDataType;
			if (knownJetTypes.TryGetValue(type, out jetDataType))
				return jetDataType;
			return "Text";
		}

		private void WriteCsvRecord(ICsvWriter csvWr, DataRow r) {
			for (int i=0; i<r.ItemArray.Length; i++) {
				var o = r.ItemArray[i];
				string s;
				if (o is DateTime) {
					// lets just render date value as string
					s = ((DateTime)o).ToString("d", CultureInfo.InvariantCulture);
				} else {
					s = Convert.ToString(o, CultureInfo.InvariantCulture);
				}
				csvWr.WriteField(s);
			}
			csvWr.NextRecord();
		}

		public string[] Write(DataSet ds) {
			var csvConfig = new CsvConfiguration() {
				Delimiter = ";",
				HasHeaderRecord = false
			};

			var schemaIniSb = new StringBuilder();
			var filesList = new List<string>();

			for (int tIdx=0; tIdx<ds.Tables.Count; tIdx++) {
				var tbl = ds.Tables[tIdx];
				var fileName = String.Format("table{0}.txt", tIdx);
				
				schemaIniSb.AppendFormat("[{0}]", fileName);
				schemaIniSb.AppendLine();
				schemaIniSb.AppendLine("Format=Delimited(;)");
				schemaIniSb.AppendLine("DecimalSymbol=.");
				 
				schemaIniSb.AppendLine("ColNameHeader=False");
				for (int cIdx = 0; cIdx < tbl.Columns.Count; cIdx++) {
					var col = tbl.Columns[cIdx];
					schemaIniSb.AppendFormat("Col{0}={1} {2}", cIdx+1, col.ColumnName, GetJetDataType(col.DataType) );
					schemaIniSb.AppendLine();
				}

				using (var tblCsvFileWr = new StreamWriter( Path.Combine(BasePath, fileName) )) {
					using (var csvWr = new CsvWriter(tblCsvFileWr, csvConfig)) {
						foreach (DataRow r in tbl.Rows) {
							WriteCsvRecord(csvWr, r);
						}
					}
				}

				filesList.Add(fileName);
			}

			System.IO.File.WriteAllText( Path.Combine(BasePath, "schema.ini"), schemaIniSb.ToString() );

			return filesList.ToArray();
		}

	}
}
