﻿/*
 *  Copyright 2015 Vitaliy Fedorchenko (nrecosite.com)
 *
 *  Licensed under PivotData Source Code Licence (see LICENSE file).
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS 
 *  OF ANY KIND, either express or implied.
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.IO;

using Microsoft.AnalysisServices;

namespace NReco.PivotData.Examples.ToolkitCreateOfflineCube {
	
	public class CubeGenerator {

		string ServerConnStr;

		public string DbName { get; set; }

		public string TempPath { get; set; }

		public string FactsTableName { get; set; }

		public CubeGenerator(string serverConnectionStr, string dbName) {
			ServerConnStr = serverConnectionStr;
			DbName = dbName;
			FactsTableName = "facts";
			TempPath = Environment.CurrentDirectory;
		}

		private string GetCsvDataPath() {
			return Path.Combine( TempPath ?? Path.GetTempPath(), Path.GetRandomFileName() );
		}

		private RelationalDataSource AddCsvDataSource(Database db, string basePath) {
			if (!Path.IsPathRooted(basePath))
				basePath = Path.GetFullPath(basePath);
			var csvConnString = string.Format(
				@"Provider=Microsoft.Jet.OleDb.4.0;Data Source={0};Extended Properties=""Text;HDR=NO;FMT=Delimited(;)"";", 
				basePath
			);

			var objDataSource = db.DataSources.Add("OLAP_DS");
			objDataSource.ConnectionString = csvConnString;
			objDataSource.Update();
			return objDataSource;
		}

		public void CreateCube(string cubeName, DataSet ds) {
			var csvDataBasePath = GetCsvDataPath();
			if (!Directory.Exists(csvDataBasePath))
				Directory.CreateDirectory(csvDataBasePath);

			var csvWriter = new JetDbCsvWriter( csvDataBasePath );
			var csvFiles = csvWriter.Write(ds);
			var schema = ds.Clone();
			string factsJetTblName = null;
			for (int i = 0; i < schema.Tables.Count; i++) {
				var csvJetTblName = csvFiles[i].Replace('.', '#');
				if (schema.Tables[i].TableName==FactsTableName)
					factsJetTblName = csvJetTblName;
				schema.Tables[i].TableName = csvJetTblName;
			}

			var server = new Server();
			server.Connect(ServerConnStr);
			var db = server.Databases.FindByName(DbName);
			if (db==null)
				db = server.Databases.Add(DbName);
			db.Update();
			
			var objDataSource =  AddCsvDataSource(db, csvDataBasePath);

            var objDataSourceView = db.DataSourceViews.Add("OLAP_DS_VIEW");
            objDataSourceView.DataSourceID = objDataSource.ID;
            objDataSourceView.Schema = schema;
			objDataSourceView.Update();

			// add dimensions
			for (int i = 0; i < ds.Tables.Count; i++) {
				var tbl = ds.Tables[i];
				if (tbl.TableName==FactsTableName)
					continue;
				var jetDbTblName = schema.Tables[i].TableName;

				var dimension = db.Dimensions.Add(tbl.TableName);
				dimension.Source = new DataSourceViewBinding(objDataSourceView.ID);
				var dimAttrId = dimension.Attributes.Add( tbl.Columns["key"].Caption );
				dimAttrId.Usage = AttributeUsage.Key;
				dimAttrId.KeyColumns.Add(jetDbTblName, "id", OleDbTypeConverter.GetRestrictedOleDbType(tbl.PrimaryKey[0].DataType) );
				dimAttrId.NameColumn = new DataItem(jetDbTblName, "key", 
					OleDbTypeConverter.GetRestrictedOleDbType(typeof(string)) );

				// add any additional dimension attributes
				foreach (DataColumn c in tbl.Columns) {
					if (c.ColumnName=="id" || c.ColumnName=="key") continue;
					var dimAttr = dimension.Attributes.Add( c.Caption );
					dimAttr.KeyColumns.Add(jetDbTblName, c.ColumnName, OleDbTypeConverter.GetRestrictedOleDbType(c.DataType) );
				}

				dimension.Update();
			}

			var cube = db.Cubes.FindByName(cubeName);
			if (cube!=null)
				cube.Drop();
			cube = db.Cubes.Add(cubeName);
			cube.Source = new DataSourceViewBinding(objDataSourceView.ID);

			var mg = cube.MeasureGroups.Add(FactsTableName);
			mg.ProcessingMode = ProcessingMode.LazyAggregations;

			foreach (DataColumn c in ds.Tables[FactsTableName].Columns) {
				var rel = c.Table.DataSet.Relations.Cast<DataRelation>().Where( r=>r.ParentColumns.Contains(c) ).FirstOrDefault();
				if (rel!=null) {
					var dim = db.Dimensions.FindByName(rel.ChildTable.TableName);

					var cubeDim = cube.Dimensions.Add(dim.ID);
					var MGDim = mg.Dimensions.Add(cubeDim.ID);
					var MGDimA = MGDim.Attributes.Add(dim.KeyAttribute.ID);
					MGDimA.Type = MeasureGroupAttributeType.Granularity;
					MGDimA.KeyColumns.Add(factsJetTblName, c.ColumnName, 
						OleDbTypeConverter.GetRestrictedOleDbType(c.DataType) );
				} else {
					var measure = mg.Measures.Add(c.Caption);
					measure.AggregateFunction =  AggregationFunction.Sum;
					if (c.ExtendedProperties["AggregationFunction"]!=null)
						measure.AggregateFunction = (AggregationFunction)c.ExtendedProperties["AggregationFunction"];
					measure.Source = new DataItem(factsJetTblName, c.ColumnName, 
						OleDbTypeConverter.GetRestrictedOleDbType(c.DataType) );
				}
			}

			var objPartition = mg.Partitions.Add(FactsTableName);
			objPartition.Source = new TableBinding(objDataSource.ID, null, factsJetTblName);
			objPartition.ProcessingMode = ProcessingMode.Regular;
			objPartition.StorageMode = StorageMode.Molap;

			cube.Update(UpdateOptions.ExpandFull);

			db.Process(ProcessType.ProcessFull);

			server.Disconnect();

			Directory.Delete(csvDataBasePath, true);
		}

	}
}
