﻿/*
 *  Copyright 2015 Vitaliy Fedorchenko (nrecosite.com)
 *
 *  Licensed under PivotData Source Code Licence (see LICENSE file).
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS 
 *  OF ANY KIND, either express or implied.
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Data;

using Microsoft.AnalysisServices;

using NReco.PivotData;
using NReco.PivotData.Input;
using NReco.PivotData.Output;

namespace NReco.PivotData.Examples.ToolkitCreateOfflineCube {
	
	/// <summary>
	/// Create offline cube (.cub file) by PivotData
	/// </summary>
	/// <remarks>
	/// PREREQUISITIES (install them before building this example):
	/// <list>
	///		<item>
	///			SQL Server AMO package ( SQL_AS_AMO.msi , https://www.microsoft.com/en-us/download/details.aspx?id=42295 )
	///		</item>
	///		<item>
	///			OLE DB for OLAP provider ( SQL_AS_OLEDB.msi, https://www.microsoft.com/en-us/download/details.aspx?id=42295 )
	///		</item>
	///		<item>
	///			MS JET DB (Access) Engine ( needed only if Office components are not installed: http://www.microsoft.com/en-us/download/details.aspx?id=13255 )
	///		</item>
	/// </list>
	/// Important notice: 'Microsoft.Jet.OleDb.4.0' OLE provider used for reading csv data by OLAP Engine is available only for x86 applications.
	/// As result application that generates offline cube should be compiled for x86 platform.
	/// </remarks>
	class Program {
		static void Main(string[] args) {

			var offlineCubeFile = Path.Combine(Environment.CurrentDirectory, "test.cub");

			if (System.IO.File.Exists(offlineCubeFile))
				System.IO.File.Delete(offlineCubeFile);

			Console.WriteLine("Reading sample PivotData from 'Baltimore_City_Empl_Salaries_2014' ...");

			var pvtDataFactory = new PivotDataFactory();
			var pvtData = new CubeFileReader("Baltimore_City_Empl_Salaries_2014", pvtDataFactory).Read();
			
			Console.WriteLine("Exporting PivotData to DataSet with 'star' data schema ...");
			
			var ds = new DataSet();
			var starSchemaWr = new DataSetStarSchemaWriter(ds);
			var starSchemaResult = starSchemaWr.Write(pvtData);

			// lets add additional dimension attributes
			foreach (DataTable t in starSchemaResult.DimensionTables) {
				if (t.Columns["key"].DataType==typeof(DateTime))
					AddDateDimensionDerivedAttributes(t);
			}

			// lets configure suitable aggregate function
			var pvtCfg = pvtDataFactory.GetConfiguration(pvtData);
			for (int i=0; i<pvtCfg.Aggregators.Length; i++) {
				var aggrCfg = pvtCfg.Aggregators[i];
				var aggrFunction = AggregationFunction.Sum; // default aggr function for measure
				switch (aggrCfg.Name) {
					case "Min":
						aggrFunction = AggregationFunction.Min;
 						break;
					case "Max":
						aggrFunction = AggregationFunction.Max;
 						break;
					case "Average":
						aggrFunction = AggregationFunction.AverageOfChildren;
 						break;
				}
				starSchemaResult.FactsTableMeasureColumns[i].ExtendedProperties["AggregationFunction"] = aggrFunction;
			}

			Console.WriteLine("Generating offline cube by DataSet...");

			var cubeGenerator = new CubeGenerator(
				String.Format(@"Data Source={0}", offlineCubeFile),
				"Test"
			);
			cubeGenerator.CreateCube("Baltimore City Employee Salaries", ds);

			Console.WriteLine("Done! Now you may open generated 'test.cub' with Excel");
		}

		static void AddDateDimensionDerivedAttributes(DataTable tbl) {
			tbl.Columns.Add("Year", typeof(int));
			tbl.Columns.Add("Month", typeof(int));
			tbl.Columns.Add("Day", typeof(int));
			tbl.Columns.Add("Quarter", typeof(string));
			foreach (DataRow r in tbl.Rows) {
				if (r["key"] != null && !r.IsNull("key")) { 
					var dt = (DateTime)r["key"];
					r["Year"] = dt.Year;
					r["Month"] = dt.Month;
					r["Day"] = dt.Day;
					r["Quarter"] = String.Format("Q{0}", (int)Math.Ceiling((float)(dt.Month+1)/3) );
				}
			}
		}

	}
}
