﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace NReco.PivotData.Examples.ToolkitPivotDataServiceSource {

	// excludes entries with totals (if present)
	public class SkipTotalKeysPivotTableWrapper : IPivotTable {

		IPivotTable PvtTbl;

		public SkipTotalKeysPivotTableWrapper(IPivotTable pvtTbl) {
			PvtTbl = pvtTbl;
		}

		public string[] Columns => PvtTbl.Columns;

		public string[] Rows => PvtTbl.Rows;

		ValueKey[] FilteredColumnKeys = null;

		public ValueKey[] ColumnKeys {
			get {
				return FilteredColumnKeys ?? (FilteredColumnKeys = FilterTotalKeys(PvtTbl.ColumnKeys));
			}
		}

		ValueKey[] FilteredRowKeys = null;

		public ValueKey[] RowKeys {
			get {
				return FilteredRowKeys ?? (FilteredRowKeys = FilterTotalKeys(PvtTbl.RowKeys));
			}
		}

		ValueKey[] FilterTotalKeys(ValueKey[] keys) {
			var l = new List<ValueKey>(keys.Length);
			for (int i = 0; i < keys.Length; i++) {
				var k = keys[i];
				if (!k.HasEmpty)
					l.Add(k);
			}

			return l.ToArray();
		}

		public IPivotData PivotData => PvtTbl.PivotData;

		public IAggregator GetValue(ValueKey rowKey, ValueKey colKey) {
			return PvtTbl.GetValue(rowKey, colKey);
		}
	}
}
