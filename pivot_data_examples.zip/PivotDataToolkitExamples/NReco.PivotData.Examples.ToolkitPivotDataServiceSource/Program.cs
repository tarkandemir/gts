﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;

namespace NReco.PivotData.Examples.ToolkitPivotDataServiceSource {

	/// <summary>
	/// This example illustrates how to use PivotData Microservice API endpoint as a data source:
	/// load pivot table JSON export into PivotData class instance.
	/// </summary>
	class Program {
		static void Main(string[] args) {

			// this example connects to PivotData microservice online demo
			var pivotDataService = new PivotDataServiceClient(
						"http://pivotdataservice.nrecosite.com/pivotdataservice/",
						"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6WyJkZW1vQHNlZWt0YWJsZS5jb20iLCJkZW1vQHNlZWt0YWJsZS5jb20iXSwibmFtZWlkIjpbIjEiLCIxIl0sInVuaXF1ZV9uYW1lIjpbIlNlZWtUYWJsZSBEZW1vIiwiU2Vla1RhYmxlIERlbW8iXSwicmVhZG9ubHkiOlsiVHJ1ZSIsIlRydWUiXSwibmJmIjoxNTM4NTczMTI2LCJleHAiOjE4ODQxNzMxMjYsImlhdCI6MTUzODU3MzEyNiwiaXNzIjoiU1QifQ.LlMWzVC0E0gcLCn6Wb9gw03y4IealqLRKPnCiZm-kr8");

			var reportJson = "{\"Rows\":[{\"Name\":\"Region\"}],\"Columns\":[{\"Name\":\"Order Date (Year)\"}, {\"Name\":\"Order Date (Month)\"}],\"SubtotalColumns\":true,\"Measures\":[{\"Name\":\"Count\"},{\"Name\":\"SumOfSales\"}]}";


			var pvtData1 = pivotDataService.LoadPivotDataFromJsonExportAsync(
					"7f74de2546804cf9b12da34d7e5af382",
					reportJson,
					new IAggregatorFactory[] {
						// for each measure used in report
						new CountAggregatorFactory(), new SumAggregatorFactory("Sales") 
					}
				).Result;

			var grandTotal = pvtData1[Key.Empty, Key.Empty, Key.Empty];
			Console.WriteLine("GRAND TOTAL: COUNT = {0}, SALES = {1}",
				grandTotal.AsComposite().Aggregators[0].Value,
				grandTotal.AsComposite().Aggregators[1].Value);

			var atlanticTotal = pvtData1["Atlantic", Key.Empty, Key.Empty];
			Console.WriteLine("Atlantic: COUNT = {0}, SALES = {1}", 
				atlanticTotal.AsComposite().Aggregators[0].Value,
				atlanticTotal.AsComposite().Aggregators[1].Value);



			Console.WriteLine();
			Console.WriteLine("Load PivotData with pre-calculated row/column/grand totals.");
			var pvtData2 = pivotDataService.LoadPivotDataFromJsonExportAsync(
					"7f74de2546804cf9b12da34d7e5af382",	reportJson, null).Result;

			var grandTotal2 = pvtData2[Key.Empty, Key.Empty, Key.Empty];
			Console.WriteLine("PRE-CALCULATED GRAND TOTAL: COUNT = {0}, SALES = {1}",
				grandTotal2.AsComposite().Aggregators[0].Value,
				grandTotal2.AsComposite().Aggregators[1].Value);

			var pvtTbl = new PivotTable(
				new[] { "Region" }, 
				new[] { "Order Date.Year", "Order Date.Month" },  // important - here you need to use dimension _label_, it may differ from the _name_ that is specified in the report JSON config
				pvtData2);
			pvtTbl.TotalsCache = false; // important - should be disabled for pre-calculated totals
			var fltPvtTbl = new SkipTotalKeysPivotTableWrapper(pvtTbl);
			var strWr = new StringWriter();
			new Output.PivotTableCsvWriter(strWr).Write(fltPvtTbl);
			Console.WriteLine(strWr.ToString());

			Console.WriteLine("Press any key...");
			Console.ReadKey();
		}
	}
}
