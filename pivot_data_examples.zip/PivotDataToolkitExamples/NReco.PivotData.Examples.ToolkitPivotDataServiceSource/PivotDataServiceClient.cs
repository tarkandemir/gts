﻿using System;
using System.Collections.Generic;
using System.Text;

using System.Linq;
using System.Threading.Tasks;
using System.IO;
using NReco.PivotData;
using NReco.PivotData.Input;
using System.Net.Http;
using System.Collections;
using Newtonsoft.Json;

namespace NReco.PivotData.Examples.ToolkitPivotDataServiceSource {
	
	public class PivotDataServiceClient {

		string EndpointBaseUrl;
		string JWT;

		public PivotDataServiceClient(string endpointBaseUrl, string jwt) {
			EndpointBaseUrl = endpointBaseUrl;
			JWT = jwt;
		}

		public async Task<IPivotData> LoadPivotDataFromJsonExportAsync(string cubeId, string reportJson, IAggregatorFactory[] aggrFactories) {
			using (var httpClient = new HttpClient()) {
				var postKeyValues = new List<KeyValuePair<string, string>>();
				postKeyValues.Add(new KeyValuePair<string, string>("pvtReportJson", reportJson));
				if (aggrFactories == null) {
					// no factories = load values as non-mergable aggregators
					// try to load sub-totals in this case
					postKeyValues.Add(new KeyValuePair<string, string>("enableJsonPivotSubtotals", "1"));
				}

				if (JWT != null)
					httpClient.DefaultRequestHeaders.Add("Authorization", "Bearer " + JWT);
				var httpResponse = await httpClient.PostAsync(EndpointBaseUrl + "api/cube/" + cubeId + "/pivot/export/json", new FormUrlEncodedContent(postKeyValues));
				if (!httpResponse.IsSuccessStatusCode)
					throw new Exception("PivotData microservice API call error");
				using (var httpResponseStream = await httpResponse.Content.ReadAsStreamAsync()) {
					using (var rdr = new StreamReader(httpResponseStream)) {
						var exportJson = new JsonSerializer().Deserialize<PivotTableJsonModel>(new JsonTextReader(rdr));
						return LoadPivotDataFromJsonExport(exportJson, aggrFactories);
					}
				}
			}
		}


		public class PivotTableJsonModel {
			public string[] Rows { get; set; }
			public string[] Columns { get; set; }
			public object[][] RowKeys { get; set; }
			public object[][] ColumnKeys { get; set; }

			public object[][] Values { get; set; }

			public string[] MeasureLabels { get; set; }

			public object[] ColumnTotals { get; set; }
			public object[] RowTotals { get; set; }

			public object GrandTotal { get; set; }
		}

		public IPivotData LoadPivotDataFromJsonExport(PivotTableJsonModel exportJson, IAggregatorFactory[] aggrFactories) {
			var dims = exportJson.Rows.Union(exportJson.Columns).ToArray();
			var loadTotals = false;
			if (aggrFactories==null) {
				// use 'FirstValueAggregator' that just holds value as-is
				// it doesn't support roll-ups, so resulting PivotData object is not suitable for roll-ups 
				// (slicing with SliceQuery or calculating sub-totals that are not present in the JSON export)
				aggrFactories = new IAggregatorFactory[exportJson.MeasureLabels.Length];
				for (int i = 0; i < aggrFactories.Length; i++)
					aggrFactories[i] = new FirstValueAggregatorFactory(exportJson.MeasureLabels[i]);
				loadTotals = true;
			}
			var pvtData = new PivotData(dims, aggrFactories.Length > 1 ? new CompositeAggregatorFactory(aggrFactories) : aggrFactories[0]);

			var pvtDataFactory = new PivotDataFactory();
			pvtDataFactory.RegisterAggregator("FirstValue", typeof(FirstValueAggregatorFactory),
					(t, args) => {
						if (args == null || args.Length < 1)
							throw new ArgumentException("Invalid FirstValue configuration: expected field name as a first param.");
						return new FirstValueAggregatorFactory(Convert.ToString(args[0]));
					},
					(aggrFactory) => new object[] { ((FirstValueAggregatorFactory)aggrFactory).Field }
				);
			var pvtDataCfg = pvtDataFactory.GetConfiguration(pvtData);

			var source = new PivotTableJsonModelDataSource(exportJson, loadTotals);

			var fieldMapping = new Dictionary<string, string>();
			for (int aggrIdx = 0; aggrIdx < pvtDataCfg.Aggregators.Length; aggrIdx++) {
				var aggrCfg = pvtDataCfg.Aggregators[aggrIdx];
				var fld = aggrCfg.Name;
				if (aggrCfg.Params != null)
					fld = String.Join("_", aggrCfg.Params.Select(p => Convert.ToString(p)).ToArray()) + "_" + fld;
				fieldMapping[fld] = exportJson.MeasureLabels[aggrIdx];
			}
			var mappedColsSource = new FieldMappingDataSource(source, fieldMapping);

			// prepare GroupedSourceReader and CsvReader
			var groupedSourceRdr = new GroupedSourceReader(mappedColsSource,
				"Count");
			groupedSourceRdr.AggregatorStateComposers.Add(
				new GroupedSourceReader.ArrayAggregatorStateComposer("FirstValue",
					new[] { "Count", "{0}_FirstValue" },
					new Type[] { typeof(uint), typeof(object) }
				)
			);

			var pvtDataState = groupedSourceRdr.ReadState(pvtDataCfg);
			if (loadTotals) {
				// for pre-calculated totals FixedPivotData should be used
				return new FixedPivotData(pvtDataCfg.Dimensions, pvtData.AggregatorFactory, pvtDataState);
			}
			pvtData.SetState(pvtDataState);
			return pvtData;

		}

		internal class PivotTableJsonModelDataSource : IPivotDataSource {
			PivotTableJsonModel JsonModel;
			Dictionary<string, int> RowDimToIdx;
			Dictionary<string, int> ColDimToIdx;
			Dictionary<string, int> MeasureToIdx;
			bool LoadTotals;

			internal PivotTableJsonModelDataSource(PivotTableJsonModel jsonModel, bool loadTotals) {
				LoadTotals = loadTotals;
				JsonModel = jsonModel;
				RowDimToIdx = getIndex(JsonModel.Rows);
				ColDimToIdx = getIndex(JsonModel.Columns);
				MeasureToIdx = getIndex(JsonModel.MeasureLabels);
			}

			Dictionary<string,int> getIndex(string[] arr) {
				var res = new Dictionary<string, int>(arr.Length);
				for (int i = 0; i < arr.Length; i++)
					res[arr[i]] = i;
				return res;
			}

			IEnumerable getUnpivotedData() {
				if (JsonModel.Rows.Length > 0 && JsonModel.Columns.Length > 0) {
					for (int rIdx = 0; rIdx < JsonModel.RowKeys.Length; rIdx++)
						for (int cIdx = 0; cIdx < JsonModel.ColumnKeys.Length; cIdx++) {
							yield return new UnpivotedDataEntry() {
								ColKeys = JsonModel.ColumnKeys[cIdx],
								RowKeys = JsonModel.RowKeys[rIdx],
								Value = JsonModel.Values[rIdx][cIdx]
							};
						}
				}
				if ((JsonModel.Rows.Length>0 && JsonModel.Columns.Length==0) || LoadTotals) {
					var emptyArr = new object[0];
					// no columns
					for (int rIdx = 0; rIdx < JsonModel.RowKeys.Length; rIdx++) {
						yield return new UnpivotedDataEntry() {
							ColKeys = emptyArr,
							RowKeys = JsonModel.RowKeys[rIdx],
							Value = JsonModel.RowTotals[rIdx]
						};
					}
				}
				if ((JsonModel.Columns.Length>0 && JsonModel.Rows.Length==0) || LoadTotals) {
					var emptyArr = new object[0];
					// no rows
					for (int cIdx = 0; cIdx < JsonModel.ColumnKeys.Length; cIdx++) {
						yield return new UnpivotedDataEntry() {
							ColKeys = JsonModel.ColumnKeys[cIdx],
							RowKeys = emptyArr,
							Value = JsonModel.ColumnTotals[cIdx]
						};
					}
				} 
				if ((JsonModel.Columns.Length == 0 && JsonModel.Rows.Length == 0) || LoadTotals) {
					var emptyArr = new object[0];
					yield return new UnpivotedDataEntry() {
						ColKeys = emptyArr,
						RowKeys = emptyArr,
						Value = JsonModel.GrandTotal
					};
				}
			}

			object getValue(object o, string field) {
				var entry = (UnpivotedDataEntry)o;
				if (RowDimToIdx.TryGetValue(field, out var rowIdx)) {
					return rowIdx<entry.RowKeys.Length ? entry.RowKeys[rowIdx] : Key.Empty;
				} else if (ColDimToIdx.TryGetValue(field, out var colIdx)) {
					return colIdx<entry.ColKeys.Length ? entry.ColKeys[colIdx] : Key.Empty;
				} else if (MeasureToIdx.TryGetValue(field, out var msrIdx)) {
					if (entry.Value is IList aggrValues) {
						return aggrValues[msrIdx];
					} else {
						return entry.Value;
					}
				} else if (field=="Count") {
					// if there is no "Count" measure in the JSON export
					// let's return just 1
					// NOTE: merge of some aggregators may give incorrect result in this case (like AverageAggregator)
					return 1;
				}

				throw new Exception("Unknown field: " + field);
			}

			public void ReadData(Action<IEnumerable, Func<object, string, object>> handler) {
				handler(getUnpivotedData(), (row, field) => {
					var val = getValue(row, field);
					if (val is Newtonsoft.Json.Linq.JValue jVal)
						val = jVal.Value;
					if (field == "Count" && val == null)
						return 0;
					return val;
				});
			}

			internal class UnpivotedDataEntry {
				internal object[] RowKeys;
				internal object[] ColKeys;
				internal object Value;
			}
		}

		public class FieldMappingDataSource : IPivotDataSource {

			IDictionary<string, string> Mapping;
			IPivotDataSource BaseSource;

			public FieldMappingDataSource(IPivotDataSource baseSource, IDictionary<string,string> mapping) {
				Mapping = mapping;
				BaseSource = baseSource;
			}

			public void ReadData(Action<IEnumerable, Func<object, string, object>> readData) {
				BaseSource.ReadData((data, getValue) => {
					readData(data, (row, field) => {
						if (Mapping.TryGetValue(field, out var mappedField))
							field = mappedField;
						return getValue(row, field);
					});
				});
			}
		}


	}
}
