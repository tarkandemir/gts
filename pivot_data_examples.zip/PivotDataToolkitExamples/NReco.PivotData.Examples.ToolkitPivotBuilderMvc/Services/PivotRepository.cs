﻿/*
 *  Copyright 2015-2023 Vitaliy Fedorchenko (nrecosite.com)
 *
 *  Licensed under PivotData Source Code Licence (see LICENSE file).
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS 
 *  OF ANY KIND, either express or implied.
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.IO;

using PivotBuilderMvc.Models;
using NReco.PivotData;
using NReco.PivotData.Input;
using Microsoft.Extensions.Caching.Memory;

namespace PivotBuilderMvc.Services {

	public class PivotRepository {

		Dictionary<string,ICube> Cubes;
		IMemoryCache MemCache;

		public PivotRepository(IEnumerable<ICube> cubes, IMemoryCache memCache) {
			MemCache = memCache;
			Cubes = new Dictionary<string,ICube>();
			foreach (var c in cubes)
				Cubes[c.Id] = c;
		}

		public IEnumerable<ICube> GetCubes() {
			return Cubes.Values.ToArray();
		}

		public ICube GetCube(string cubeName) {
			ICube cube = null;
			if (!Cubes.TryGetValue(cubeName, out cube))
				throw new Exception("Unknown cube: "+cubeName);
			// lets wrap ICube implementation with cache wrapper
			// it is especially useful for cases when pivot table data calculation takes
			// significant amount of time
			return new CacheCubeWrapper( cube, MemCache );
		}


		string[] GetPivotTableDims(PivotTableConfiguration config) {
			var allDims = new HashSet<string>();
			if (config.Rows != null)
				foreach (var rowDim in config.Rows)
					allDims.Add(rowDim);
			if (config.Columns != null)
				foreach (var colDim in config.Columns)
					allDims.Add(colDim);
			return allDims.ToArray();
		}

		/// <summary>
		/// Resolves "LabelText" with cube-defined defaults that may be configured 
		/// when PivotDataConfigurationEx and/or AggregatorFactoryConfigurationEx are used.
		/// </summary>
		public void ResolveMembersLabelTextFromCubeConfig(PivotTableReportConfig pvtReportCfg) {
			var cube = GetCube(pvtReportCfg.CubeName);
			var cubeCfg = cube.GetConfiguration();

			if (pvtReportCfg.Rows != null)
				foreach (var rowDim in pvtReportCfg.Rows)
					if (rowDim.LabelText == null)
						rowDim.LabelText = getDimLabel(rowDim.Name);
			if (pvtReportCfg.Columns != null)
				foreach (var colDim in pvtReportCfg.Columns)
					if (colDim.LabelText == null)
						colDim.LabelText = getDimLabel(colDim.Name);
			if (pvtReportCfg.Measures != null)
				foreach (var msr in pvtReportCfg.Measures)
					if (msr.LabelText == null)
						msr.LabelText = getMsrLabel(msr);

			string getDimLabel(string dimName) {
				if (cubeCfg is PivotDataConfigurationEx cubeCfgEx)
					foreach (var dim in cubeCfgEx.Dimensions)
						if (dim.Name == dimName && dim.LabelText != null)
							return dim.LabelText;
				return null;
			}
			string getMsrLabel(PivotTableReportConfig.Measure msr) {
				for (int msrIdx = 0; msrIdx < cubeCfg.Aggregators.Length; msrIdx++) {
					var aggrCfg = cubeCfg.Aggregators[msrIdx];
					if (aggrCfg is AggregatorFactoryConfigurationEx aggrCfgEx
						&& ((aggrCfgEx.CubeSchemaName != null && aggrCfgEx.CubeSchemaName == msr.Name) || msrIdx.ToString()==msr.Name)
						&& aggrCfgEx.CubeSchemaLabelText != null) {
						return aggrCfgEx.CubeSchemaLabelText;
					}
				}
				return null;
			}
		}

		public PivotTableResult CreatePivotTable(PivotTableReportConfig pvtReportCfg, bool forUi) {
			var cube = GetCube(pvtReportCfg.CubeName);

			var pvtTblCfg = pvtReportCfg.GetPivotTableConfig(cube.GetConfiguration());
			var pvtData = cube.LoadPivotData(GetPivotTableDims(pvtTblCfg), pvtTblCfg.Measures);

			// apply keyword filter
			if (!String.IsNullOrWhiteSpace(pvtReportCfg.Filter)) {
				var cubeFilter = new CubeKeywordFilter(pvtReportCfg.Filter);
				pvtData = cubeFilter.Filter(pvtData);
			}

			var pvtTblFactory = new PivotTableFactory();
			// report measures are selected by ICube.LoadPivotData
			// we provide specially prepared IPivotData instance to PivotTableFactory and no need to slice it additionally
			pvtTblCfg.Measures = null;
			PivotTable pvtTblImpl = pvtTblFactory.Create(pvtData, pvtTblCfg);
			pvtTblImpl.TotalsCache = !cube.AreTotalsPrecalculated(pvtTblCfg.Measures);
			IPivotTable pvtTbl = pvtTblImpl;

			var res = new PivotTableResult() {
				BasePivotTable = pvtTbl
			};

			var expandCollapseEnabled = pvtReportCfg.ExpandCollapse != null && pvtReportCfg.ExpandCollapse.Enabled;

			var hasTopLimits = pvtReportCfg.LimitColumns.HasValue || pvtReportCfg.LimitRows.HasValue;
			var limitRows = pvtReportCfg.LimitRows.HasValue ? pvtReportCfg.LimitRows.Value : Int32.MaxValue;
			var limitCols = pvtReportCfg.LimitColumns.HasValue ? pvtReportCfg.LimitColumns.Value : Int32.MaxValue;
			if (!expandCollapseEnabled) {
				// without Expand/Collapse top N limits are applied first
				if (hasTopLimits) {
					// apply TopPivotTable wrapper if limits are specified
					pvtTbl = new TopPivotTable(pvtTbl, limitRows, limitCols);
				}
			}

			for (int i = 0; i < pvtReportCfg.Measures.Length; i++) {
				var m = pvtReportCfg.Measures[i];
				if (m.Difference.HasValue)
					pvtTbl = new DifferencePivotTable(pvtTbl, m.Difference.Value, i) {
						Percentage = m.DifferenceAsPercentage
					};
				if (m.Percentage.HasValue)
					pvtTbl = new PercentagePivotTable(pvtTbl, m.Percentage.Value, i);
				if (m.RunningTotal.HasValue)
					pvtTbl = new RunningValuePivotTable(pvtTbl, m.RunningTotal.Value, i);
				if (m.Heatmap.HasValue)
					pvtTbl = new HeatmapPivotTable(pvtTbl, m.Heatmap.Value, i);
			}

			if (expandCollapseEnabled) {
				// Collapse wrapper should go _before_ "PaginatePivotTable" or "TopPivotTable"
				res.CollapsePvtTbl = new CollapsePivotTable(pvtTbl, pvtReportCfg.ExpandCollapse);
				pvtTbl = res.CollapsePvtTbl;

				// for Expand/Collapse limits should be applied after CollapsePivotTable
				if (hasTopLimits) {
					pvtTbl = new TopPivotTable(pvtTbl, limitRows, limitCols);
				}
			}

			// pagination
			var hasRowPage = pvtReportCfg.RowPage != null && !pvtReportCfg.LimitRows.HasValue;
			var hasColPage = pvtReportCfg.ColumnPage != null && !pvtReportCfg.LimitColumns.HasValue;
			if (hasRowPage || hasColPage) {
				var rowPage = hasRowPage ? pvtReportCfg.RowPage : new PaginatePivotTable.Page(0, Int32.MaxValue);
				var colPage = hasColPage ? pvtReportCfg.ColumnPage : new PaginatePivotTable.Page(0, Int32.MaxValue);
				var pagePvtTbl = new PaginatePivotTable(pvtTbl, rowPage, colPage);
				if (!forUi) {
					pagePvtTbl.IncludePrevNextGroups = false;
				} else {
					// metadata JSON for UI should NOT contain 'virtual' rows/cols
					// that may be added by PaginatePivotTable for UI navigation purposes
					res.JsonMetadataPivotTable = new PaginatePivotTable(pvtTbl, rowPage, colPage) {
						IncludePrevNextGroups = false
					};
				}
				pvtTbl = pagePvtTbl;
			}

			res.FinalPivotTable = pvtTbl;
			if (res.JsonMetadataPivotTable == null)
				res.JsonMetadataPivotTable = res.FinalPivotTable;
			if (res.CollapsePvtTbl != null) {
				// expand/collapse pivot table always uses absolute indexes
				// and metadata should reflect that 
				res.JsonMetadataPivotTable = res.BasePivotTable;
			}
			return res;
		}

		public class PivotTableResult {

			public IPivotTable BasePivotTable { get; set; }

			public IPivotTable FinalPivotTable { get; set; }

			public CollapsePivotTable CollapsePvtTbl { get; set; }

			public IPivotTable JsonMetadataPivotTable { get; set; }

		}


	}
}