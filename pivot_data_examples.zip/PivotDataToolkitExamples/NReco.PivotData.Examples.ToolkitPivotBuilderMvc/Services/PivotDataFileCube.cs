﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.IO;

using NReco.PivotData;
using NReco.PivotData.Input;

namespace PivotBuilderMvc.Services {
	
	/// <summary>
	/// Cube for serialized PivotData file (can be created with NReco.PivotData.Output.CubeFileWriter from PivotData class instance). 
	/// </summary>
	public class PivotDataFileCube : ICube {

		string CubeFileName;

		public string Id { get; private set; }

		public string Name { get; set; }

		public PivotDataFileCube(string cubeId, string cubeFileName) {
			Id = cubeId;
			CubeFileName = cubeFileName;
			Name = cubeId;
		}

		IPivotData LoadCubeFromFile() {
			var cubeRdr = new CubeFileReader(CubeFileName);
			return cubeRdr.Read();
		}

		public PivotDataConfiguration GetConfiguration() {
			return new PivotDataFactory().GetConfiguration(LoadCubeFromFile());
		}

		public IPivotData LoadPivotData(string[] dims, int[] aggrs) {
			var savedCube = LoadCubeFromFile();
			var sliceQuery = new SliceQuery(savedCube);
			foreach (var dim in dims)
				sliceQuery.Dimension(dim);
			foreach (var aggrIdx in aggrs)
				sliceQuery.Measure(aggrIdx);
			return sliceQuery.Execute();
		}
	}

}