﻿using System;
using Microsoft.Extensions.Caching.Memory;
using NReco.PivotData;

namespace PivotBuilderMvc.Services {

	/// <summary>
	/// Cache wrapper for better UX on sort/filter actions.
	/// </summary>
	public class CacheCubeWrapper : ICube {

		ICube Cube;

		public string Id {
			get { return Cube.Id; }
		}

		public string Name {
			get { return Cube.Name; }
		}

		IMemoryCache MemoryCache;

		public CacheCubeWrapper(ICube cube, IMemoryCache memoryCache) {
			MemoryCache = memoryCache;
			Cube = cube;
		}

		public bool AreTotalsPrecalculated(int[] aggrs) => Cube.AreTotalsPrecalculated(aggrs);

		public PivotDataConfiguration GetConfiguration() {
			var cacheKey = "PivotDataConfiguration:"+Id;
			var pvtCfg = MemoryCache.Get(cacheKey) as PivotDataConfiguration;
			if (pvtCfg == null) {
				pvtCfg = Cube.GetConfiguration();
				MemoryCache.Set(cacheKey, pvtCfg);
			}
			return pvtCfg;
		}

		public IPivotData LoadPivotData(string[] dims, int[] aggrs) {
			var cacheKey = "PivotData:"+Id+":dims:"+String.Join("#", dims)+":aggrs:"+String.Join("#", aggrs);
			var pvtData = MemoryCache.Get(cacheKey) as IPivotData;
			if (pvtData == null) {
				pvtData = Cube.LoadPivotData(dims, aggrs);
				MemoryCache.Set(cacheKey, pvtData);
			}
			return pvtData;
		}
	}
}