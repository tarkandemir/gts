﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace PivotBuilderMvc.Models {
	
	public class ProjectsDashboard {

		public string CompletionPivotTableJson { get; set; }
		public string CompletionPivotTableHtml { get; set; }

		public string ActiveTasksByTypePvtTblJson { get; set; }
		public string ClosedTasksByTypePvtTblJson { get; set; }
		public string TasksByTypePivotTableHtml { get; set; }
	}
}