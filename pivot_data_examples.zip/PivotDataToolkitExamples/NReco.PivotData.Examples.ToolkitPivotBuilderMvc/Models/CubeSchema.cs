﻿using System;
using System.Collections.Generic;
using System.Linq;

using NReco.PivotData;

namespace PivotBuilderMvc.Models {

	/// <summary>
	/// This is API model that represents cube configuration as it is exposed to the client side.
	/// </summary>
	public class CubeSchema {

		public string Id { get; set; }
		public string Name { get; set; }

		public CubeMemberSchema[] Dimensions { get; set; }

		public CubeMemberSchema[] Measures { get; set; }

		public CubeSchema(string id, string name, PivotDataConfiguration cubeCfg) {
			Id = id;
			Name = name;
			Dimensions = cubeCfg is PivotDataConfigurationEx cubeCfgEx ? cubeCfgEx.Dimensions 
					: cubeCfg.Dimensions.Select(d => new CubeMemberSchema() { LabelText = d, Name = d } ).ToArray();
			
			Measures = cubeCfg.Aggregators.Select( (aggrCfg, i) => {
				var aggrCfgEx = aggrCfg as AggregatorFactoryConfigurationEx;
				return new CubeMemberSchema() {
					Name = aggrCfgEx?.CubeSchemaName ?? i.ToString(),
					LabelText = aggrCfgEx?.CubeSchemaLabelText ?? FormatMeasureLabel(aggrCfg)
				};
			}).ToArray();
		}

		string FormatMeasureLabel(AggregatorFactoryConfiguration aggr) {
			var lbl = aggr.Name;
			if (aggr.Params!=null && aggr.Params.Length>0)
				lbl += " of "+String.Join(", ", aggr.Params.Select(p=>p.ToString()).ToArray() );
			return lbl;
		}

		public class CubeMemberSchema {
			public string Name { get; set; }
			public string LabelText { get; set; }

			public CubeMemberSchema() { }

			public CubeMemberSchema(string name, string label) {
				Name = name;
				LabelText = label;
			}

		}
	}

	public class PivotDataConfigurationEx : PivotDataConfiguration {

		CubeSchema.CubeMemberSchema[] _Dimensions;

		public new CubeSchema.CubeMemberSchema[] Dimensions {
			get { return _Dimensions; }
			set {
				_Dimensions = value;
				base.Dimensions = value.Select(d => d.Name).ToArray();
			}
		}

	}

	public class AggregatorFactoryConfigurationEx : AggregatorFactoryConfiguration {

		public string CubeSchemaName { get; set; }

		public string CubeSchemaLabelText { get; set; }

		public AggregatorFactoryConfigurationEx(string name, object[] aggrParams) : base(name, aggrParams) {

		}

	}

}