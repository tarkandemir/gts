﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Data;

using Microsoft.AnalysisServices.AdomdClient;
using NReco.PivotData.Input;
using NReco.PivotData.Output;

namespace NReco.PivotData.Examples.ToolkitAdomdSource {

	/// <summary>
	/// This example illustrates how to use SSAS (OLAP server) cube as a data source for PivotData and pivot tables generation.
	/// </summary>
	/// <remarks>
	class Program {

		static void Main(string[] args) {

			// specify your SSAS XMLA endpoint here
			var adomdConn = new AdomdConnection(@"Data Source=https://demos.telerik.com/olap/msmdpump.dll;Catalog=Adventure Works DW 2008R2");

			// NOTE: measures should be selected on COLUMNS (0)
			// all dimensions should come on 1, 2, 3 etc, but it is more efficient to make crossjoin and select all dims on 1
			var mdx = @"SELECT 
				NON EMPTY CROSSJOIN([Customer].[Country].ALLMEMBERS,[Product].[Category].ALLMEMBERS) DIMENSION PROPERTIES MEMBER_CAPTION ON ROWS,
				NON EMPTY { [Measures].[Internet Sales Amount],[Measures].[Internet Order Count] } ON COLUMNS FROM [Adventure Works]";

			var cmd = adomdConn.CreateCommand();
			cmd.CommandText = mdx;

			// use this method to get raw data provided by AdomdDataReader for debug purposes
			//ReadDataReaderRaw(cmd);
			//return;

			var dbCmdSource = new DbCommandSource(cmd);

			// handle AdomdDataReader field names of dimensions
			// for '[HireDate].[Year].Members' data reader name is smth like '[HireDate].[Year].[Year].[MEMBER_CAPTION]'
			var adomdSource = new ResolveAdomdSource(dbCmdSource,
				"[Measures].[Internet Order Count]"   // measure field used to skip rows with NULLs in measures
			);

			// handle NULLs as Key.Empty for correct load of sub-totals and totals
			var nullAsKeyEmptySource = new NullAsKeyEmptySource(adomdSource);

			var grpRdr = new GroupedSourceReader(
				nullAsKeyEmptySource,
				"[Measures].[Internet Order Count]"  // this is field name for column with 'count' values
			);

			// register a state composer for custom "FirstAggregator"
			grpRdr.AggregatorStateComposers.Add(
				new GroupedSourceReader.ArrayAggregatorStateComposer("First",
					// FirstAggregator state is an array of 2 elements:
					// [0] = count: take from "[Measures].[Count]" field
					// [1] = value (any type): take from FirstAggregatorFactory field
					new[] { "[Measures].[Internet Order Count]", "{0}" },    // state values field name templates
					new[] { typeof(uint), typeof(object) })   // types of state values
			);

			// desired pivot table configuration
			// note: FirstValueAggregator is used for any type of measures as they are calculated by OLAP server
			// and AdomdDataReader returns sub-totals and grand total too.
			var pvtCfg = new PivotDataConfiguration() {
				Dimensions = new[] { "[Customer].[Country]", "[Product].[Category]" },
				Aggregators = new[] {
					new AggregatorFactoryConfiguration("First", new [] {"[Measures].[Internet Order Count]"}),
					new AggregatorFactoryConfiguration("First", new [] {"[Measures].[Internet Sales Amount]"})
				}
			};

			var pvtDataState = grpRdr.ReadState(pvtCfg);
			var pvtData = new FixedPivotData(pvtCfg.Dimensions, 
				new CompositeAggregatorFactory(	
					new FirstAggregatorFactory("[Measures].[Internet Order Count]", "Orders Count"),
					new FirstAggregatorFactory("[Measures].[Internet Sales Amount]", "Sales Amount")
				), pvtDataState);

			// now we can create pivot table data model
			var pvtTbl = new PivotTable(new[] { "[Customer].[Country]" }, new[] { "[Product].[Category]" }, pvtData);
			pvtTbl.TotalsCache = false; // disable excessive roll-ups as our totals are pre-calculated

			var strWr = new StringWriter();
			new PivotTableCsvWriter(strWr).Write(pvtTbl);
			Console.WriteLine(strWr.ToString());
			Console.WriteLine("\nPress any key to exit...");
			Console.ReadKey();

		}

		static void ReadDataReaderRaw(IDbCommand cmd) {
			cmd.Connection.Open();
			try {
				using (var rdr = cmd.ExecuteReader()) {
					for (int i = 0; i < rdr.FieldCount; i++) {
						Console.Write($"{rdr.GetName(i)}\t");
					}
					Console.WriteLine();

					while (rdr.Read()) {
						for (int i = 0; i < rdr.FieldCount; i++) {
							Console.Write($"[{rdr[i] ?? "NULL"}]\t");
						}
						Console.WriteLine();

					}

				}

			} finally {
				cmd.Connection.Close();
			}
			Console.WriteLine("\nPress any key...");
			Console.ReadKey();
		}
	}
}
