﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Data;
using NReco.PivotData.Input;

namespace NReco.PivotData.Examples.ToolkitAdomdSource {

	/// <summary>
	/// <see cref="IPivotDataSource"/> wrapper that resolved AdomdDataReader field by prefix and skips 'empty' rows.
	/// </summary>
	public class ResolveAdomdSource : IPivotDataSource {

		IPivotDataSource BaseSource;
		string CountFieldName;

		public ResolveAdomdSource(IPivotDataSource baseSource, string countFieldName) {
			BaseSource = baseSource;
			CountFieldName = countFieldName;
		}

		IEnumerable filterRowsWithNullCount(IEnumerable data) {
			// if NON EMPTY is not specified AdomdDataReader can return rows with NULL in measures
			// lets just skip them
			foreach (var r in data) {
				var rdr = (IDataReader)r;
				if (rdr[CountFieldName] == null)
					continue;
				yield return r;
			}
		}

		public void ReadData(Action<IEnumerable, Func<object, string, object>> readData) {
			BaseSource.ReadData((data, getValue) => {
				var resolvedFields = new Dictionary<string, string>();
				var knownFields = new HashSet<string>();

				string resolveFieldName(IDataReader rdr, string f) {
					if (resolvedFields.TryGetValue(f, out var resolvedFld))
						return resolvedFld;

					if (knownFields.Count<rdr.FieldCount)
						for (int i=0; i<rdr.FieldCount; i++)
							knownFields.Add(rdr.GetName(i));

					if (knownFields.Contains(f)) {
						// field exists
						resolvedFields[f] = f;
						return f;
					}
					// try to find field by prefix
					foreach (var fName in knownFields) {
						if (fName.StartsWith(f)) {
							resolvedFields[f] = fName;
							return fName;
						}
					}
					// no matches by prefix
					// return field name as is, it will cause 'invalid field name' error
					return f;
				}

				readData(filterRowsWithNullCount(data), (row, field) => {
					var rdr = (IDataReader)row;
					return getValue(row, resolveFieldName(rdr, field ) );
				});
			});
		}
	}
}
