﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NReco.PivotData.Examples.ToolkitAdomdSource {

	/// <summary>
	/// Implements special aggregator that always holds only first value.
	/// </summary>	 
	public class FirstAggregator : IAggregator {

		object value = null;
		uint count = 0;
		string field;

		public FirstAggregator(string f) {
			field = f;
		}

		public FirstAggregator(string f, object state) : this(f) {
			var stateArr = state as object[];
			if (stateArr == null || stateArr.Length != 2)
				throw new InvalidOperationException("invalid state");
			count = Convert.ToUInt32(stateArr[0]);
			value = stateArr[1];
		}

		public void Push(object r, Func<object, string, object> getValue) {
			var v = getValue(r, field);
			if (v != null && !DBNull.Value.Equals(v)) {
				if (count == 0) {
					value = v;
				}
				count++;
			}
		}

		public object Value {
			get { return value; }
		}

		public uint Count {
			get { return count; }
		}

		public void Merge(IAggregator aggr) {
			if (count == 0) {
				value = aggr.Value;
				count = aggr.Count;
			}
		}

		public object GetState() {
			return new object[] { count, value };
		}
	}

	public class FirstAggregatorFactory : IAggregatorFactory {

		public string Field { get; private set; }

		public string Caption { get; private set; }

		public FirstAggregatorFactory(string field, string caption) {
			Field = field;
			Caption = caption;
		}

		public IAggregator Create() {
			return new FirstAggregator(Field);
		}

		public IAggregator Create(object state) {
			return new FirstAggregator(Field, state);
		}

		public override bool Equals(object obj) {
			var factory = obj as FirstAggregatorFactory;
			if (factory == null)
				return false;
			return factory.Field == Field;
		}

		public override string ToString() {
			return Caption ?? Field;
		}
	}

}
