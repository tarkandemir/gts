﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using MongoDB.Bson;

namespace NReco.PivotData.Examples.ToolkitMongoDbSource {

	/// <summary>
	/// Represents <see cref="IPivotDataSource"/> implementation for standard MongoDb query results.
	// </summary>
	public class MongoQueryResults : IPivotDataSource {
		IEnumerable<BsonDocument> Results;

		internal MongoQueryResults(IEnumerable<BsonDocument> queryResults) {
			Results = queryResults;
		}

		public void ReadData(Action<IEnumerable, Func<object, string, object>> handler) {
			handler(Results, GetBsonDocumentValue);
		}

		static object GetBsonDocumentValue(object d, string f) {
			if (d is BsonArray) {
				throw new Exception("Use unwind to expand sub-collections.");
			}
			var doc = (BsonDocument)d;
			var pathCharIdx = f.IndexOf('.');
			if (pathCharIdx>0) {
				var pathFld = f.Substring(0, pathCharIdx);
				return GetBsonDocumentValue( GetValueOrNull(doc, pathFld), f.Substring(pathCharIdx+1) );
			}
			return BsonTypeMapper.MapToDotNetValue(  GetValueOrNull(doc, f) );
		}

		static BsonValue GetValueOrNull(BsonDocument bsonDoc, string f) {
			BsonValue res = null;
			if (bsonDoc.TryGetValue(f, out res))
				return res;
			return BsonValue.Create(null);
		}

	}

}
