﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;

using MongoDB.Bson;
using MongoDB.Driver;

using NReco.PivotData;
using NReco.PivotData.Input;
using NReco.PivotData.Output;

namespace NReco.PivotData.Examples.ToolkitMongoDbSource {
	
	class Program {

		static void Main(string[] args) {

			// This example illustrates how to use MongoDb as a data source for PivotData
			// sample mongo DB: https://docs.mongodb.com/getting-started/shell/import-data/

			var mongoSource = new MongoDbSource(
				"mongodb+srv://nrecodemo:B9DgeMdDWf6yz6VN@cluster0.l3vux.mongodb.net/",
				"sample_restaurants",  // db name
				"restaurants"  // collection name
			);

			// use case 1: query mongo DB and aggregate data with PivotData (for small datasets)
			var pvtData1 = new PivotData(new [] {"cuisine", "address.street"}, new CountAggregatorFactory());
			var result1 = mongoSource.GetDataSource( new PivotDataFactory().GetConfiguration(pvtData1) );
			pvtData1.ProcessData(result1);

			Console.WriteLine("Result 1: input data from mongo, aggregated by PivotData");
			WritePvtTbl( new PivotTable( 
				new [] {"cuisine"},
				null,
				pvtData1
			) );
			Console.WriteLine("Press any key...");
			Console.ReadKey();
			Console.WriteLine();

			// use case 2: aggregate data with mongo DB and load results into PivotData
			IPivotData pvtData2 = new PivotData(new [] {"borough"}, new AverageAggregatorFactory("grades.score"));
			var pvtFactory = new PivotDataFactory();
			var pvtCfg = new PivotDataFactory().GetConfiguration(pvtData2);
			var pvtReader = new GroupedSourceReader( mongoSource.GetAggregateDataSource(pvtCfg, "grades"), "__Count" );
			pvtData2 = pvtReader.Read(pvtCfg, pvtFactory);
			
			Console.WriteLine("Result 2: data aggregated by mongo and loaded into PivotData");
			WritePvtTbl( new PivotTable( 
				new [] {"borough"},
				null,
				pvtData2
			) );
			Console.WriteLine("Press any key...");
			Console.ReadKey();
		}

		static void WritePvtTbl(IPivotTable pvtTbl) {
			var strWr = new StringWriter();
			var wr = new PivotTableCsvWriter(strWr);
			wr.Write(pvtTbl);
			Console.WriteLine(strWr.ToString());
		}


	}
}
