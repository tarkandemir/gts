﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using MongoDB.Bson;
using MongoDB.Driver;

namespace NReco.PivotData.Examples.ToolkitMongoDbSource {

	public class MongoDbSource {

		string ConnectionString;
		string Database;
		string Collection;

		/// <summary>
		/// Database-level filter JSON https://docs.mongodb.com/manual/reference/operator/query/ (optional)
		/// </summary>
		public string FilterJson { get; set; }

		public MongoDbSource(string connectionString, string database, string collection) {
			ConnectionString = connectionString;
			Database = database;
			Collection = collection;
		}

		private IMongoCollection<BsonDocument> GetMongoCollection() {
			var client = new MongoClient(ConnectionString);
			var db = client.GetDatabase(Database);
			return db.GetCollection<BsonDocument>(Collection);
		}

		private BsonDocument GetFilterBson(string filterJson) {
			if (filterJson!=null) {
				return BsonDocument.Parse(filterJson);
			}
			return new BsonDocument();
		}

		/// <summary>
		/// Returns a data source instance for PivotData.ProcessData method (aggregation is performed by .NET code). 
		/// </summary>
		/// <remarks>
		/// Use this method for small datasets or if you need to use aggregators that differs from min/max/average/sum/count.
		/// </remarks>
		public IPivotDataSource GetDataSource(PivotDataConfiguration pvtConfig) {
			var colList = new List<string>();
			foreach (var dim in pvtConfig.Dimensions) {
				colList.Add(dim);
			}
			foreach (var aggrCfg in pvtConfig.Aggregators) {
				// for now lets assume that only parameter that aggregator may have is a field name
				if (aggrCfg.Params!=null) {
					foreach (var p in aggrCfg.Params)
						if (p is string) {
							colList.Add( (string)p );
						}
				}
			}
			var collection = GetMongoCollection();

			ProjectionDefinition<BsonDocument> projection = null;
			foreach (var col in colList) {
				if (projection==null)
					projection = Builders<BsonDocument>.Projection.Include(col);
				else
					projection = projection.Include(col);
			}

			var res = collection.Find( GetFilterBson(FilterJson) ).Project(projection).ToEnumerable();
			return new MongoQueryResults(res);
		}


		internal static string getFlatName(string s) {
			return s.Replace(".", "__");
		}

		/// <summary>
		/// Returns a data source instance for GroupedSourceReader (aggregation is performed with MongoDb aggregation pipeline). 
		/// </summary>
		/// <remarks>
		/// This method can be used with Mongo collections of any size. Only min/max/average/sum/count aggregators are supported.
		/// </remarks>
		public IPivotDataSource GetAggregateDataSource(PivotDataConfiguration pvtConfig, params string[] unwinds) {
			var mongoAggregators = new Dictionary<string, string>() {
				{"Count", null },
				{"Sum", "$sum" },
				{"Average", "$avg" },
				{"Min", "$min"},
				{"Max", "$max"}
			};

			var idListDoc = new BsonDocument();
			var groupBsonDoc = new BsonDocument();
			var selectFields = new List<string>();

			foreach (var dim in pvtConfig.Dimensions) {
				idListDoc.Add( getFlatName(dim) , "$"+dim);
				selectFields.Add(dim);
			}
			foreach (var aggrCfg in pvtConfig.Aggregators) {
				// for now lets assume that only parameter that aggregator may have is a field name
				if (aggrCfg.Params!=null) {
					foreach (var p in aggrCfg.Params)
						if (p is string) {
							var colName = (string)p;
							groupBsonDoc.Add( String.Format( "{0}_{1}", getFlatName(colName), aggrCfg.Name ), 
								new BsonDocument() { { mongoAggregators[aggrCfg.Name], "$"+colName } } );

							selectFields.Add(colName);					
						}
				}
			}
			groupBsonDoc.Add("__Count", new BsonDocument("$sum", 1));
			groupBsonDoc.Add("_id", idListDoc);
			
			var collection = GetMongoCollection().Aggregate();
			collection = collection.Match( GetFilterBson(FilterJson) );

			if (unwinds!=null && unwinds.Length>0) {
				foreach (var unwind in unwinds) {
					collection = collection.Unwind(unwind);
				}
			}

			collection = collection.Group(groupBsonDoc);
			var res = collection.ToEnumerable();
			return new MongoAggregateResults(res);
		}


	}
}
