﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using MongoDB.Bson;

namespace NReco.PivotData.Examples.ToolkitMongoDbSource {
	
	/// <summary>
	/// Represents <see cref="IPivotDataSource"/> implementation for standard MongoDb query results.
	// </summary>
	public class MongoAggregateResults : IPivotDataSource {
			
		IEnumerable<BsonDocument> Results;

		internal MongoAggregateResults(IEnumerable<BsonDocument> queryResults) {
			Results = queryResults;
		}

		public void ReadData(Action<IEnumerable, Func<object, string, object>> handler) {
			handler(Results, GetBsonDocumentValue);
		}

		static object GetBsonDocumentValue(object d, string f) {
			var pathCharIdx = f.IndexOf('.');
			if (pathCharIdx>0) {
				f = MongoDbSource.getFlatName(f);
			}

			var doc = (BsonDocument)d;
			var id = doc["_id"];
			if (id is BsonDocument) {
				var idDoc = (BsonDocument)id;
				if (idDoc.Contains(f))
					return BsonTypeMapper.MapToDotNetValue( GetValueOrNull( idDoc, f) );
			}
			return BsonTypeMapper.MapToDotNetValue( GetValueOrNull( doc, f) );
		}

		static BsonValue GetValueOrNull(BsonDocument bsonDoc, string f) {
			BsonValue res = null;
			if (bsonDoc.TryGetValue(f, out res))
				return res;
			return BsonValue.Create(null);
		}


	}
}
