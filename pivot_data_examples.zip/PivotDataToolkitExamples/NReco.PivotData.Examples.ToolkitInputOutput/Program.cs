﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

using NReco.PivotData;
using NReco.PivotData.Input;
using NReco.PivotData.Input.Value;
using NReco.PivotData.Output;

namespace NReco.PivotData.Examples.ToolkitInputOutput {
	
	/// <summary>
	/// This example illustrates PivotData Toolkit Input readers / Output writers usage.
	/// </summary>
	class Program {
		static void Main(string[] args) {

			// step 1: aggregate CSV file, parse numbers/dates and configure derived values
			Console.WriteLine("Aggregating 'TechCrunchcontinentalUSA.csv' ...");
			PivotData techCrunchPvtData;

			using (var csvFileRdr = new StreamReader("TechCrunchcontinentalUSA.csv") ) {
				var csvPvtReader = new CsvSource(csvFileRdr, new CsvConfiguration() { Delimiter="," } );

				// configure derived source wrapper that will parse dates and numbers
				var parsePvtReader = new DerivedValueSource(csvPvtReader);
				parsePvtReader.Register("fundedDate", new ParseValue().ParseDateTimeHandler );
				parsePvtReader.Register("raisedAmt", new ParseValue().ParseDecimalHandler );

				// configure some derived values
				var derivedValsPvtReader = new DerivedValueSource(parsePvtReader);
				derivedValsPvtReader.Register("funded_year", new DatePartValue("fundedDate").YearHandler );
				derivedValsPvtReader.Register("funded_quarter", new DatePartValue("fundedDate").QuarterHandler );

				// finally lets compose year+quarter
				var fmtValsPvtReader = new DerivedValueSource(derivedValsPvtReader);
				fmtValsPvtReader.Register("funded_year_quarter", 
					new FormatValue("{0} Q{1}", new[]{"funded_year", "funded_quarter"}).FormatHandler );

				techCrunchPvtData = new PivotData(new[]{"company","category","fundedDate","funded_year_quarter","round"},
					new CompositeAggregatorFactory( 
						new CountAggregatorFactory(),
						new SumAggregatorFactory("raisedAmt"),
						new AverageAggregatorFactory("raisedAmt"),
						new MaxAggregatorFactory("raisedAmt")
					), false);

				techCrunchPvtData.ProcessData(fmtValsPvtReader);
			}

			// step 2: save cube to file
			Console.WriteLine("Writing data cube to 'TechCrunchCube'...");
			var cubeFileWr = new CubeFileWriter("TechCrunchCube");
			var pvtDataFactory = new PivotDataFactory();
			// note: if your cube uses custom IAggregateFactory implementations they should be registered 
			// in with PivotDataFactory.RegisterAggregator
			cubeFileWr.Write(techCrunchPvtData, pvtDataFactory.GetConfiguration(techCrunchPvtData) );

			// step 3: read saved cube from file
			Console.WriteLine("Reading saved data cube from 'TechCrunchCube'...");
			var cubeFileRdr = new CubeFileReader("TechCrunchCube", pvtDataFactory);
			IPivotData loadedPvtData = cubeFileRdr.Read();

			// lets render some data
			Console.WriteLine("Total raised amount: {0:#.##}", 
				loadedPvtData[Key.Empty,Key.Empty,Key.Empty,Key.Empty,Key.Empty].AsComposite().Aggregators[1].Value );

			Console.WriteLine("\nGenerating pivot table (CSV format)...");

			// simple CSV output
			var pvtTblFactory = new PivotTableFactory();
			var	pvtByRound = pvtTblFactory.Create(loadedPvtData,
					new PivotTableConfiguration() {
						Rows = new[] {"round"}, Measures = new[]{ 1 }
					}
				);
			var csvWriter = new PivotTableCsvWriter(Console.Out);
			csvWriter.Write(pvtByRound);

			Console.WriteLine("\nGenerating pivot table (HTML format)...");
			var	pvtNumInvByCategory = pvtTblFactory.Create(loadedPvtData,
					new PivotTableConfiguration() {
						Columns = new[] {"category"}, Measures = new[] { 0 }
					}
				);
			var htmlWriter = new PivotTableHtmlWriter(Console.Out);
			htmlWriter.Write(pvtNumInvByCategory);

			Console.WriteLine("\n\nGenerating pivot table (Excel format)...");
			var	pvtAmountByRoundAndQuarter = pvtTblFactory.Create(loadedPvtData,
					new PivotTableConfiguration() {
						Rows = new [] {"funded_year_quarter"},
						Columns = new[] {"round"}, Measures = new [] { 1 }
					}
				);
			using (var excelStream = new FileStream("TechCrunch_Report.xlsx", FileMode.OpenOrCreate, FileAccess.Write)) {
				var excelWriter = new PivotTableExcelWriter(excelStream, "Report");
				excelWriter.Write(pvtAmountByRoundAndQuarter);
			}
			Console.WriteLine("(report saved to 'TechCrunch_Report.xlsx')");
			Console.WriteLine("\nPress any key...");

			Console.ReadKey();
		}


	}

}
