﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data;
using Microsoft.Data.Sqlite;

using NReco.PivotData;
using NReco.PivotData.Input;

using NReco.PivotData.Output;

namespace NReco.PivotData.Examples.ToolkitSqlDbSource {

	/// <summary>
	/// This example illustrates how to aggregate data from SQL DB source (SQLite is used for demo purposes)
	/// </summary>
	/// <remarks>
	/// SQLite is used as database for demo purposes (sample Chinook Database https://github.com/lerocha/chinook-database )
	/// </remarks>
	class Program {
		static void Main(string[] args) {

			// sample 1: use database as data source and aggregate data on .NET side
			var pvtData = new PivotData(
					new[] {"BillingCountry", "GenreName"},
					new CompositeAggregatorFactory(
						new SumAggregatorFactory("Quantity"),
						new SumAggregatorFactory("UnitPrice")
					)
				);
			Console.WriteLine("Processing data from sample Chinook DB (aggregation performed by PivotData)...");

			// instead of SQLiteConnection you can use any ADO.NET-compatible provider:
			//   SQL Server: System.Data.SqlClient.SqlConnection
			//   MySql: MySql.Data.MySqlClient.MySqlConnection
			//   PostgreSql: Npgsql.NpgsqlConnection 

			// SQL query should return columns used as dimensions or measures in "pvtData"
			var sqlSelect = @"
				SELECT Quantity, inv_line.UnitPrice, inv.InvoiceDate, inv.BillingCountry, g.Name as GenreName FROM InvoiceLine inv_line
				LEFT JOIN Invoice inv ON (inv.InvoiceId=inv_line.InvoiceId)
				LEFT JOIN Track tr ON (tr.TrackId=inv_line.TrackId)
				LEFT JOIN Genre g ON (g.GenreId=tr.GenreId)
			";

			var sqliteConn = new SqliteConnection("Data Source=Chinook_Sqlite.sqlite");
			var selectCmd = new SqliteCommand(sqlSelect, sqliteConn);
			var dbCmdSource = new DbCommandSource(selectCmd);
			pvtData.ProcessData(dbCmdSource);  // read all rows and aggregate on .NET side

			Console.WriteLine("Track sales for 'Rock': {0}",
				new SliceQuery(pvtData).Dimension("GenreName").Measure(0).Execute(false)["Rock"].Value
			);

			// sample 2: aggregate data on DB-side with GROUP BY
			// this is typical case for aggregating really big datasets with MS SQL, MySql, PostgreSql, Amazon RedShift etc
			Console.WriteLine("\nProcessing data from sample Chinook DB (aggregation performed by DB with GROUP BY)...");
			
			var sqlSelectGroupBy = @"
				SELECT 
					inv.BillingCountry, g.Name as GenreName,
					SUM(Quantity) as Quantity_Sum, SUM(inv_line.UnitPrice) as UnitPrice_Sum,
					COUNT(Quantity) as cnt 
				FROM InvoiceLine inv_line
				LEFT JOIN Invoice inv ON (inv.InvoiceId=inv_line.InvoiceId)
				LEFT JOIN Track tr ON (tr.TrackId=inv_line.TrackId)
				LEFT JOIN Genre g ON (g.GenreId=tr.GenreId)
				GROUP BY g.Name, inv.BillingCountry
			";

			// SQL GROUP BY query should return:
			// - group-by columns used as dimensions
			// - columns used by GroupedSourceReader for loading aggregators: https://www.nrecosite.com/pivotdata/load-pre-aggregated-data.aspx
			var selectGroupByCmd = new SqliteCommand(sqlSelectGroupBy, sqliteConn);
			var dbGroupByCmdSource = new DbCommandSource(selectGroupByCmd);
			var pvtDataFactory = new PivotDataFactory();
			var groupedPvtDataReader = new GroupedSourceReader(
					dbGroupByCmdSource,
					"cnt"  // column name with rows count for each entry - needed for populating IAggregator.Count property
				);
			// custom aggregator (already registered: sum, min, max, avg) may be registered
			// with GroupedSourceReader.RegisterAggregator

			var pvtDataFromGroupBy = groupedPvtDataReader.Read(
					pvtDataFactory.GetConfiguration(pvtData), // or you can compose PivotDataConfiguration manually
					pvtDataFactory
				);
			var pvtTblByGenres = new PivotTable(new[] {"GenreName"},null, pvtDataFromGroupBy);
			new PivotTableCsvWriter(Console.Out).Write(pvtTblByGenres);

			Console.ReadKey();
		}
	}
}
