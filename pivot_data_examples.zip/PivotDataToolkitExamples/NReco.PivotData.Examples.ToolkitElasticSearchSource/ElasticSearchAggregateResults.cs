﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;
using NReco.PivotData.Input;


namespace NReco.PivotData.Examples.ToolkitElasticSearchSource {

	public class ElasticSearchAggregateResults : IPivotDataSource {

		PivotDataConfiguration PvtDataCfg;
		string ResultJson;

		Dictionary<string, int> DimNameToIdx;
		Dictionary<string, int> AggrFldToIdx;

		public ElasticSearchAggregateResults(PivotDataConfiguration pvtDataCfg, string resJson) {
			PvtDataCfg = pvtDataCfg;
			ResultJson = resJson;

			DimNameToIdx = new Dictionary<string, int>();
			for (int i = 0; i < PvtDataCfg.Dimensions.Length; i++) {
				DimNameToIdx[PvtDataCfg.Dimensions[i]] = i;
			}

			AggrFldToIdx = new Dictionary<string, int>();
			for (int i = 0; i < PvtDataCfg.Aggregators.Length; i++) {
				var aggr = PvtDataCfg.Aggregators[i];

				// compose field names used by GroupedSourceReader to load aggregators values
				// see https://www.nrecosite.com/pivotdata/load-pre-aggregated-data.aspx

				var fldName = aggr.Name;
				if (aggr.Name != "Count" && aggr.Params != null && aggr.Params.Length > 0)
					fldName = Convert.ToString(aggr.Params[0]) + "_" + fldName;
				AggrFldToIdx[fldName] = i;
			}
		}

		public void ReadData(Action<IEnumerable, Func<object, string, object>> handler) {
			handler(GetResults(ResultJson), GetResultEntryValue);
		}

		IEnumerable<ResultEntry> GetResults(string resJson) {
			var topObj = JObject.Parse(resJson);
			var resEntry = new ResultEntry() {
				DimKeys = new object[PvtDataCfg.Dimensions.Length],
				Metrics = new object[PvtDataCfg.Aggregators.Length]
			};
			var aggregations = topObj["aggregations"] as JObject;
			foreach (var entry in ProcessBuckets(aggregations, PvtDataCfg.Dimensions.Length - 1, resEntry))
				yield return entry;
		}

		IEnumerable<ResultEntry> ProcessBuckets(JObject obj, int dimIdx, ResultEntry resEntry) {
			var propName = "by_" + PvtDataCfg.Dimensions[dimIdx];
			var byObj = obj[propName] as JObject;
			var buckets = byObj["buckets"] as JArray;
			for (int i = 0; i < buckets.Count; i++) {
				var bucketObj = buckets[i] as JObject;
				var key = (bucketObj["key"] as JValue).Value;
				resEntry.DimKeys[dimIdx] = key;
				if (dimIdx > 0) {
					foreach (var entry in ProcessBuckets(bucketObj, dimIdx - 1, resEntry))
						yield return entry;
				} else {
					resEntry.Count = ((JValue)bucketObj["doc_count"]).Value<int>();
					for (int j = 0; j < PvtDataCfg.Aggregators.Length; j++) {
						var aggrCfg = PvtDataCfg.Aggregators[j];
						if (aggrCfg.Name == "Count") {
							resEntry.Metrics[j] = resEntry.Count;
						} else if (aggrCfg.Params != null && aggrCfg.Params.Length > 0) {
							var metricObj = (JObject)bucketObj[aggrCfg.Name + "_" + Convert.ToString(aggrCfg.Params[0])];
							var metricVal = ((JValue)metricObj.GetValue("value")).Value;
							resEntry.Metrics[j] = metricVal;
						} else {
							throw new NotSupportedException("Cannot read values for aggregator " + aggrCfg.Name);
						}
					}
					yield return resEntry;
				}
			}
		}

		public class ResultEntry {
			public object[] DimKeys;

			public int Count;
			public object[] Metrics;
		}

		// handler for GroupedSourceReader
		object GetResultEntryValue(object row, string field) {
			var resEntry = (ResultEntry)row;
			if (field == "Count")
				return resEntry.Count;
			if (DimNameToIdx.TryGetValue(field, out var dimIdx))
				return resEntry.DimKeys[dimIdx];
			if (AggrFldToIdx.TryGetValue(field, out var metricIdx))
				return resEntry.Metrics[metricIdx];
			throw new ArgumentException("Unknown field: " + field);
		}

	}

}
