﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using NReco.PivotData;
using Newtonsoft.Json.Linq;

namespace NReco.PivotData.Examples.ToolkitElasticSearchSource {

	public class ElasticSearchQuery {

		PivotDataConfiguration PvtDataCfg;

		Dictionary<string, string> aggrNameToFuncName = new Dictionary<string, string>() {
			{"Sum", "sum"},
			{"Average", "avg"},
			{"Min", "min"},
			{"Max", "max"}
		};

		public ElasticSearchQuery(PivotDataConfiguration pvtDataCfg) {
			PvtDataCfg = pvtDataCfg;
		}

		public string Compose() {
			// here you can add any additional query options (say, filters)

			var topObj = new JObject();
			topObj.Add("size", new JValue(0));
			var currObj = topObj;
			for (int i = (PvtDataCfg.Dimensions.Length - 1); i >= 0; i--) {
				var dimName = PvtDataCfg.Dimensions[i];
				var aggsObj = new JObject();
				currObj.Add("aggs", aggsObj);

				var byObj = new JObject();
				aggsObj.Add("by_" + dimName, byObj);

				var termsObj = new JObject();
				byObj.Add("terms", termsObj);
				termsObj.Add("field", new JValue(dimName));
				termsObj.Add("size", new JValue(100000));   // some reasonable number of keys to return

				if (i == 0) {
					var finalAggsObj = new JObject();
					int propsCnt = 0;
					for (int j = 0; j < PvtDataCfg.Aggregators.Length; j++) {
						var aggr = PvtDataCfg.Aggregators[j];
						if (aggr.Name == "Count" || aggr.Params == null || aggr.Params.Length < 1)
							continue; // ignore: elasic always returns counts

						var aggrFuncNameObj = new JObject();
						string aggrFuncName;
						if (!aggrNameToFuncName.TryGetValue(aggr.Name, out aggrFuncName))
							throw new Exception("Unsupported aggregator: " + aggr.Name);

						var aggrFldObj = new JObject();
						aggrFldObj.Add("field", Convert.ToString(aggr.Params[0]));
						aggrFuncNameObj.Add(aggrFuncName, aggrFldObj);

						finalAggsObj.Add($"{aggr.Name}_{aggr.Params[0]}", aggrFuncNameObj);
						propsCnt++;

					}
					if (propsCnt > 0)
						byObj.Add("aggs", finalAggsObj);
				}

				currObj = byObj;
			}
			return topObj.ToString();
		}

	}

}
