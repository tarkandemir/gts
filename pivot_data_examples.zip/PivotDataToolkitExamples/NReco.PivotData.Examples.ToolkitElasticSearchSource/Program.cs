﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Threading.Tasks;

using Elasticsearch.Net;
using NReco.PivotData.Input;
using NReco.PivotData.Output;

namespace NReco.PivotData.Examples.ToolkitElasticSearchSource {
	class Program {

		static void Main(string[] args) {

			// This example illustrates how to use ElasticSearch as a data source for PivotData
			// Sample uses account.json dataset from official ElasticSearch docs: https://www.elastic.co/guide/en/elasticsearch/reference/6.2/_exploring_your_data.html

			// in case if you want to use local elasticsearch instance
			//var node = new Uri("http://localhost:9200");

			var node = new Uri("https://site:nxxr8qt7n26c7jwijhwg1ipnarf402yn@thorin-us-east-1.searchly.com");

			var config = new ConnectionConfiguration(node).RequestTimeout(TimeSpan.FromMinutes(2));
			var elasticSearchClient = new ElasticLowLevelClient(config);
			var index = "bank";
			string docType = "_doc";


			var pvtDataCfg = new PivotDataConfiguration() {
				Dimensions = new[] { "state.keyword", "gender.keyword" },
				Aggregators = new[] {
					new AggregatorFactoryConfiguration("Count", null),
					new AggregatorFactoryConfiguration("Average", new object[] {"age"})
				}
			};
			var elasticQuery = new ElasticSearchQuery(pvtDataCfg);
			var q = elasticQuery.Compose();

			var resp = elasticSearchClient.Search<StringResponse>(index, docType, PostData.String(q));
			var elasticSearchSrc = new ElasticSearchAggregateResults(pvtDataCfg, resp.Body);

			var pvtReader = new GroupedSourceReader(elasticSearchSrc, "Count");  // 'Count' is special field name for 'doc_count'
			var pvtData = pvtReader.Read(pvtDataCfg, new PivotDataFactory());

			var pvtTbl = new PivotTable(new[] { "state.keyword" }, new[] { "gender.keyword" }, pvtData);
			WritePvtTbl(pvtTbl);

			Console.WriteLine("Press any key...");
			Console.ReadKey();
		}

		static void WritePvtTbl(IPivotTable pvtTbl) {
			var strWr = new StringWriter();
			var wr = new PivotTableCsvWriter(strWr);
			wr.FormatValue = (aggr, idx) => String.Format("{0:0.###}", aggr.Value);
			wr.Write(pvtTbl);
			Console.WriteLine(strWr.ToString());
		}


	}
}
