NReco.PivotData Toolkit
-----------------------
Component page: https://www.nrecosite.com/pivot_data_library_net.aspx
Getting started: https://www.nrecosite.com/pivotdata/cube-basics.aspx
API reference: https://www.nrecosite.com/doc/NReco.PivotData/

Nuget packages
--------------
NReco.PivotData (OLAP library)     
    https://www.nuget.org/packages/NReco.PivotData/ (source code / examples: https://github.com/nreco/pivotdata)
NReco.PivotData.Extensions (BI Toolkit components)
    https://www.nuget.org/packages/NReco.PivotData.Extensions/
	    note: without a valid license key, NReco.PivotData.Extensions.dll works in TRIAL MODE (with some data size limitations / trial notices).

Examples in this package
------------------------
ToolkitPivotBuilderMvc      web pivot table builder, HTML pivot tables and charts examples (MVC, online demo: http://pivottable.nrecosite.com/ )
ToolkitAdomdSource          how to use SSAS OLAP server as data source (based on Microsoft.AnalysisServices.AdomdClient)
ToolkitElasticSearchSource  how to use ElasticSearch as data source for pivot tables
ToolkitInputOutput          illustrates usage of Toolkit data sources and pivot table writers
ToolkitLoadPreaggregatedTotals    how to load pre-aggregated totals/sub-totals - like SELECT WITH CUBE
ToolkitMongoDbSource        how to use MongoDb data source as input
ToolkitSqlDbSource          how to use SQL data source as input (2 variants: aggregation on .NET side and aggregation on database level)
ToolkitPivotDataServiceSource	how to use PivotDataService API to load PivotData
ToolkitCreateOfflineCube	(legacy) generates offline AS cube (.cub file) by PivotData instance (MS SQL/AS server is NOT needed, only AS OLE driver is used) 
ToolkitPivotTableWebForms   (legacy) aggregates JSON data and renders simple pivot table (WebForms)
ToolkitPivotTableWinForms   (legacy) displays pivot table in desktop app with WebBrowser and DataGridView control (WebForms)

Examples for NReco.PivotData (OLAP library) are here: https://github.com/nreco/pivotdata/tree/master/examples

License and usage conditions
----------------------------
NReco.PivotData.DLL
    Free usage license: https://github.com/nreco/pivotdata/blob/master/src/LICENSE
NReco.PivotData.Extensions.DLL + js widgets + code from toolkit examples
    Toolkit components require commercial license for usage and redistribution as part of your own product. It can be purchased here: https://www.nrecosite.com/pivot_data_library_net.aspx