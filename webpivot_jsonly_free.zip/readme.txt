NReco pivottable.js extensions
------------------------------
Visit http://www.nrecosite.com/pivot_table_aspnet.aspx for the latest information (change log, examples etc)
ASP.NET integration demo (export, SQL data source): http://webpivot.nrecosite.com/

License
-------
Free version of NReco extensions (nrecopivottableext.js, nrecopivottableext.css) with "powered by" notice can be used and redistributed without any limitations.
Any modifications in the javascript code are NOT allowed, as well as removing or hiding "powered by" label. 

You may purchase commercial version to remove "powered by" notice and avoid these restrictions.
