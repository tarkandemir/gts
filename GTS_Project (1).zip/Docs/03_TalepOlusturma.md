# 📨 Talep Oluşturma Modülü

## 🎯 Modül Amacı
Kullanıcıların şirket içinde başka bir kullanıcıya resmi bir görüş talebi iletmesini sağlar. Eskiden e-posta ile yapılan bu işlem artık sistem içinden yapılacaktır.

## 👥 Hedef Kullanıcı
Tüm AD kullanıcıları

## 🧭 Ekran Akışı
1. Kullanıcı "Yeni Talep Oluştur" butonuna basar
2. Form ekranı açılır
3. Kullanıcı zorunlu ve opsiyonel alanları doldurur
4. Gönder butonuna basıldığında:
   - Talep veritabanına kaydedilir
   - Alıcılara bildirim ve e-posta gider
   - İlgili log satırı yazılır

## 🧾 Form Alanları
| Alan          | Açıklama                                    | Tip             | Zorunlu |
|---------------|---------------------------------------------|------------------|---------|
| ToSicils      | AD'den autocomplete, çoklu kullanıcı seçimi | List<string>     | ✅      |
| CcSicils      | Bilgilendirme için çoklu seçim              | List<string>     | ❌      |
| Subject       | Talep başlığı                               | string           | ✅      |
| Description   | Rich text olarak detay açıklama             | string           | ✅      |
| IsUrgent      | SLA’ya etki eden bir flag                   | bool             | ❌      |
| DueDate       | Opsiyonel tamamlanma süresi                 | DateTime?        | ❌      |
| Attachments   | Çoklu dosya yükleme                         | List<IFormFile>  | ❌      |

## 🗃️ Veritabanı İlişkisi
- Talepler: `DI_GTS_REQUESTS`
- Alıcılar (To/CC): `DI_GTS_REQUEST_RECIPIENTS`
- Ekler: `DI_GTS_ATTACHMENTS`

## ⚙️ Cursor İçin Teknik Notlar
- ViewModel’de `ToSicils`, `CcSicils` alanları `List<string>` olmalı
- View’da `<select multiple>` ile desteklenmeli
- Controller POST aksiyonu bu iki listeyi ayrı ayrı parse etmeli
- Kategori, talebi alan kişi tarafından atanacağından bu formda yer almaz
- Kullanıcı bilgisi `DOMAIN\SICIL` formatında alınır → sadece `SICIL` kısmı kullanılmalı
