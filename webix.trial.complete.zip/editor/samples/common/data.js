// eslint-disable-next-line no-unused-vars
const dummyText = `
  <p>Hello World</p>
  <p><a href="https://docs.webix.com/desktop__editor.html">https://docs.webix.com/desktop__editor.html</a></p>
  <p><a href="https://docs.webix.com/desktop__editor.html"><b>Sa</b><i>mp</i>le</a> text</p>
  <p>With spaces:</p>
  <p>
    <img src="https://docs.webix.com/richtext-backend/images/1/i.png" style="width:249px;height:143px;">
  </p>
  <p>No spaces:</p>
  <p><img src="https://docs.webix.com/richtext-backend/images/2/i.png" style="width:249px;height:143px;"></p>
`;
