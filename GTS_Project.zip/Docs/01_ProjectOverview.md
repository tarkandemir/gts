# 📘 GTS – Görüş Takip Sistemi: Proje Genel Tanımı

## 🎯 Amaç
Görüş Takip Sistemi (GTS), şirket içindeki çalışanların birimler arası resmi görüş/talep süreçlerini e-posta yerine merkezi bir platformdan yönetmesini amaçlar. Talep oluşturma, iletme, bildirim alma, izleme ve raporlama işlemlerini tek bir sistemde toplar.

## 🧱 Temel Özellikler
- Windows Authentication (DOMAIN\SICIL formatı)
- SLA yönetimi ve aciliyet takibi
- Dinamik bildirim ve e-posta altyapısı
- Kategori bazlı etiketleme ve yönetim
- Çoklu kullanıcıya talep iletimi (To ve CC)
- Detaylı loglama ve işlem geçmişi
- Oracle veritabanı ile çalışma (triggersız)

## 📁 Modüller
1. Talep Oluşturma
2. Talep Listeleme & Detay
3. Bildirim Sistemi
4. SLA Takibi
5. Loglama
6. Yorum & Yanıt Sistemi
7. İstatistik Sayfası
8. Kullanıcı Profili
9. Yönetici Paneli
10. Takvim Görünümü
11. Geri Bildirim
12. Yardım / SSS
13. Dashboard

## 📊 Veritabanı
- Prefix: `DI_GTS_`
- Trigger kullanımına izin verilmez
- JOIN işlemleri küçük harf ile yazılır
