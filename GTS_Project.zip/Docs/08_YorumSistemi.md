# 💬 Yorum & Yanıt Sistemi

## 🎯 Amaç
Talepler altında kullanıcıların etkileşimde bulunmasını sağlar. Yanıt yapısı ile tartışma ortamı oluşur.

## 📎 Özellikler
- Her yoruma cevap verilebilir (thread)
- Kullanıcı ve zaman bilgisiyle görünür
- Silme ve düzenleme desteklenebilir

## 🗃️ Veritabanı
- `DI_GTS_COMMENTS`
- `PARENT_ID` alanı ile hiyerarşi kurulur
