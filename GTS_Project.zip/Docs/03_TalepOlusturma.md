# 📨 Talep Oluşturma Modülü

## 🎯 Modül Amacı
Kullanıcıların şirket içinde başka bir kullanıcıya resmi bir görüş talebi iletmesini sağlar. Eskiden e-posta ile yapılan bu işlem artık sistem içinden yapılacaktır.

## 👥 Hedef Kullanıcı
Tüm AD kullanıcıları

## 🧭 Ekran Akışı
1. Kullanıcı "Yeni Talep Oluştur" butonuna basar
2. Form ekranı açılır
3. Kullanıcı zorunlu ve opsiyonel alanları doldurur
4. Gönder butonuna basıldığında:
   - Talep veritabanına kaydedilir
   - Alıcılara bildirim ve e-posta gider
   - İlgili log satırı yazılır

## 🧾 Form Alanları
| Alan          | Açıklama                                    | Tip             |
|---------------|---------------------------------------------|-----------------|
| Kime (To)     | AD'den autocomplete, çoklu seçim            | List<string>    |
| Bilgilendirme (CC) | Ek kullanıcılar, çoklu seçim           | List<string>    |
| Konu          | Talep başlığı                               | string          |
| Açıklama      | Rich text olarak detay açıklama             | string          |
| Acil mi?      | SLA’ya etki eden bir flag                   | bool            |
| Son Tarih     | Opsiyonel tamamlanma süresi                 | DateTime?       |
| Ekler         | Çoklu dosya yükleme                         | List<IFormFile> |

## 🗃️ Veritabanı İlişkisi
- Talepler: `DI_GTS_REQUESTS`
- Alıcılar (To/CC): `DI_GTS_REQUEST_RECIPIENTS`
- Ekler: `DI_GTS_ATTACHMENTS`

## ⚙️ Cursor İçin Teknik Notlar
- ViewModel’de `ToSicils` ve `CcSicils` alanları `List<string>` olmalı
- View’da `<select multiple>` ile desteklenmeli
- Controller POST aksiyonu bu iki listeyi ayrı ayrı parse etmeli
- Kategori, talebi alan kişi tarafından atanacağından burada yer almaz

## 🔔 Uyarı
- Kullanıcı adı `DOMAIN\SICIL` formatındaysa sadece `SICIL` kısmı alınmalıdır.
