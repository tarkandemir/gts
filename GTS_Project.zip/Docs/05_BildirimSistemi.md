# 🔔 Bildirim Sistemi Modülü

## 🎯 Amaç
Kullanıcılara sistem içi olaylar hakkında anlık bilgilendirme sağlamak. Talep oluşturulduğunda, yanıtlandığında veya yorum eklendiğinde kullanıcıya haber verilmesini sağlar.

## 🧭 Ekran Akışı
- Yeni bildirim geldiğinde ekranın üst kısmında toast/modal uyarı gösterilir
- Bildirim geçmişi "Bildirimler" sekmesinde görülebilir
- Okunmamış bildirimler vurgulanır

## 📦 Bildirim Tipleri
- Yeni talep geldi
- Talebiniz yanıtlandı
- Yorum eklendi
- SLA uyarısı

## 🗃️ Veritabanı
- Bildirimler `DI_GTS_NOTIFICATIONS` tablosuna kaydedilir
- `IS_READ` flag’i ile okundu takibi yapılır

## ⚙️ Teknik Notlar
- Opsiyonel olarak SignalR altyapısı ile canlı bildirim yapılabilir
