# 🧾 Loglama Modülü

## 🎯 Amaç
Sistem içindeki tüm hareketlerin kayıt altına alınması, işlem geçmişinin izlenebilir olması.

## 🔍 Loglanan İşlemler
- Talep oluşturma
- Durum değişikliği
- Kategori atama
- Yorum ekleme
- Ek dosya işlemleri

## 🗃️ Veritabanı
- `DI_GTS_LOG_OPERATIONS` tablosuna yazılır

## ⚙️ Teknik Notlar
- Talep detay ekranında log geçmişi kullanıcıya gösterilebilir
