# 📈 İstatistik Modülü

## 🎯 Amaç
Yöneticilere sistemdeki kullanım verileri, performans, SLA uyumu gibi konularda özet bilgi sağlamak.

## 📊 Grafikler
- Talep hacmi (günlük, aylık)
- Ortalama çözüm süresi
- SLA ihlali oranı
- Kategori bazlı dağılım

## 🗃️ Veritabanı
- `DI_GTS_REQUESTS`, `DI_GTS_SLA_TRACKING`, `DI_GTS_USERS`

## ⚙️ Teknik Notlar
- Oracle’dan veri çekilerek grafik oluşturulmalı
- Dashboard veya ayrı sayfa olabilir
