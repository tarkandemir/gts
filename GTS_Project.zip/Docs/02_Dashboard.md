# 📊 Dashboard Modülü

## 🎯 Amaç
Kullanıcının sistemdeki en güncel durumları tek bakışta görebileceği bir özet ekranıdır. Talepler, SLA durumu, bildirimler ve istatistiksel veriler burada görselleştirilir.

## 👥 Hedef Kullanıcı
Tüm kullanıcılar

## 🧭 Ekran Akışı
1. Giriş yapan kullanıcı otomatik olarak Dashboard'a yönlendirilir
2. Ekranda kendi taleplerine ait hızlı istatistik kutuları görüntülenir
3. Anlamlı grafikler ile kategori ve durum dağılımı sunulur

## 🧾 İçerik Kutuları
- Bekleyen Talepler
- Tamamlanan Talepler
- SLA Uyarısı Veren Talepler
- Hızlı Erişim: Talep Oluştur, Listele, Takvim

## 📈 Grafikler
- Duruma göre talep dağılımı (Pie)
- Kategoriye göre dağılım (Bar)
- Günlük/haftalık yeni talep sayısı (Line)

## ⚙️ Teknik Notlar
- Grafikler Oracle’dan canlı veriyle beslenmeli
- Tarih filtresi ile dinamik sorgulama yapılmalı
