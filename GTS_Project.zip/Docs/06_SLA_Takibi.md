# ⏱️ SLA Takibi Modülü

## 🎯 Amaç
Taleplerin zamanında işleme alınmasını sağlamak ve ihlalleri belirlemek. SLA süresi aciliyet derecesine göre atanır.

## 📏 SLA Süreleri (örnek)
- Kritik: 8 saat
- Yüksek: 24 saat
- Orta: 48 saat
- Düşük: 72 saat

## 🗃️ Veritabanı
- `DI_GTS_SLA_TRACKING` tablosu
- Gecikmiş talepler sistemde vurgulanır

## ⚙️ Teknik Notlar
- SLA süresi talep oluşturulurken atanır
- Süresi geçen talepler `STATUS` bilgisine göre filtrelenebilir
