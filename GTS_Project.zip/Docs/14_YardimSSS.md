# ❓ Yardım / SSS Sayfası

## 🎯 Amaç
Sistemi ilk defa kullananlar için rehberlik sağlamak.

## İçerik Önerileri
- Nasıl talep oluşturulur?
- SLA nedir?
- Talepler nasıl cevaplanır?
- Kime alanı ne işe yarar?
- Kategori nasıl atanır?

## ⚙️ Teknik Notlar
- Statik HTML içerik olarak sunulabilir
