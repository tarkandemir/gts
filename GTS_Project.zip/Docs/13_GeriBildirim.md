# 📥 Geri Bildirim Modülü

## 🎯 Amaç
Kullanıcıların sistemle ilgili öneri, şikayet veya hata bildirimi yapmasını sağlar.

## 📋 Form Alanları
- Konu
- Açıklama
- Dosya (opsiyonel)

## 🗃️ Veritabanı
- `DI_GTS_FEEDBACKS`
