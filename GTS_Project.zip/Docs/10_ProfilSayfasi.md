# 👤 Kullanıcı Profili Sayfası

## 🎯 Amaç
Kullanıcının kendi sistem tercihlerini yönetmesi ve profil bilgilerini görüntülemesi sağlanır.

## 📋 İçerik
- AD bilgileri (okunabilir)
- Bildirim tercihleri (açık/kapalı)
- Tema modu (açık/koyu)

## 🗃️ Veritabanı
- `DI_GTS_USERS` veya `DI_GTS_USER_PREFS`

## ⚙️ Teknik Notlar
- Tercihler session üzerinden alınabilir
