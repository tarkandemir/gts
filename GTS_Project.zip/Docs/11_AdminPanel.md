# 🛠️ Yönetici Paneli

## 🎯 Amaç
Sistem yöneticisinin kullanıcıları, kategorileri, SLA yapılarını ve talepleri merkezi olarak kontrol etmesini sağlar.

## 🧾 Panel Bileşenleri
- Tüm talepleri listeleme ve filtreleme
- Kullanıcı tercihlerini görüntüleme
- SLA sürelerini tanımlama
- Kategori yönetimi

## ⚙️ Teknik Notlar
- Yetki bazlı erişim gerektirir
