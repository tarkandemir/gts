# 📋 Talep Listeleme & Detay Modülü

## 🎯 Amaç
Kullanıcının gönderdiği ve aldığı tüm talepleri listelemesi ve detaylarını görüntülemesi sağlanır.

## 🧭 Ekran Akışı
1. Kullanıcı filtreleme seçeneklerini girer (durum, tarih, kategori vb.)
2. Liste güncellenir, detay butonlarıyla açılır
3. Talep detayı popup/modal ya da ayrı sayfada gösterilir

## 🧾 Listeleme Alanları
- Talep No
- Konu
- Gönderen
- Durum
- Oluşturulma Tarihi
- Acil mi?
- Due Date

## 🔍 Detay Ekranı İçeriği
- Talep bilgileri
- Ekler (indirilebilir)
- Yorum/yanıt dizisi
- Log geçmişi
- Durum/Kategori güncelleme alanları

## ⚙️ Teknik Notlar
- Oracle’dan gelen talepler filtrelenebilir sorgu ile alınmalı
- Detay ekranı isteğe bağlı modal veya ayrı sayfa olabilir
